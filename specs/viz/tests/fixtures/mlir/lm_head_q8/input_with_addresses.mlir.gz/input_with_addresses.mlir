#loc29 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":55:10)
#loc32 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":59:15)
#loc36 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":66:17)
#loc38 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":68:17)
#loc40 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":72:19)
#loc42 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":74:19)
#loc49 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":85:10)
#loc51 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":89:15)
#loc55 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":96:17)
#loc57 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":98:17)
#loc59 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":102:19)
#loc61 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":104:19)
#loc68 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":115:10)
#loc70 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":119:15)
#loc74 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":126:17)
#loc76 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":128:17)
#loc78 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":132:19)
#loc80 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":134:19)
#loc87 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":145:10)
#loc89 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":149:15)
#loc93 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":156:17)
#loc95 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":158:17)
#loc97 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":162:19)
#loc99 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":164:19)
#loc106 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":175:10)
#loc108 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":179:15)
#loc112 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":186:17)
#loc114 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":188:17)
#loc116 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":192:19)
#loc118 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":194:19)
#loc125 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":205:10)
#loc127 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":209:15)
#loc131 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":216:17)
#loc133 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":218:17)
#loc135 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":222:19)
#loc137 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":224:19)
#loc144 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":235:10)
#loc146 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":239:15)
#loc150 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":246:17)
#loc152 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":248:17)
#loc154 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":252:19)
#loc156 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":254:19)
#loc163 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":265:10)
#loc165 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":269:15)
#loc169 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":276:17)
#loc171 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":278:17)
#loc173 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":282:19)
#loc175 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":284:19)
#loc183 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:26)
#loc184 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:56)
#loc185 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:82)
module {
  aie.device(npu2) {
    %shim_noc_tile_4_0 = aie.tile(4, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_3_0 = aie.tile(3, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_2_0 = aie.tile(2, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_1_0 = aie.tile(1, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_0_0 = aie.tile(0, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %tile_1_5 = aie.tile(1, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_1_4 = aie.tile(1, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_1_3 = aie.tile(1, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_1_2 = aie.tile(1, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_0_5 = aie.tile(0, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_0_4 = aie.tile(0, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_0_3 = aie.tile(0, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_0_2 = aie.tile(0, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %y7_cons_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 0) {init = 0 : i32, sym_name = "y7_cons_prod_lock_0"} loc(#loc2)
    %y7_cons_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 1) {init = 0 : i32, sym_name = "y7_cons_cons_lock_0"} loc(#loc2)
    %y7_buff_0 = aie.buffer(%tile_1_5) {address = 47616 : i32, sym_name = "y7_buff_0"} : memref<128xf32>  loc(#loc2)
    %y7_buff_1 = aie.buffer(%tile_1_5) {address = 48128 : i32, sym_name = "y7_buff_1"} : memref<128xf32>  loc(#loc2)
    %y7_prod_lock_0 = aie.lock(%tile_1_5, 0) {init = 2 : i32, sym_name = "y7_prod_lock_0"} loc(#loc2)
    %y7_cons_lock_0 = aie.lock(%tile_1_5, 1) {init = 0 : i32, sym_name = "y7_cons_lock_0"} loc(#loc2)
    %y6_cons_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 2) {init = 0 : i32, sym_name = "y6_cons_prod_lock_0"} loc(#loc3)
    %y6_cons_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 3) {init = 0 : i32, sym_name = "y6_cons_cons_lock_0"} loc(#loc3)
    %y6_buff_0 = aie.buffer(%tile_1_4) {address = 47616 : i32, sym_name = "y6_buff_0"} : memref<128xf32>  loc(#loc3)
    %y6_buff_1 = aie.buffer(%tile_1_4) {address = 48128 : i32, sym_name = "y6_buff_1"} : memref<128xf32>  loc(#loc3)
    %y6_prod_lock_0 = aie.lock(%tile_1_4, 0) {init = 2 : i32, sym_name = "y6_prod_lock_0"} loc(#loc3)
    %y6_cons_lock_0 = aie.lock(%tile_1_4, 1) {init = 0 : i32, sym_name = "y6_cons_lock_0"} loc(#loc3)
    %y5_cons_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 0) {init = 0 : i32, sym_name = "y5_cons_prod_lock_0"} loc(#loc4)
    %y5_cons_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 1) {init = 0 : i32, sym_name = "y5_cons_cons_lock_0"} loc(#loc4)
    %y5_buff_0 = aie.buffer(%tile_1_3) {address = 47616 : i32, sym_name = "y5_buff_0"} : memref<128xf32>  loc(#loc4)
    %y5_buff_1 = aie.buffer(%tile_1_3) {address = 48128 : i32, sym_name = "y5_buff_1"} : memref<128xf32>  loc(#loc4)
    %y5_prod_lock_0 = aie.lock(%tile_1_3, 0) {init = 2 : i32, sym_name = "y5_prod_lock_0"} loc(#loc4)
    %y5_cons_lock_0 = aie.lock(%tile_1_3, 1) {init = 0 : i32, sym_name = "y5_cons_lock_0"} loc(#loc4)
    %y4_cons_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 2) {init = 0 : i32, sym_name = "y4_cons_prod_lock_0"} loc(#loc5)
    %y4_cons_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 3) {init = 0 : i32, sym_name = "y4_cons_cons_lock_0"} loc(#loc5)
    %y4_buff_0 = aie.buffer(%tile_1_2) {address = 47616 : i32, sym_name = "y4_buff_0"} : memref<128xf32>  loc(#loc5)
    %y4_buff_1 = aie.buffer(%tile_1_2) {address = 48128 : i32, sym_name = "y4_buff_1"} : memref<128xf32>  loc(#loc5)
    %y4_prod_lock_0 = aie.lock(%tile_1_2, 0) {init = 2 : i32, sym_name = "y4_prod_lock_0"} loc(#loc5)
    %y4_cons_lock_0 = aie.lock(%tile_1_2, 1) {init = 0 : i32, sym_name = "y4_cons_lock_0"} loc(#loc5)
    %y3_cons_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 0) {init = 0 : i32, sym_name = "y3_cons_prod_lock_0"} loc(#loc6)
    %y3_cons_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 1) {init = 0 : i32, sym_name = "y3_cons_cons_lock_0"} loc(#loc6)
    %y3_buff_0 = aie.buffer(%tile_0_5) {address = 47616 : i32, sym_name = "y3_buff_0"} : memref<128xf32>  loc(#loc6)
    %y3_buff_1 = aie.buffer(%tile_0_5) {address = 48128 : i32, sym_name = "y3_buff_1"} : memref<128xf32>  loc(#loc6)
    %y3_prod_lock_0 = aie.lock(%tile_0_5, 0) {init = 2 : i32, sym_name = "y3_prod_lock_0"} loc(#loc6)
    %y3_cons_lock_0 = aie.lock(%tile_0_5, 1) {init = 0 : i32, sym_name = "y3_cons_lock_0"} loc(#loc6)
    %y2_cons_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 2) {init = 0 : i32, sym_name = "y2_cons_prod_lock_0"} loc(#loc7)
    %y2_cons_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 3) {init = 0 : i32, sym_name = "y2_cons_cons_lock_0"} loc(#loc7)
    %y2_buff_0 = aie.buffer(%tile_0_4) {address = 47616 : i32, sym_name = "y2_buff_0"} : memref<128xf32>  loc(#loc7)
    %y2_buff_1 = aie.buffer(%tile_0_4) {address = 48128 : i32, sym_name = "y2_buff_1"} : memref<128xf32>  loc(#loc7)
    %y2_prod_lock_0 = aie.lock(%tile_0_4, 0) {init = 2 : i32, sym_name = "y2_prod_lock_0"} loc(#loc7)
    %y2_cons_lock_0 = aie.lock(%tile_0_4, 1) {init = 0 : i32, sym_name = "y2_cons_lock_0"} loc(#loc7)
    %y1_cons_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 0) {init = 0 : i32, sym_name = "y1_cons_prod_lock_0"} loc(#loc8)
    %y1_cons_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 1) {init = 0 : i32, sym_name = "y1_cons_cons_lock_0"} loc(#loc8)
    %y1_buff_0 = aie.buffer(%tile_0_3) {address = 47616 : i32, sym_name = "y1_buff_0"} : memref<128xf32>  loc(#loc8)
    %y1_buff_1 = aie.buffer(%tile_0_3) {address = 48128 : i32, sym_name = "y1_buff_1"} : memref<128xf32>  loc(#loc8)
    %y1_prod_lock_0 = aie.lock(%tile_0_3, 0) {init = 2 : i32, sym_name = "y1_prod_lock_0"} loc(#loc8)
    %y1_cons_lock_0 = aie.lock(%tile_0_3, 1) {init = 0 : i32, sym_name = "y1_cons_lock_0"} loc(#loc8)
    %y0_cons_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 2) {init = 0 : i32, sym_name = "y0_cons_prod_lock_0"} loc(#loc9)
    %y0_cons_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 3) {init = 0 : i32, sym_name = "y0_cons_cons_lock_0"} loc(#loc9)
    %y0_buff_0 = aie.buffer(%tile_0_2) {address = 47616 : i32, sym_name = "y0_buff_0"} : memref<128xf32>  loc(#loc9)
    %y0_buff_1 = aie.buffer(%tile_0_2) {address = 48128 : i32, sym_name = "y0_buff_1"} : memref<128xf32>  loc(#loc9)
    %y0_prod_lock_0 = aie.lock(%tile_0_2, 0) {init = 2 : i32, sym_name = "y0_prod_lock_0"} loc(#loc9)
    %y0_cons_lock_0 = aie.lock(%tile_0_2, 1) {init = 0 : i32, sym_name = "y0_cons_lock_0"} loc(#loc9)
    %x_0_cons_buff_0 = aie.buffer(%tile_0_2) {address = 43520 : i32, sym_name = "x_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_0_cons_prod_lock_0 = aie.lock(%tile_0_2, 2) {init = 1 : i32, sym_name = "x_0_cons_prod_lock_0"} loc(#loc10)
    %x_0_cons_cons_lock_0 = aie.lock(%tile_0_2, 3) {init = 0 : i32, sym_name = "x_0_cons_cons_lock_0"} loc(#loc10)
    %x_1_cons_buff_0 = aie.buffer(%tile_0_3) {address = 43520 : i32, sym_name = "x_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_1_cons_prod_lock_0 = aie.lock(%tile_0_3, 2) {init = 1 : i32, sym_name = "x_1_cons_prod_lock_0"} loc(#loc10)
    %x_1_cons_cons_lock_0 = aie.lock(%tile_0_3, 3) {init = 0 : i32, sym_name = "x_1_cons_cons_lock_0"} loc(#loc10)
    %x_2_cons_buff_0 = aie.buffer(%tile_0_4) {address = 43520 : i32, sym_name = "x_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_2_cons_prod_lock_0 = aie.lock(%tile_0_4, 2) {init = 1 : i32, sym_name = "x_2_cons_prod_lock_0"} loc(#loc10)
    %x_2_cons_cons_lock_0 = aie.lock(%tile_0_4, 3) {init = 0 : i32, sym_name = "x_2_cons_cons_lock_0"} loc(#loc10)
    %x_3_cons_buff_0 = aie.buffer(%tile_0_5) {address = 43520 : i32, sym_name = "x_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_3_cons_prod_lock_0 = aie.lock(%tile_0_5, 2) {init = 1 : i32, sym_name = "x_3_cons_prod_lock_0"} loc(#loc10)
    %x_3_cons_cons_lock_0 = aie.lock(%tile_0_5, 3) {init = 0 : i32, sym_name = "x_3_cons_cons_lock_0"} loc(#loc10)
    %x_4_cons_buff_0 = aie.buffer(%tile_1_2) {address = 43520 : i32, sym_name = "x_4_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_4_cons_prod_lock_0 = aie.lock(%tile_1_2, 2) {init = 1 : i32, sym_name = "x_4_cons_prod_lock_0"} loc(#loc10)
    %x_4_cons_cons_lock_0 = aie.lock(%tile_1_2, 3) {init = 0 : i32, sym_name = "x_4_cons_cons_lock_0"} loc(#loc10)
    %x_5_cons_buff_0 = aie.buffer(%tile_1_3) {address = 43520 : i32, sym_name = "x_5_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_5_cons_prod_lock_0 = aie.lock(%tile_1_3, 2) {init = 1 : i32, sym_name = "x_5_cons_prod_lock_0"} loc(#loc10)
    %x_5_cons_cons_lock_0 = aie.lock(%tile_1_3, 3) {init = 0 : i32, sym_name = "x_5_cons_cons_lock_0"} loc(#loc10)
    %x_6_cons_buff_0 = aie.buffer(%tile_1_4) {address = 43520 : i32, sym_name = "x_6_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_6_cons_prod_lock_0 = aie.lock(%tile_1_4, 2) {init = 1 : i32, sym_name = "x_6_cons_prod_lock_0"} loc(#loc10)
    %x_6_cons_cons_lock_0 = aie.lock(%tile_1_4, 3) {init = 0 : i32, sym_name = "x_6_cons_cons_lock_0"} loc(#loc10)
    %x_7_cons_buff_0 = aie.buffer(%tile_1_5) {address = 43520 : i32, sym_name = "x_7_cons_buff_0"} : memref<2048xbf16>  loc(#loc10)
    %x_7_cons_prod_lock_0 = aie.lock(%tile_1_5, 2) {init = 1 : i32, sym_name = "x_7_cons_prod_lock_0"} loc(#loc10)
    %x_7_cons_cons_lock_0 = aie.lock(%tile_1_5, 3) {init = 0 : i32, sym_name = "x_7_cons_cons_lock_0"} loc(#loc10)
    %x_prod_lock_0 = aie.lock(%shim_noc_tile_4_0, 0) {init = 0 : i32, sym_name = "x_prod_lock_0"} loc(#loc10)
    %x_cons_lock_0 = aie.lock(%shim_noc_tile_4_0, 1) {init = 0 : i32, sym_name = "x_cons_lock_0"} loc(#loc10)
    %w7_cons_buff_0 = aie.buffer(%tile_1_5) {address = 4096 : i32, sym_name = "w7_cons_buff_0"} : memref<17408xui8>  loc(#loc11)
    %w7_cons_buff_1 = aie.buffer(%tile_1_5) {address = 21504 : i32, sym_name = "w7_cons_buff_1"} : memref<17408xui8>  loc(#loc11)
    %w7_cons_prod_lock_0 = aie.lock(%tile_1_5, 4) {init = 2 : i32, sym_name = "w7_cons_prod_lock_0"} loc(#loc11)
    %w7_cons_cons_lock_0 = aie.lock(%tile_1_5, 5) {init = 0 : i32, sym_name = "w7_cons_cons_lock_0"} loc(#loc11)
    %w7_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 4) {init = 0 : i32, sym_name = "w7_prod_lock_0"} loc(#loc11)
    %w7_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 5) {init = 0 : i32, sym_name = "w7_cons_lock_0"} loc(#loc11)
    %w6_cons_buff_0 = aie.buffer(%tile_1_4) {address = 4096 : i32, sym_name = "w6_cons_buff_0"} : memref<17408xui8>  loc(#loc12)
    %w6_cons_buff_1 = aie.buffer(%tile_1_4) {address = 21504 : i32, sym_name = "w6_cons_buff_1"} : memref<17408xui8>  loc(#loc12)
    %w6_cons_prod_lock_0 = aie.lock(%tile_1_4, 4) {init = 2 : i32, sym_name = "w6_cons_prod_lock_0"} loc(#loc12)
    %w6_cons_cons_lock_0 = aie.lock(%tile_1_4, 5) {init = 0 : i32, sym_name = "w6_cons_cons_lock_0"} loc(#loc12)
    %w6_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 6) {init = 0 : i32, sym_name = "w6_prod_lock_0"} loc(#loc12)
    %w6_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 7) {init = 0 : i32, sym_name = "w6_cons_lock_0"} loc(#loc12)
    %w5_cons_buff_0 = aie.buffer(%tile_1_3) {address = 4096 : i32, sym_name = "w5_cons_buff_0"} : memref<17408xui8>  loc(#loc13)
    %w5_cons_buff_1 = aie.buffer(%tile_1_3) {address = 21504 : i32, sym_name = "w5_cons_buff_1"} : memref<17408xui8>  loc(#loc13)
    %w5_cons_prod_lock_0 = aie.lock(%tile_1_3, 4) {init = 2 : i32, sym_name = "w5_cons_prod_lock_0"} loc(#loc13)
    %w5_cons_cons_lock_0 = aie.lock(%tile_1_3, 5) {init = 0 : i32, sym_name = "w5_cons_cons_lock_0"} loc(#loc13)
    %w5_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 4) {init = 0 : i32, sym_name = "w5_prod_lock_0"} loc(#loc13)
    %w5_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 5) {init = 0 : i32, sym_name = "w5_cons_lock_0"} loc(#loc13)
    %w4_cons_buff_0 = aie.buffer(%tile_1_2) {address = 4096 : i32, sym_name = "w4_cons_buff_0"} : memref<17408xui8>  loc(#loc14)
    %w4_cons_buff_1 = aie.buffer(%tile_1_2) {address = 21504 : i32, sym_name = "w4_cons_buff_1"} : memref<17408xui8>  loc(#loc14)
    %w4_cons_prod_lock_0 = aie.lock(%tile_1_2, 4) {init = 2 : i32, sym_name = "w4_cons_prod_lock_0"} loc(#loc14)
    %w4_cons_cons_lock_0 = aie.lock(%tile_1_2, 5) {init = 0 : i32, sym_name = "w4_cons_cons_lock_0"} loc(#loc14)
    %w4_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 6) {init = 0 : i32, sym_name = "w4_prod_lock_0"} loc(#loc14)
    %w4_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 7) {init = 0 : i32, sym_name = "w4_cons_lock_0"} loc(#loc14)
    %w3_cons_buff_0 = aie.buffer(%tile_0_5) {address = 4096 : i32, sym_name = "w3_cons_buff_0"} : memref<17408xui8>  loc(#loc15)
    %w3_cons_buff_1 = aie.buffer(%tile_0_5) {address = 21504 : i32, sym_name = "w3_cons_buff_1"} : memref<17408xui8>  loc(#loc15)
    %w3_cons_prod_lock_0 = aie.lock(%tile_0_5, 4) {init = 2 : i32, sym_name = "w3_cons_prod_lock_0"} loc(#loc15)
    %w3_cons_cons_lock_0 = aie.lock(%tile_0_5, 5) {init = 0 : i32, sym_name = "w3_cons_cons_lock_0"} loc(#loc15)
    %w3_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 4) {init = 0 : i32, sym_name = "w3_prod_lock_0"} loc(#loc15)
    %w3_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 5) {init = 0 : i32, sym_name = "w3_cons_lock_0"} loc(#loc15)
    %w2_cons_buff_0 = aie.buffer(%tile_0_4) {address = 4096 : i32, sym_name = "w2_cons_buff_0"} : memref<17408xui8>  loc(#loc16)
    %w2_cons_buff_1 = aie.buffer(%tile_0_4) {address = 21504 : i32, sym_name = "w2_cons_buff_1"} : memref<17408xui8>  loc(#loc16)
    %w2_cons_prod_lock_0 = aie.lock(%tile_0_4, 4) {init = 2 : i32, sym_name = "w2_cons_prod_lock_0"} loc(#loc16)
    %w2_cons_cons_lock_0 = aie.lock(%tile_0_4, 5) {init = 0 : i32, sym_name = "w2_cons_cons_lock_0"} loc(#loc16)
    %w2_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 6) {init = 0 : i32, sym_name = "w2_prod_lock_0"} loc(#loc16)
    %w2_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 7) {init = 0 : i32, sym_name = "w2_cons_lock_0"} loc(#loc16)
    %w1_cons_buff_0 = aie.buffer(%tile_0_3) {address = 4096 : i32, sym_name = "w1_cons_buff_0"} : memref<17408xui8>  loc(#loc17)
    %w1_cons_buff_1 = aie.buffer(%tile_0_3) {address = 21504 : i32, sym_name = "w1_cons_buff_1"} : memref<17408xui8>  loc(#loc17)
    %w1_cons_prod_lock_0 = aie.lock(%tile_0_3, 4) {init = 2 : i32, sym_name = "w1_cons_prod_lock_0"} loc(#loc17)
    %w1_cons_cons_lock_0 = aie.lock(%tile_0_3, 5) {init = 0 : i32, sym_name = "w1_cons_cons_lock_0"} loc(#loc17)
    %w1_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 4) {init = 0 : i32, sym_name = "w1_prod_lock_0"} loc(#loc17)
    %w1_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 5) {init = 0 : i32, sym_name = "w1_cons_lock_0"} loc(#loc17)
    %w0_cons_buff_0 = aie.buffer(%tile_0_2) {address = 4096 : i32, sym_name = "w0_cons_buff_0"} : memref<17408xui8>  loc(#loc18)
    %w0_cons_buff_1 = aie.buffer(%tile_0_2) {address = 21504 : i32, sym_name = "w0_cons_buff_1"} : memref<17408xui8>  loc(#loc18)
    %w0_cons_prod_lock_0 = aie.lock(%tile_0_2, 4) {init = 2 : i32, sym_name = "w0_cons_prod_lock_0"} loc(#loc18)
    %w0_cons_cons_lock_0 = aie.lock(%tile_0_2, 5) {init = 0 : i32, sym_name = "w0_cons_cons_lock_0"} loc(#loc18)
    %w0_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 6) {init = 0 : i32, sym_name = "w0_prod_lock_0"} loc(#loc18)
    %w0_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 7) {init = 0 : i32, sym_name = "w0_cons_lock_0"} loc(#loc18)
    aie.flow(%shim_noc_tile_0_0, DMA : 0, %tile_0_2, DMA : 0) loc(#loc18)
    aie.flow(%shim_noc_tile_0_0, DMA : 1, %tile_0_3, DMA : 0) loc(#loc17)
    aie.flow(%shim_noc_tile_1_0, DMA : 0, %tile_0_4, DMA : 0) loc(#loc16)
    aie.flow(%shim_noc_tile_1_0, DMA : 1, %tile_0_5, DMA : 0) loc(#loc15)
    aie.flow(%shim_noc_tile_2_0, DMA : 0, %tile_1_2, DMA : 0) loc(#loc14)
    aie.flow(%shim_noc_tile_2_0, DMA : 1, %tile_1_3, DMA : 0) loc(#loc13)
    aie.flow(%shim_noc_tile_3_0, DMA : 0, %tile_1_4, DMA : 0) loc(#loc12)
    aie.flow(%shim_noc_tile_3_0, DMA : 1, %tile_1_5, DMA : 0) loc(#loc11)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_1_5, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_1_4, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_1_3, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_1_2, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_0_5, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_0_4, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_0_3, DMA : 1) loc(#loc10)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %tile_0_2, DMA : 1) loc(#loc10)
    aie.flow(%tile_0_2, DMA : 0, %shim_noc_tile_0_0, DMA : 0) loc(#loc9)
    aie.flow(%tile_0_3, DMA : 0, %shim_noc_tile_0_0, DMA : 1) loc(#loc8)
    aie.flow(%tile_0_4, DMA : 0, %shim_noc_tile_1_0, DMA : 0) loc(#loc7)
    aie.flow(%tile_0_5, DMA : 0, %shim_noc_tile_1_0, DMA : 1) loc(#loc6)
    aie.flow(%tile_1_2, DMA : 0, %shim_noc_tile_2_0, DMA : 0) loc(#loc5)
    aie.flow(%tile_1_3, DMA : 0, %shim_noc_tile_2_0, DMA : 1) loc(#loc4)
    aie.flow(%tile_1_4, DMA : 0, %shim_noc_tile_3_0, DMA : 0) loc(#loc3)
    aie.flow(%tile_1_5, DMA : 0, %shim_noc_tile_3_0, DMA : 1) loc(#loc2)
    %tab0 = aie.buffer(%tile_0_2) {address = 38912 : i32, sym_name = "tab0"} : memref<4608xui8>  loc(#loc19)
    func.func private @gemv_q4_prep_k2048(memref<2048xbf16>, memref<4608xui8>) attributes {link_with = "gemv_q4_prep_k2048.o"} loc(#loc20)
    func.func private @lm_head_q8_group(memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) attributes {link_with = "lm_head_q8_group.o"} loc(#loc21)
    %tab1 = aie.buffer(%tile_0_3) {address = 38912 : i32, sym_name = "tab1"} : memref<4608xui8>  loc(#loc22)
    %tab2 = aie.buffer(%tile_0_4) {address = 38912 : i32, sym_name = "tab2"} : memref<4608xui8>  loc(#loc23)
    %tab3 = aie.buffer(%tile_0_5) {address = 38912 : i32, sym_name = "tab3"} : memref<4608xui8>  loc(#loc24)
    %tab4 = aie.buffer(%tile_1_2) {address = 38912 : i32, sym_name = "tab4"} : memref<4608xui8>  loc(#loc25)
    %tab5 = aie.buffer(%tile_1_3) {address = 38912 : i32, sym_name = "tab5"} : memref<4608xui8>  loc(#loc26)
    %tab6 = aie.buffer(%tile_1_4) {address = 38912 : i32, sym_name = "tab6"} : memref<4608xui8>  loc(#loc27)
    %tab7 = aie.buffer(%tile_1_5) {address = 38912 : i32, sym_name = "tab7"} : memref<4608xui8>  loc(#loc28)
    %core_0_2 = aie.core(%tile_0_2) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c243 = arith.constant 243 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc31)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":59:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":55:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":55:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc31)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc31)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc33)
      func.call @gemv_q4_prep_k2048(%x_0_cons_buff_0, %tab0) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc34)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc35)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":66:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":55:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":55:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c243 : index loc(#loc35)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc35)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      %8 = arith.index_cast %5 : i32 to index loc(#loc38)
      %9 = arith.index_cast %8 : index to i64 loc(#loc38)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc38)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y0_buff_0 : memref<128xf32>) loc(#loc38)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y0_buff_1 : memref<128xf32>) loc(#loc38)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y0_buff_0 : memref<128xf32>) loc(#loc38)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":68:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc39)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":72:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":55:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc39)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc39)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      %14 = arith.index_cast %12 : i32 to index loc(#loc42)
      %15 = arith.index_cast %14 : index to i64 loc(#loc42)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc42)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w0_cons_buff_0 : memref<17408xui8>) loc(#loc42)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w0_cons_buff_1 : memref<17408xui8>) loc(#loc42)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w0_cons_buff_0 : memref<17408xui8>) loc(#loc42)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":74:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc43)
      func.call @lm_head_q8_group(%16, %tab0, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc44)
      aie.use_lock(%w0_cons_prod_lock_0, Release, %c1_i32) loc(#loc45)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc45)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc45)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc45)
      %21 = arith.addi %11, %c1 : index loc(#loc39)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc39)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y0_cons_lock_0, Release, %c1_i32) loc(#loc46)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc46)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc46)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc46)
      %25 = arith.addi %4, %c1 : index loc(#loc35)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc35)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc47)
      %26 = arith.addi %0, %c1 : index loc(#loc31)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc31)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc48)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc29)
    %core_0_3 = aie.core(%tile_0_3) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c243 = arith.constant 243 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc50)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":89:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":85:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":85:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc50)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc50)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      func.call @gemv_q4_prep_k2048(%x_1_cons_buff_0, %tab1) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc53)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc54)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":96:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":85:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":85:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c243 : index loc(#loc54)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc54)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      %8 = arith.index_cast %5 : i32 to index loc(#loc57)
      %9 = arith.index_cast %8 : index to i64 loc(#loc57)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc57)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y1_buff_0 : memref<128xf32>) loc(#loc57)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y1_buff_1 : memref<128xf32>) loc(#loc57)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y1_buff_0 : memref<128xf32>) loc(#loc57)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":98:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc58)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":102:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":85:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc58)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc58)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      %14 = arith.index_cast %12 : i32 to index loc(#loc61)
      %15 = arith.index_cast %14 : index to i64 loc(#loc61)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc61)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w1_cons_buff_0 : memref<17408xui8>) loc(#loc61)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w1_cons_buff_1 : memref<17408xui8>) loc(#loc61)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w1_cons_buff_0 : memref<17408xui8>) loc(#loc61)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":104:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc62)
      func.call @lm_head_q8_group(%16, %tab1, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc63)
      aie.use_lock(%w1_cons_prod_lock_0, Release, %c1_i32) loc(#loc64)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc64)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc64)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc64)
      %21 = arith.addi %11, %c1 : index loc(#loc58)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc58)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y1_cons_lock_0, Release, %c1_i32) loc(#loc65)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc65)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc65)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc65)
      %25 = arith.addi %4, %c1 : index loc(#loc54)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc54)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc66)
      %26 = arith.addi %0, %c1 : index loc(#loc50)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc50)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc67)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc49)
    %core_0_4 = aie.core(%tile_0_4) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c243 = arith.constant 243 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc69)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":119:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":115:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":115:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc69)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc69)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc71)
      func.call @gemv_q4_prep_k2048(%x_2_cons_buff_0, %tab2) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc72)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc73)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":126:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":115:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":115:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c243 : index loc(#loc73)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc73)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc75)
      %8 = arith.index_cast %5 : i32 to index loc(#loc76)
      %9 = arith.index_cast %8 : index to i64 loc(#loc76)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc76)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y2_buff_0 : memref<128xf32>) loc(#loc76)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y2_buff_1 : memref<128xf32>) loc(#loc76)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y2_buff_0 : memref<128xf32>) loc(#loc76)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":128:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc77)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":132:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":115:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc77)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc77)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc79)
      %14 = arith.index_cast %12 : i32 to index loc(#loc80)
      %15 = arith.index_cast %14 : index to i64 loc(#loc80)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc80)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w2_cons_buff_0 : memref<17408xui8>) loc(#loc80)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w2_cons_buff_1 : memref<17408xui8>) loc(#loc80)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w2_cons_buff_0 : memref<17408xui8>) loc(#loc80)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":134:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc81)
      func.call @lm_head_q8_group(%16, %tab2, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc82)
      aie.use_lock(%w2_cons_prod_lock_0, Release, %c1_i32) loc(#loc83)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc83)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc83)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc83)
      %21 = arith.addi %11, %c1 : index loc(#loc77)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc77)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y2_cons_lock_0, Release, %c1_i32) loc(#loc84)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc84)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc84)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc84)
      %25 = arith.addi %4, %c1 : index loc(#loc73)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc73)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc85)
      %26 = arith.addi %0, %c1 : index loc(#loc69)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc69)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc86)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc68)
    %core_0_5 = aie.core(%tile_0_5) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c243 = arith.constant 243 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc88)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":149:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":145:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":145:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc88)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc88)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc90)
      func.call @gemv_q4_prep_k2048(%x_3_cons_buff_0, %tab3) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc91)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc92)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":156:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":145:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":145:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c243 : index loc(#loc92)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc92)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc94)
      %8 = arith.index_cast %5 : i32 to index loc(#loc95)
      %9 = arith.index_cast %8 : index to i64 loc(#loc95)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc95)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y3_buff_0 : memref<128xf32>) loc(#loc95)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y3_buff_1 : memref<128xf32>) loc(#loc95)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y3_buff_0 : memref<128xf32>) loc(#loc95)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":158:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc96)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":162:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":145:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc96)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc96)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc98)
      %14 = arith.index_cast %12 : i32 to index loc(#loc99)
      %15 = arith.index_cast %14 : index to i64 loc(#loc99)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc99)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w3_cons_buff_0 : memref<17408xui8>) loc(#loc99)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w3_cons_buff_1 : memref<17408xui8>) loc(#loc99)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w3_cons_buff_0 : memref<17408xui8>) loc(#loc99)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":164:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc100)
      func.call @lm_head_q8_group(%16, %tab3, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc101)
      aie.use_lock(%w3_cons_prod_lock_0, Release, %c1_i32) loc(#loc102)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc102)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc102)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc102)
      %21 = arith.addi %11, %c1 : index loc(#loc96)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc96)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y3_cons_lock_0, Release, %c1_i32) loc(#loc103)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc103)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc103)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc103)
      %25 = arith.addi %4, %c1 : index loc(#loc92)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc92)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc104)
      %26 = arith.addi %0, %c1 : index loc(#loc88)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc88)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc105)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc87)
    %core_1_2 = aie.core(%tile_1_2) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c242 = arith.constant 242 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc107)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":179:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":175:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":175:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc107)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc107)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc109)
      func.call @gemv_q4_prep_k2048(%x_4_cons_buff_0, %tab4) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc110)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc111)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":186:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":175:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":175:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c242 : index loc(#loc111)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc111)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y4_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc113)
      %8 = arith.index_cast %5 : i32 to index loc(#loc114)
      %9 = arith.index_cast %8 : index to i64 loc(#loc114)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc114)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y4_buff_0 : memref<128xf32>) loc(#loc114)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y4_buff_1 : memref<128xf32>) loc(#loc114)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y4_buff_0 : memref<128xf32>) loc(#loc114)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":188:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc115)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":192:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":175:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc115)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc115)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc117)
      %14 = arith.index_cast %12 : i32 to index loc(#loc118)
      %15 = arith.index_cast %14 : index to i64 loc(#loc118)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc118)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w4_cons_buff_0 : memref<17408xui8>) loc(#loc118)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w4_cons_buff_1 : memref<17408xui8>) loc(#loc118)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w4_cons_buff_0 : memref<17408xui8>) loc(#loc118)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":194:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc119)
      func.call @lm_head_q8_group(%16, %tab4, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc120)
      aie.use_lock(%w4_cons_prod_lock_0, Release, %c1_i32) loc(#loc121)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc121)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc121)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc121)
      %21 = arith.addi %11, %c1 : index loc(#loc115)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc115)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y4_cons_lock_0, Release, %c1_i32) loc(#loc122)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc122)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc122)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc122)
      %25 = arith.addi %4, %c1 : index loc(#loc111)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc111)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc123)
      %26 = arith.addi %0, %c1 : index loc(#loc107)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc107)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc124)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc106)
    %core_1_3 = aie.core(%tile_1_3) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c242 = arith.constant 242 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc126)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":209:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":205:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":205:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc126)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc126)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc128)
      func.call @gemv_q4_prep_k2048(%x_5_cons_buff_0, %tab5) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc129)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc130)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":216:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":205:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":205:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c242 : index loc(#loc130)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc130)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y5_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc132)
      %8 = arith.index_cast %5 : i32 to index loc(#loc133)
      %9 = arith.index_cast %8 : index to i64 loc(#loc133)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc133)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y5_buff_0 : memref<128xf32>) loc(#loc133)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y5_buff_1 : memref<128xf32>) loc(#loc133)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y5_buff_0 : memref<128xf32>) loc(#loc133)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":218:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc134)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":222:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":205:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc134)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc134)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc136)
      %14 = arith.index_cast %12 : i32 to index loc(#loc137)
      %15 = arith.index_cast %14 : index to i64 loc(#loc137)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc137)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w5_cons_buff_0 : memref<17408xui8>) loc(#loc137)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w5_cons_buff_1 : memref<17408xui8>) loc(#loc137)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w5_cons_buff_0 : memref<17408xui8>) loc(#loc137)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":224:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc138)
      func.call @lm_head_q8_group(%16, %tab5, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc139)
      aie.use_lock(%w5_cons_prod_lock_0, Release, %c1_i32) loc(#loc140)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc140)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc140)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc140)
      %21 = arith.addi %11, %c1 : index loc(#loc134)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc134)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y5_cons_lock_0, Release, %c1_i32) loc(#loc141)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc141)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc141)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc141)
      %25 = arith.addi %4, %c1 : index loc(#loc130)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc130)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc142)
      %26 = arith.addi %0, %c1 : index loc(#loc126)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc126)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc143)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc125)
    %core_1_4 = aie.core(%tile_1_4) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c242 = arith.constant 242 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc145)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":239:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":235:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":235:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc145)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc145)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc147)
      func.call @gemv_q4_prep_k2048(%x_6_cons_buff_0, %tab6) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc148)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc149)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":246:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":235:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":235:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c242 : index loc(#loc149)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc149)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y6_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc151)
      %8 = arith.index_cast %5 : i32 to index loc(#loc152)
      %9 = arith.index_cast %8 : index to i64 loc(#loc152)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc152)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y6_buff_0 : memref<128xf32>) loc(#loc152)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y6_buff_1 : memref<128xf32>) loc(#loc152)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y6_buff_0 : memref<128xf32>) loc(#loc152)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":248:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc153)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":252:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":235:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc153)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc153)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc155)
      %14 = arith.index_cast %12 : i32 to index loc(#loc156)
      %15 = arith.index_cast %14 : index to i64 loc(#loc156)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc156)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w6_cons_buff_0 : memref<17408xui8>) loc(#loc156)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w6_cons_buff_1 : memref<17408xui8>) loc(#loc156)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w6_cons_buff_0 : memref<17408xui8>) loc(#loc156)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":254:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc157)
      func.call @lm_head_q8_group(%16, %tab6, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc158)
      aie.use_lock(%w6_cons_prod_lock_0, Release, %c1_i32) loc(#loc159)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc159)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc159)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc159)
      %21 = arith.addi %11, %c1 : index loc(#loc153)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc153)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y6_cons_lock_0, Release, %c1_i32) loc(#loc160)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc160)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc160)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc160)
      %25 = arith.addi %4, %c1 : index loc(#loc149)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc149)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc161)
      %26 = arith.addi %0, %c1 : index loc(#loc145)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc145)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc162)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc144)
    %core_1_5 = aie.core(%tile_1_5) {
      %c1 = arith.constant 1 : index loc(#loc30)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc30)
      %c0 = arith.constant 0 : index loc(#loc30)
      %c242 = arith.constant 242 : index loc(#loc30)
      %c16 = arith.constant 16 : index loc(#loc30)
      %c0_i32 = arith.constant 0 : i32 loc(#loc30)
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %c2_i32 = arith.constant 2 : i32 loc(#loc30)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc164)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":269:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":265:10), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":265:10)):  // 2 preds: ^bb0, ^bb16
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc164)
      cf.cond_br %3, ^bb2, ^bb17 loc(#loc164)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%x_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc166)
      func.call @gemv_q4_prep_k2048(%x_7_cons_buff_0, %tab7) : (memref<2048xbf16>, memref<4608xui8>) -> () loc(#loc167)
      cf.br ^bb3(%c0, %1, %2 : index, i32, i32) loc(#loc168)
    ^bb3(%4: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":276:17), %5: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":265:10), %6: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":265:10)):  // 2 preds: ^bb2, ^bb15
      %7 = arith.cmpi slt, %4, %c242 : index loc(#loc168)
      cf.cond_br %7, ^bb4, ^bb16 loc(#loc168)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%y7_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc170)
      %8 = arith.index_cast %5 : i32 to index loc(#loc171)
      %9 = arith.index_cast %8 : index to i64 loc(#loc171)
      cf.switch %9 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc171)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%y7_buff_0 : memref<128xf32>) loc(#loc171)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%y7_buff_1 : memref<128xf32>) loc(#loc171)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%y7_buff_0 : memref<128xf32>) loc(#loc171)
    ^bb8(%10: memref<128xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":278:17)):  // 3 preds: ^bb5, ^bb6, ^bb7
      cf.br ^bb9(%c0, %6 : index, i32) loc(#loc172)
    ^bb9(%11: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":282:19), %12: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":265:10)):  // 2 preds: ^bb8, ^bb14
      %13 = arith.cmpi slt, %11, %c16 : index loc(#loc172)
      cf.cond_br %13, ^bb10, ^bb15 loc(#loc172)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%w7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc174)
      %14 = arith.index_cast %12 : i32 to index loc(#loc175)
      %15 = arith.index_cast %14 : index to i64 loc(#loc175)
      cf.switch %15 : i64, [
        default: ^bb13,
        0: ^bb11,
        1: ^bb12
      ] loc(#loc175)
    ^bb11:  // pred: ^bb10
      cf.br ^bb14(%w7_cons_buff_0 : memref<17408xui8>) loc(#loc175)
    ^bb12:  // pred: ^bb10
      cf.br ^bb14(%w7_cons_buff_1 : memref<17408xui8>) loc(#loc175)
    ^bb13:  // pred: ^bb10
      cf.br ^bb14(%w7_cons_buff_0 : memref<17408xui8>) loc(#loc175)
    ^bb14(%16: memref<17408xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":284:19)):  // 3 preds: ^bb11, ^bb12, ^bb13
      %17 = arith.index_cast %11 : index to i32 loc(#loc176)
      func.call @lm_head_q8_group(%16, %tab7, %10, %17) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> () loc(#loc177)
      aie.use_lock(%w7_cons_prod_lock_0, Release, %c1_i32) loc(#loc178)
      %18 = arith.addi %12, %c1_i32 : i32 loc(#loc178)
      %19 = arith.cmpi sge, %18, %c2_i32 : i32 loc(#loc178)
      %20 = arith.select %19, %c0_i32, %18 : i32 loc(#loc178)
      %21 = arith.addi %11, %c1 : index loc(#loc172)
      cf.br ^bb9(%21, %20 : index, i32) loc(#loc172)
    ^bb15:  // pred: ^bb9
      aie.use_lock(%y7_cons_lock_0, Release, %c1_i32) loc(#loc179)
      %22 = arith.addi %5, %c1_i32 : i32 loc(#loc179)
      %23 = arith.cmpi sge, %22, %c2_i32 : i32 loc(#loc179)
      %24 = arith.select %23, %c0_i32, %22 : i32 loc(#loc179)
      %25 = arith.addi %4, %c1 : index loc(#loc168)
      cf.br ^bb3(%25, %24, %12 : index, i32, i32) loc(#loc168)
    ^bb16:  // pred: ^bb3
      aie.use_lock(%x_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc180)
      %26 = arith.addi %0, %c1 : index loc(#loc164)
      cf.br ^bb1(%26, %5, %6 : index, i32, i32) loc(#loc164)
    ^bb17:  // pred: ^bb1
      aie.end loc(#loc181)
    } {link_files = ["gemv_q4_prep_k2048.o", "lm_head_q8_group.o"], stack_size = 4096 : i32} loc(#loc163)
    aie.runtime_sequence(%arg0: memref<540344320xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:26), %arg1: memref<2048xbf16> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:56), %arg2: memref<248320xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:82)) {
      %0 = aiex.dma_configure_task_for @x_shim_alloc {
        aie.dma_bd(%arg1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1]) loc(#loc187)
        aie.end loc(#loc188)
      } loc(#loc186)
      aiex.dma_start_task(%0) loc(#loc189)
      %1 = aiex.dma_configure_task_for @w0_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 0 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1]) loc(#loc191)
        aie.end loc(#loc192)
      } loc(#loc190)
      aiex.dma_start_task(%1) loc(#loc193)
      %2 = aiex.dma_configure_task_for @y0_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 0 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1]) loc(#loc195)
        aie.end loc(#loc196)
      } {issue_token = true} loc(#loc194)
      aiex.dma_start_task(%2) loc(#loc197)
      %3 = aiex.dma_configure_task_for @w1_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 67682304 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1]) loc(#loc199)
        aie.end loc(#loc200)
      } loc(#loc198)
      aiex.dma_start_task(%3) loc(#loc201)
      %4 = aiex.dma_configure_task_for @y1_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 31104 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1]) loc(#loc203)
        aie.end loc(#loc204)
      } {issue_token = true} loc(#loc202)
      aiex.dma_start_task(%4) loc(#loc205)
      %5 = aiex.dma_configure_task_for @w2_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 135364608 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1]) loc(#loc207)
        aie.end loc(#loc208)
      } loc(#loc206)
      aiex.dma_start_task(%5) loc(#loc209)
      %6 = aiex.dma_configure_task_for @y2_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 62208 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1]) loc(#loc211)
        aie.end loc(#loc212)
      } {issue_token = true} loc(#loc210)
      aiex.dma_start_task(%6) loc(#loc213)
      %7 = aiex.dma_configure_task_for @w3_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 203046912 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1]) loc(#loc215)
        aie.end loc(#loc216)
      } loc(#loc214)
      aiex.dma_start_task(%7) loc(#loc217)
      %8 = aiex.dma_configure_task_for @y3_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 93312 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1]) loc(#loc219)
        aie.end loc(#loc220)
      } {issue_token = true} loc(#loc218)
      aiex.dma_start_task(%8) loc(#loc221)
      %9 = aiex.dma_configure_task_for @w4_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 270729216 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1]) loc(#loc223)
        aie.end loc(#loc224)
      } loc(#loc222)
      aiex.dma_start_task(%9) loc(#loc225)
      %10 = aiex.dma_configure_task_for @y4_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 124416 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1]) loc(#loc227)
        aie.end loc(#loc228)
      } {issue_token = true} loc(#loc226)
      aiex.dma_start_task(%10) loc(#loc229)
      %11 = aiex.dma_configure_task_for @w5_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 338132992 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1]) loc(#loc231)
        aie.end loc(#loc232)
      } loc(#loc230)
      aiex.dma_start_task(%11) loc(#loc233)
      %12 = aiex.dma_configure_task_for @y5_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 155392 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1]) loc(#loc235)
        aie.end loc(#loc236)
      } {issue_token = true} loc(#loc234)
      aiex.dma_start_task(%12) loc(#loc237)
      %13 = aiex.dma_configure_task_for @w6_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 405536768 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1]) loc(#loc239)
        aie.end loc(#loc240)
      } loc(#loc238)
      aiex.dma_start_task(%13) loc(#loc241)
      %14 = aiex.dma_configure_task_for @y6_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 186368 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1]) loc(#loc243)
        aie.end loc(#loc244)
      } {issue_token = true} loc(#loc242)
      aiex.dma_start_task(%14) loc(#loc245)
      %15 = aiex.dma_configure_task_for @w7_shim_alloc {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 472940544 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1]) loc(#loc247)
        aie.end loc(#loc248)
      } loc(#loc246)
      aiex.dma_start_task(%15) loc(#loc249)
      %16 = aiex.dma_configure_task_for @y7_shim_alloc {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 217344 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1]) loc(#loc251)
        aie.end loc(#loc252)
      } {issue_token = true} loc(#loc250)
      aiex.dma_start_task(%16) loc(#loc253)
      aiex.dma_await_task(%2) loc(#loc254)
      aiex.dma_await_task(%4) loc(#loc255)
      aiex.dma_await_task(%6) loc(#loc256)
      aiex.dma_await_task(%8) loc(#loc257)
      aiex.dma_await_task(%10) loc(#loc258)
      aiex.dma_await_task(%12) loc(#loc259)
      aiex.dma_await_task(%14) loc(#loc260)
      aiex.dma_await_task(%16) loc(#loc261)
      aiex.dma_free_task(%0) loc(#loc262)
      aiex.dma_free_task(%1) loc(#loc263)
      aiex.dma_free_task(%2) loc(#loc264)
      aiex.dma_free_task(%3) loc(#loc265)
      aiex.dma_free_task(%4) loc(#loc266)
      aiex.dma_free_task(%5) loc(#loc267)
      aiex.dma_free_task(%6) loc(#loc268)
      aiex.dma_free_task(%7) loc(#loc269)
      aiex.dma_free_task(%8) loc(#loc270)
      aiex.dma_free_task(%9) loc(#loc271)
      aiex.dma_free_task(%10) loc(#loc272)
      aiex.dma_free_task(%11) loc(#loc273)
      aiex.dma_free_task(%12) loc(#loc274)
      aiex.dma_free_task(%13) loc(#loc275)
      aiex.dma_free_task(%14) loc(#loc276)
      aiex.dma_free_task(%15) loc(#loc277)
      aiex.dma_free_task(%16) loc(#loc278)
    } loc(#loc182)
    aie.shim_dma_allocation @w0_shim_alloc(%shim_noc_tile_0_0, MM2S, 0) loc(#loc18)
    %mem_0_2 = aie.mem(%tile_0_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc18)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc18)
      aie.dma_bd(%w0_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc18)
      aie.use_lock(%w0_cons_cons_lock_0, Release, %c1_i32) loc(#loc18)
      aie.next_bd ^bb2 loc(#loc18)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc18)
      aie.dma_bd(%w0_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc18)
      aie.use_lock(%w0_cons_cons_lock_0, Release, %c1_i32) loc(#loc18)
      aie.next_bd ^bb1 loc(#loc18)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc9)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc9)
      aie.dma_bd(%y0_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc9)
      aie.use_lock(%y0_prod_lock_0, Release, %c1_i32) loc(#loc9)
      aie.next_bd ^bb7 loc(#loc9)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc9)
      aie.dma_bd(%y0_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc9)
      aie.use_lock(%y0_prod_lock_0, Release, %c1_i32) loc(#loc9)
      aie.next_bd ^bb6 loc(#loc9)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc18)
    } loc(#loc18)
    aie.shim_dma_allocation @w1_shim_alloc(%shim_noc_tile_0_0, MM2S, 1) loc(#loc17)
    %mem_0_3 = aie.mem(%tile_0_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc17)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc17)
      aie.dma_bd(%w1_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc17)
      aie.use_lock(%w1_cons_cons_lock_0, Release, %c1_i32) loc(#loc17)
      aie.next_bd ^bb2 loc(#loc17)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc17)
      aie.dma_bd(%w1_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc17)
      aie.use_lock(%w1_cons_cons_lock_0, Release, %c1_i32) loc(#loc17)
      aie.next_bd ^bb1 loc(#loc17)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc8)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc8)
      aie.dma_bd(%y1_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc8)
      aie.use_lock(%y1_prod_lock_0, Release, %c1_i32) loc(#loc8)
      aie.next_bd ^bb7 loc(#loc8)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc8)
      aie.dma_bd(%y1_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc8)
      aie.use_lock(%y1_prod_lock_0, Release, %c1_i32) loc(#loc8)
      aie.next_bd ^bb6 loc(#loc8)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc17)
    } loc(#loc17)
    aie.shim_dma_allocation @w2_shim_alloc(%shim_noc_tile_1_0, MM2S, 0) loc(#loc16)
    %mem_0_4 = aie.mem(%tile_0_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc16)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%w2_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc16)
      aie.use_lock(%w2_cons_cons_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb2 loc(#loc16)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%w2_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc16)
      aie.use_lock(%w2_cons_cons_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb1 loc(#loc16)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc7)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc7)
      aie.dma_bd(%y2_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc7)
      aie.use_lock(%y2_prod_lock_0, Release, %c1_i32) loc(#loc7)
      aie.next_bd ^bb7 loc(#loc7)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc7)
      aie.dma_bd(%y2_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc7)
      aie.use_lock(%y2_prod_lock_0, Release, %c1_i32) loc(#loc7)
      aie.next_bd ^bb6 loc(#loc7)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc16)
    } loc(#loc16)
    aie.shim_dma_allocation @w3_shim_alloc(%shim_noc_tile_1_0, MM2S, 1) loc(#loc15)
    %mem_0_5 = aie.mem(%tile_0_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc15)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc15)
      aie.dma_bd(%w3_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc15)
      aie.use_lock(%w3_cons_cons_lock_0, Release, %c1_i32) loc(#loc15)
      aie.next_bd ^bb2 loc(#loc15)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc15)
      aie.dma_bd(%w3_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc15)
      aie.use_lock(%w3_cons_cons_lock_0, Release, %c1_i32) loc(#loc15)
      aie.next_bd ^bb1 loc(#loc15)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc6)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%y3_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc6)
      aie.use_lock(%y3_prod_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb7 loc(#loc6)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%y3_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc6)
      aie.use_lock(%y3_prod_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb6 loc(#loc6)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc15)
    } loc(#loc15)
    aie.shim_dma_allocation @w4_shim_alloc(%shim_noc_tile_2_0, MM2S, 0) loc(#loc14)
    %mem_1_2 = aie.mem(%tile_1_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc14)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc14)
      aie.dma_bd(%w4_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc14)
      aie.use_lock(%w4_cons_cons_lock_0, Release, %c1_i32) loc(#loc14)
      aie.next_bd ^bb2 loc(#loc14)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc14)
      aie.dma_bd(%w4_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc14)
      aie.use_lock(%w4_cons_cons_lock_0, Release, %c1_i32) loc(#loc14)
      aie.next_bd ^bb1 loc(#loc14)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_4_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc5)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y4_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc5)
      aie.dma_bd(%y4_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc5)
      aie.use_lock(%y4_prod_lock_0, Release, %c1_i32) loc(#loc5)
      aie.next_bd ^bb7 loc(#loc5)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y4_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc5)
      aie.dma_bd(%y4_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc5)
      aie.use_lock(%y4_prod_lock_0, Release, %c1_i32) loc(#loc5)
      aie.next_bd ^bb6 loc(#loc5)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc14)
    } loc(#loc14)
    aie.shim_dma_allocation @w5_shim_alloc(%shim_noc_tile_2_0, MM2S, 1) loc(#loc13)
    %mem_1_3 = aie.mem(%tile_1_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc13)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc13)
      aie.dma_bd(%w5_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc13)
      aie.use_lock(%w5_cons_cons_lock_0, Release, %c1_i32) loc(#loc13)
      aie.next_bd ^bb2 loc(#loc13)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc13)
      aie.dma_bd(%w5_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc13)
      aie.use_lock(%w5_cons_cons_lock_0, Release, %c1_i32) loc(#loc13)
      aie.next_bd ^bb1 loc(#loc13)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_5_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc4)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y5_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc4)
      aie.dma_bd(%y5_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc4)
      aie.use_lock(%y5_prod_lock_0, Release, %c1_i32) loc(#loc4)
      aie.next_bd ^bb7 loc(#loc4)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y5_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc4)
      aie.dma_bd(%y5_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc4)
      aie.use_lock(%y5_prod_lock_0, Release, %c1_i32) loc(#loc4)
      aie.next_bd ^bb6 loc(#loc4)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc13)
    } loc(#loc13)
    aie.shim_dma_allocation @w6_shim_alloc(%shim_noc_tile_3_0, MM2S, 0) loc(#loc12)
    %mem_1_4 = aie.mem(%tile_1_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc12)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc12)
      aie.dma_bd(%w6_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc12)
      aie.use_lock(%w6_cons_cons_lock_0, Release, %c1_i32) loc(#loc12)
      aie.next_bd ^bb2 loc(#loc12)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc12)
      aie.dma_bd(%w6_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc12)
      aie.use_lock(%w6_cons_cons_lock_0, Release, %c1_i32) loc(#loc12)
      aie.next_bd ^bb1 loc(#loc12)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_6_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc3)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y6_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%y6_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc3)
      aie.use_lock(%y6_prod_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb7 loc(#loc3)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y6_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%y6_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc3)
      aie.use_lock(%y6_prod_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb6 loc(#loc3)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc12)
    } loc(#loc12)
    aie.shim_dma_allocation @w7_shim_alloc(%shim_noc_tile_3_0, MM2S, 1) loc(#loc11)
    %mem_1_5 = aie.mem(%tile_1_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc30)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb3) loc(#loc11)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%w7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%w7_cons_buff_0 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc11)
      aie.use_lock(%w7_cons_cons_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb2 loc(#loc11)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%w7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%w7_cons_buff_1 : memref<17408xui8> offset = 0 len = 17408) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc11)
      aie.use_lock(%w7_cons_cons_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb1 loc(#loc11)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb4, ^bb5) loc(#loc10)
    ^bb4:  // 2 preds: ^bb3, ^bb4
      aie.use_lock(%x_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%x_7_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 2 : i32} loc(#loc10)
      aie.use_lock(%x_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb4 loc(#loc10)
    ^bb5:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc2)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%y7_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%y7_buff_0 : memref<128xf32> offset = 0 len = 128) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc2)
      aie.use_lock(%y7_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb7 loc(#loc2)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%y7_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%y7_buff_1 : memref<128xf32> offset = 0 len = 128) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc2)
      aie.use_lock(%y7_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb6 loc(#loc2)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc11)
    } loc(#loc11)
    aie.shim_dma_allocation @x_shim_alloc(%shim_noc_tile_4_0, MM2S, 0) loc(#loc10)
    aie.shim_dma_allocation @y0_shim_alloc(%shim_noc_tile_0_0, S2MM, 0) loc(#loc9)
    aie.shim_dma_allocation @y1_shim_alloc(%shim_noc_tile_0_0, S2MM, 1) loc(#loc8)
    aie.shim_dma_allocation @y2_shim_alloc(%shim_noc_tile_1_0, S2MM, 0) loc(#loc7)
    aie.shim_dma_allocation @y3_shim_alloc(%shim_noc_tile_1_0, S2MM, 1) loc(#loc6)
    aie.shim_dma_allocation @y4_shim_alloc(%shim_noc_tile_2_0, S2MM, 0) loc(#loc5)
    aie.shim_dma_allocation @y5_shim_alloc(%shim_noc_tile_2_0, S2MM, 1) loc(#loc4)
    aie.shim_dma_allocation @y6_shim_alloc(%shim_noc_tile_3_0, S2MM, 0) loc(#loc3)
    aie.shim_dma_allocation @y7_shim_alloc(%shim_noc_tile_3_0, S2MM, 1) loc(#loc2)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_4_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_4_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_3_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_3_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_2_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_2_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_1_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_1_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_0_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_0_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
  } loc(#loc1)
} loc(#loc)
#loc = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":1:1)
#loc1 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":2:3)
#loc2 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":44:5)
#loc3 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":43:5)
#loc4 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":42:5)
#loc5 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":41:5)
#loc6 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":40:5)
#loc7 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":39:5)
#loc8 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":38:5)
#loc9 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":37:5)
#loc10 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":36:5)
#loc11 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":35:5)
#loc12 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":34:5)
#loc13 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":33:5)
#loc14 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":32:5)
#loc15 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":31:5)
#loc16 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":30:5)
#loc17 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":29:5)
#loc18 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":28:5)
#loc19 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":45:13)
#loc20 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":46:5)
#loc21 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":47:5)
#loc22 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":48:13)
#loc23 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":49:13)
#loc24 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":50:13)
#loc25 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":51:13)
#loc26 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":52:13)
#loc27 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":53:13)
#loc28 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":54:13)
#loc30 = loc(unknown)
#loc31 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":59:7)
#loc33 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":60:14)
#loc34 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":62:9)
#loc35 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":66:9)
#loc37 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":67:17)
#loc39 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":72:11)
#loc41 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":73:19)
#loc43 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":75:19)
#loc44 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":76:13)
#loc45 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":77:13)
#loc46 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":79:11)
#loc47 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":81:9)
#loc48 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":83:7)
#loc50 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":89:7)
#loc52 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":90:14)
#loc53 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":92:9)
#loc54 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":96:9)
#loc56 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":97:17)
#loc58 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":102:11)
#loc60 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":103:19)
#loc62 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":105:19)
#loc63 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":106:13)
#loc64 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":107:13)
#loc65 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":109:11)
#loc66 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":111:9)
#loc67 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":113:7)
#loc69 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":119:7)
#loc71 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":120:14)
#loc72 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":122:9)
#loc73 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":126:9)
#loc75 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":127:17)
#loc77 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":132:11)
#loc79 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":133:19)
#loc81 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":135:19)
#loc82 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":136:13)
#loc83 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":137:13)
#loc84 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":139:11)
#loc85 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":141:9)
#loc86 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":143:7)
#loc88 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":149:7)
#loc90 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":150:14)
#loc91 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":152:9)
#loc92 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":156:9)
#loc94 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":157:17)
#loc96 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":162:11)
#loc98 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":163:19)
#loc100 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":165:19)
#loc101 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":166:13)
#loc102 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":167:13)
#loc103 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":169:11)
#loc104 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":171:9)
#loc105 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":173:7)
#loc107 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":179:7)
#loc109 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":180:14)
#loc110 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":182:9)
#loc111 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":186:9)
#loc113 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":187:17)
#loc115 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":192:11)
#loc117 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":193:19)
#loc119 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":195:19)
#loc120 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":196:13)
#loc121 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":197:13)
#loc122 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":199:11)
#loc123 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":201:9)
#loc124 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":203:7)
#loc126 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":209:7)
#loc128 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":210:14)
#loc129 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":212:9)
#loc130 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":216:9)
#loc132 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":217:17)
#loc134 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":222:11)
#loc136 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":223:19)
#loc138 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":225:19)
#loc139 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":226:13)
#loc140 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":227:13)
#loc141 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":229:11)
#loc142 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":231:9)
#loc143 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":233:7)
#loc145 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":239:7)
#loc147 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":240:14)
#loc148 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":242:9)
#loc149 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":246:9)
#loc151 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":247:17)
#loc153 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":252:11)
#loc155 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":253:19)
#loc157 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":255:19)
#loc158 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":256:13)
#loc159 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":257:13)
#loc160 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":259:11)
#loc161 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":261:9)
#loc162 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":263:7)
#loc164 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":269:7)
#loc166 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":270:14)
#loc167 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":272:9)
#loc168 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":276:9)
#loc170 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":277:17)
#loc172 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":282:11)
#loc174 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":283:19)
#loc176 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":285:19)
#loc177 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":286:13)
#loc178 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":287:13)
#loc179 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":289:11)
#loc180 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":291:9)
#loc181 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":293:7)
#loc182 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":295:5)
#loc186 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":296:12)
#loc187 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":297:9)
#loc188 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":298:9)
#loc189 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":300:7)
#loc190 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":301:12)
#loc191 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":302:9)
#loc192 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":303:9)
#loc193 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":305:7)
#loc194 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":306:13)
#loc195 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":307:9)
#loc196 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":308:9)
#loc197 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":310:7)
#loc198 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":311:13)
#loc199 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":312:9)
#loc200 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":313:9)
#loc201 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":315:7)
#loc202 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":316:13)
#loc203 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":317:9)
#loc204 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":318:9)
#loc205 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":320:7)
#loc206 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":321:13)
#loc207 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":322:9)
#loc208 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":323:9)
#loc209 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":325:7)
#loc210 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":326:13)
#loc211 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":327:9)
#loc212 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":328:9)
#loc213 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":330:7)
#loc214 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":331:13)
#loc215 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":332:9)
#loc216 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":333:9)
#loc217 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":335:7)
#loc218 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":336:13)
#loc219 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":337:9)
#loc220 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":338:9)
#loc221 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":340:7)
#loc222 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":341:13)
#loc223 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":342:9)
#loc224 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":343:9)
#loc225 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":345:7)
#loc226 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":346:13)
#loc227 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":347:9)
#loc228 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":348:9)
#loc229 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":350:7)
#loc230 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":351:13)
#loc231 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":352:9)
#loc232 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":353:9)
#loc233 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":355:7)
#loc234 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":356:13)
#loc235 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":357:9)
#loc236 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":358:9)
#loc237 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":360:7)
#loc238 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":361:13)
#loc239 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":362:9)
#loc240 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":363:9)
#loc241 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":365:7)
#loc242 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":366:13)
#loc243 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":367:9)
#loc244 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":368:9)
#loc245 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":370:7)
#loc246 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":371:13)
#loc247 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":372:9)
#loc248 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":373:9)
#loc249 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":375:7)
#loc250 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":376:13)
#loc251 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":377:9)
#loc252 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":378:9)
#loc253 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":380:7)
#loc254 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":381:7)
#loc255 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":382:7)
#loc256 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":383:7)
#loc257 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":384:7)
#loc258 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":385:7)
#loc259 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":386:7)
#loc260 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":387:7)
#loc261 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":388:7)
#loc262 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":389:7)
#loc263 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":390:7)
#loc264 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":391:7)
#loc265 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":392:7)
#loc266 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":393:7)
#loc267 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":394:7)
#loc268 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":395:7)
#loc269 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":396:7)
#loc270 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":397:7)
#loc271 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":398:7)
#loc272 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":399:7)
#loc273 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":400:7)
#loc274 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":401:7)
#loc275 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":402:7)
#loc276 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":403:7)
#loc277 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":404:7)
#loc278 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/lm_head_q8/build_full/final.prj/aie.mlir":405:7)
