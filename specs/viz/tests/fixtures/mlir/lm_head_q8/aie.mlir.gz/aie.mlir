module {
  aie.device(npu2) {
    %logical_core = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_0 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_1 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_2 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_3 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_4 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_5 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_6 = aie.logical_tile<CoreTile>(?, ?)
    %logical_shim_noc = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_7 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_8 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_9 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_10 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_11 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_12 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_13 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_14 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_15 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_16 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_17 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_18 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_19 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_20 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_21 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_22 = aie.logical_tile<ShimNOCTile>(?, ?)
    aie.objectfifo @w0(%logical_shim_noc, {%logical_core}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w1(%logical_shim_noc_7, {%logical_core_0}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w2(%logical_shim_noc_8, {%logical_core_1}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w3(%logical_shim_noc_9, {%logical_core_2}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w4(%logical_shim_noc_10, {%logical_core_3}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w5(%logical_shim_noc_11, {%logical_core_4}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w6(%logical_shim_noc_12, {%logical_core_5}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @w7(%logical_shim_noc_13, {%logical_core_6}, 2 : i32) : !aie.objectfifo<memref<17408xui8>>  
    aie.objectfifo @x(%logical_shim_noc_14, {%logical_core, %logical_core_0, %logical_core_1, %logical_core_2, %logical_core_3, %logical_core_4, %logical_core_5, %logical_core_6}, 1 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @y0(%logical_core, {%logical_shim_noc_15}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y1(%logical_core_0, {%logical_shim_noc_16}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y2(%logical_core_1, {%logical_shim_noc_17}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y3(%logical_core_2, {%logical_shim_noc_18}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y4(%logical_core_3, {%logical_shim_noc_19}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y5(%logical_core_4, {%logical_shim_noc_20}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y6(%logical_core_5, {%logical_shim_noc_21}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    aie.objectfifo @y7(%logical_core_6, {%logical_shim_noc_22}, 2 : i32) : !aie.objectfifo<memref<128xf32>>  
    %tab0 = aie.buffer(%logical_core) {sym_name = "tab0"} : memref<4608xui8> 
    func.func private @gemv_q4_prep_k2048(memref<2048xbf16>, memref<4608xui8>) attributes {link_with = "gemv_q4_prep_k2048.o"}
    func.func private @lm_head_q8_group(memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) attributes {link_with = "lm_head_q8_group.o"}
    %tab1 = aie.buffer(%logical_core_0) {sym_name = "tab1"} : memref<4608xui8> 
    %tab2 = aie.buffer(%logical_core_1) {sym_name = "tab2"} : memref<4608xui8> 
    %tab3 = aie.buffer(%logical_core_2) {sym_name = "tab3"} : memref<4608xui8> 
    %tab4 = aie.buffer(%logical_core_3) {sym_name = "tab4"} : memref<4608xui8> 
    %tab5 = aie.buffer(%logical_core_4) {sym_name = "tab5"} : memref<4608xui8> 
    %tab6 = aie.buffer(%logical_core_5) {sym_name = "tab6"} : memref<4608xui8> 
    %tab7 = aie.buffer(%logical_core_6) {sym_name = "tab7"} : memref<4608xui8> 
    %0 = aie.core(%logical_core) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab0) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c243 = arith.constant 243 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c243 step %c1_24 {
          %10 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab0, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w0(Consume, 1)
          }
          aie.objectfifo.release @y0(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %1 = aie.core(%logical_core_0) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab1) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c243 = arith.constant 243 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c243 step %c1_24 {
          %10 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab1, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w1(Consume, 1)
          }
          aie.objectfifo.release @y1(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %2 = aie.core(%logical_core_1) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab2) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c243 = arith.constant 243 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c243 step %c1_24 {
          %10 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab2, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w2(Consume, 1)
          }
          aie.objectfifo.release @y2(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %3 = aie.core(%logical_core_2) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab3) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c243 = arith.constant 243 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c243 step %c1_24 {
          %10 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab3, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w3(Consume, 1)
          }
          aie.objectfifo.release @y3(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %4 = aie.core(%logical_core_3) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab4) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c242 = arith.constant 242 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c242 step %c1_24 {
          %10 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab4, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w4(Consume, 1)
          }
          aie.objectfifo.release @y4(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %5 = aie.core(%logical_core_4) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab5) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c242 = arith.constant 242 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c242 step %c1_24 {
          %10 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab5, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w5(Consume, 1)
          }
          aie.objectfifo.release @y5(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %6 = aie.core(%logical_core_5) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab6) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c242 = arith.constant 242 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c242 step %c1_24 {
          %10 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab6, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w6(Consume, 1)
          }
          aie.objectfifo.release @y6(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    %7 = aie.core(%logical_core_6) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %8 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%9, %tab7) : (memref<2048xbf16>, memref<4608xui8>) -> ()
        %c0_23 = arith.constant 0 : index
        %c242 = arith.constant 242 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg1 = %c0_23 to %c242 step %c1_24 {
          %10 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<128xf32>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<128xf32>> -> memref<128xf32>
          %c0_25 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_26 = arith.constant 1 : index
          scf.for %arg2 = %c0_25 to %c16 step %c1_26 {
            %12 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<17408xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<17408xui8>> -> memref<17408xui8>
            %14 = arith.index_cast %arg2 : index to i32
            func.call @lm_head_q8_group(%13, %tab7, %11, %14) : (memref<17408xui8>, memref<4608xui8>, memref<128xf32>, i32) -> ()
            aie.objectfifo.release @w7(Consume, 1)
          }
          aie.objectfifo.release @y7(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
      }
      aie.end
    } {stack_size = 4096 : i32}
    aie.runtime_sequence(%arg0: memref<540344320xui8>, %arg1: memref<2048xbf16>, %arg2: memref<248320xf32>) {
      %8 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%8)
      %9 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 0 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%9)
      %10 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 0 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%10)
      %11 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 67682304 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%11)
      %12 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 31104 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%12)
      %13 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 135364608 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%13)
      %14 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 62208 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%14)
      %15 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 203046912 len = 67682304 sizes = [1, 1, 1, 67682304] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%15)
      %16 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 93312 len = 31104 sizes = [1, 1, 1, 31104] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%16)
      %17 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 270729216 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%17)
      %18 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 124416 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%18)
      %19 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 338132992 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%19)
      %20 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 155392 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%20)
      %21 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 405536768 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%21)
      %22 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 186368 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%22)
      %23 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540344320xui8> offset = 472940544 len = 67403776 sizes = [1, 1, 1, 67403776] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%23)
      %24 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg2 : memref<248320xf32> offset = 217344 len = 30976 sizes = [1, 1, 1, 30976] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%24)
      aiex.dma_await_task(%10)
      aiex.dma_await_task(%12)
      aiex.dma_await_task(%14)
      aiex.dma_await_task(%16)
      aiex.dma_await_task(%18)
      aiex.dma_await_task(%20)
      aiex.dma_await_task(%22)
      aiex.dma_await_task(%24)
      aiex.dma_free_task(%8)
      aiex.dma_free_task(%9)
      aiex.dma_free_task(%10)
      aiex.dma_free_task(%11)
      aiex.dma_free_task(%12)
      aiex.dma_free_task(%13)
      aiex.dma_free_task(%14)
      aiex.dma_free_task(%15)
      aiex.dma_free_task(%16)
      aiex.dma_free_task(%17)
      aiex.dma_free_task(%18)
      aiex.dma_free_task(%19)
      aiex.dma_free_task(%20)
      aiex.dma_free_task(%21)
      aiex.dma_free_task(%22)
      aiex.dma_free_task(%23)
      aiex.dma_free_task(%24)
    }
  }
}
