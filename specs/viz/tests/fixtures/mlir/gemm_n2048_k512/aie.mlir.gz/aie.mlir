module {
  aie.device(npu2) {
    %logical_core = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_0 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_1 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_2 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_3 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_4 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_5 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_6 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_7 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_8 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_9 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_10 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_11 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_12 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_13 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_14 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_15 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_16 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_17 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_18 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_19 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_20 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_21 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_22 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_23 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_24 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_25 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_26 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_27 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_28 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_29 = aie.logical_tile<CoreTile>(?, ?)
    %logical_core_30 = aie.logical_tile<CoreTile>(?, ?)
    %logical_mem = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_31 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_32 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_33 = aie.logical_tile<MemTile>(?, ?)
    %logical_shim_noc = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_34 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_35 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_36 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_mem_37 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_38 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_39 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_40 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_41 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_42 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_43 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_44 = aie.logical_tile<MemTile>(?, ?)
    %logical_shim_noc_45 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_46 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_47 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_48 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_49 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_50 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_51 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_52 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_mem_53 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_54 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_55 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_56 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_57 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_58 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_59 = aie.logical_tile<MemTile>(?, ?)
    %logical_mem_60 = aie.logical_tile<MemTile>(?, ?)
    %logical_shim_noc_61 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_62 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_63 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_64 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_65 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_66 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_67 = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_68 = aie.logical_tile<ShimNOCTile>(?, ?)
    aie.objectfifo @A_L2L1_0(%logical_mem, {%logical_core, %logical_core_0, %logical_core_1, %logical_core_2, %logical_core_3, %logical_core_4, %logical_core_5, %logical_core_6}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @A_L3L2_0(%logical_shim_noc, {%logical_mem}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo.link [@A_L3L2_0] -> [@A_L2L1_0]([] [0])
    aie.objectfifo @A_L2L1_1(%logical_mem_31, {%logical_core_7, %logical_core_8, %logical_core_9, %logical_core_10, %logical_core_11, %logical_core_12, %logical_core_13, %logical_core_14}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @A_L3L2_1(%logical_shim_noc_34, {%logical_mem_31}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo.link [@A_L3L2_1] -> [@A_L2L1_1]([] [0])
    aie.objectfifo @A_L2L1_2(%logical_mem_32, {%logical_core_15, %logical_core_16, %logical_core_17, %logical_core_18, %logical_core_19, %logical_core_20, %logical_core_21, %logical_core_22}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @A_L3L2_2(%logical_shim_noc_35, {%logical_mem_32}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo.link [@A_L3L2_2] -> [@A_L2L1_2]([] [0])
    aie.objectfifo @A_L2L1_3(%logical_mem_33, {%logical_core_23, %logical_core_24, %logical_core_25, %logical_core_26, %logical_core_27, %logical_core_28, %logical_core_29, %logical_core_30}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @A_L3L2_3(%logical_shim_noc_36, {%logical_mem_33}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo.link [@A_L3L2_3] -> [@A_L2L1_3]([] [0])
    aie.objectfifo @B_L2L1_0(%logical_mem_37, {%logical_core, %logical_core_7, %logical_core_15, %logical_core_23}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_0(%logical_shim_noc_45, {%logical_mem_37}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_0] -> [@B_L2L1_0]([] [0])
    aie.objectfifo @B_L2L1_1(%logical_mem_38, {%logical_core_0, %logical_core_8, %logical_core_16, %logical_core_24}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_1(%logical_shim_noc_46, {%logical_mem_38}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_1] -> [@B_L2L1_1]([] [0])
    aie.objectfifo @B_L2L1_2(%logical_mem_39, {%logical_core_1, %logical_core_9, %logical_core_17, %logical_core_25}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_2(%logical_shim_noc_47, {%logical_mem_39}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_2] -> [@B_L2L1_2]([] [0])
    aie.objectfifo @B_L2L1_3(%logical_mem_40, {%logical_core_2, %logical_core_10, %logical_core_18, %logical_core_26}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_3(%logical_shim_noc_48, {%logical_mem_40}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_3] -> [@B_L2L1_3]([] [0])
    aie.objectfifo @B_L2L1_4(%logical_mem_41, {%logical_core_3, %logical_core_11, %logical_core_19, %logical_core_27}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_4(%logical_shim_noc_49, {%logical_mem_41}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_4] -> [@B_L2L1_4]([] [0])
    aie.objectfifo @B_L2L1_5(%logical_mem_42, {%logical_core_4, %logical_core_12, %logical_core_20, %logical_core_28}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_5(%logical_shim_noc_50, {%logical_mem_42}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_5] -> [@B_L2L1_5]([] [0])
    aie.objectfifo @B_L2L1_6(%logical_mem_43, {%logical_core_5, %logical_core_13, %logical_core_21, %logical_core_29}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_6(%logical_shim_noc_51, {%logical_mem_43}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_6] -> [@B_L2L1_6]([] [0])
    aie.objectfifo @B_L2L1_7(%logical_mem_44, {%logical_core_6, %logical_core_14, %logical_core_22, %logical_core_30}, 2 : i32) : !aie.objectfifo<memref<64x32xbf16>>  
    aie.objectfifo @B_L3L2_7(%logical_shim_noc_52, {%logical_mem_44}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@B_L3L2_7] -> [@B_L2L1_7]([] [0])
    aie.objectfifo @C_L1L2_0_0(%logical_core, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_0_1(%logical_core_7, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_0_2(%logical_core_15, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_0_3(%logical_core_23, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_0(%logical_mem_53 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_61}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_0_0, @C_L1L2_0_1, @C_L1L2_0_2, @C_L1L2_0_3] -> [@C_L2L3_0]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_1_0(%logical_core_0, {%logical_mem_54}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_1_1(%logical_core_8, {%logical_mem_54}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_1_2(%logical_core_16, {%logical_mem_54}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_1_3(%logical_core_24, {%logical_mem_54}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_1(%logical_mem_54 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_62}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_1_0, @C_L1L2_1_1, @C_L1L2_1_2, @C_L1L2_1_3] -> [@C_L2L3_1]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_2_0(%logical_core_1, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_2_1(%logical_core_9, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_2_2(%logical_core_17, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_2_3(%logical_core_25, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_2(%logical_mem_55 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_63}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_2_0, @C_L1L2_2_1, @C_L1L2_2_2, @C_L1L2_2_3] -> [@C_L2L3_2]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_3_0(%logical_core_2, {%logical_mem_56}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_3_1(%logical_core_10, {%logical_mem_56}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_3_2(%logical_core_18, {%logical_mem_56}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_3_3(%logical_core_26, {%logical_mem_56}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_3(%logical_mem_56 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_64}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_3_0, @C_L1L2_3_1, @C_L1L2_3_2, @C_L1L2_3_3] -> [@C_L2L3_3]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_4_0(%logical_core_3, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_4_1(%logical_core_11, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_4_2(%logical_core_19, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_4_3(%logical_core_27, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_4(%logical_mem_57 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_65}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_4_0, @C_L1L2_4_1, @C_L1L2_4_2, @C_L1L2_4_3] -> [@C_L2L3_4]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_5_0(%logical_core_4, {%logical_mem_58}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_5_1(%logical_core_12, {%logical_mem_58}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_5_2(%logical_core_20, {%logical_mem_58}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_5_3(%logical_core_28, {%logical_mem_58}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_5(%logical_mem_58 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_66}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_5_0, @C_L1L2_5_1, @C_L1L2_5_2, @C_L1L2_5_3] -> [@C_L2L3_5]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_6_0(%logical_core_5, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_6_1(%logical_core_13, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_6_2(%logical_core_21, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_6_3(%logical_core_29, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_6(%logical_mem_59 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_67}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_6_0, @C_L1L2_6_1, @C_L1L2_6_2, @C_L1L2_6_3] -> [@C_L2L3_6]([0, 2048, 4096, 6144] [])
    aie.objectfifo @C_L1L2_7_0(%logical_core_6, {%logical_mem_60}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_7_1(%logical_core_14, {%logical_mem_60}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_7_2(%logical_core_22, {%logical_mem_60}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L1L2_7_3(%logical_core_30, {%logical_mem_60}, 2 : i32) : !aie.objectfifo<memref<64x32xf32>>  
    aie.objectfifo @C_L2L3_7(%logical_mem_60 dimensionsToStream [<size = 16, stride = 128>, <size = 4, stride = 8>, <size = 4, stride = 32>, <size = 8, stride = 1>], {%logical_shim_noc_68}, 2 : i32) : !aie.objectfifo<memref<8192xf32>>  
    aie.objectfifo.link [@C_L1L2_7_0, @C_L1L2_7_1, @C_L1L2_7_2, @C_L1L2_7_3] -> [@C_L2L3_7]([0, 2048, 4096, 6144] [])
    func.func private @zero_f32(memref<2048xf32>) attributes {link_with = "matmul_bf16_f32_14e9516c.o"}
    func.func private @"14e9516c_matmul_bf16_f32"(memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) attributes {link_with = "matmul_bf16_f32_14e9516c.o"}
    %nib_0_0 = aie.buffer(%logical_core) {sym_name = "nib_0_0"} : memref<4096xui8> 
    %ascr_0_0 = aie.buffer(%logical_core) {sym_name = "ascr_0_0"} : memref<4096xbf16> 
    %rtp_0_0 = aie.buffer(%logical_core) {sym_name = "rtp_0_0"} : memref<2xi32> = dense<0>
    func.func private @gqd_entry_k0(memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) attributes {link_with = "gqd_entry_k0.o"}
    func.func private @gqd_entry_k1(memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) attributes {link_with = "gqd_entry_k1.o"}
    func.func private @gqd_entry_k2(memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) attributes {link_with = "gqd_entry_k2.o"}
    func.func private @gqd_entry_k3(memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) attributes {link_with = "gqd_entry_k3.o"}
    %nib_0_1 = aie.buffer(%logical_core_0) {sym_name = "nib_0_1"} : memref<4096xui8> 
    %ascr_0_1 = aie.buffer(%logical_core_0) {sym_name = "ascr_0_1"} : memref<4096xbf16> 
    %rtp_0_1 = aie.buffer(%logical_core_0) {sym_name = "rtp_0_1"} : memref<2xi32> = dense<0>
    %nib_0_2 = aie.buffer(%logical_core_1) {sym_name = "nib_0_2"} : memref<4096xui8> 
    %ascr_0_2 = aie.buffer(%logical_core_1) {sym_name = "ascr_0_2"} : memref<4096xbf16> 
    %rtp_0_2 = aie.buffer(%logical_core_1) {sym_name = "rtp_0_2"} : memref<2xi32> = dense<0>
    %nib_0_3 = aie.buffer(%logical_core_2) {sym_name = "nib_0_3"} : memref<4096xui8> 
    %ascr_0_3 = aie.buffer(%logical_core_2) {sym_name = "ascr_0_3"} : memref<4096xbf16> 
    %rtp_0_3 = aie.buffer(%logical_core_2) {sym_name = "rtp_0_3"} : memref<2xi32> = dense<0>
    %nib_0_4 = aie.buffer(%logical_core_3) {sym_name = "nib_0_4"} : memref<4096xui8> 
    %ascr_0_4 = aie.buffer(%logical_core_3) {sym_name = "ascr_0_4"} : memref<4096xbf16> 
    %rtp_0_4 = aie.buffer(%logical_core_3) {sym_name = "rtp_0_4"} : memref<2xi32> = dense<0>
    %nib_0_5 = aie.buffer(%logical_core_4) {sym_name = "nib_0_5"} : memref<4096xui8> 
    %ascr_0_5 = aie.buffer(%logical_core_4) {sym_name = "ascr_0_5"} : memref<4096xbf16> 
    %rtp_0_5 = aie.buffer(%logical_core_4) {sym_name = "rtp_0_5"} : memref<2xi32> = dense<0>
    %nib_0_6 = aie.buffer(%logical_core_5) {sym_name = "nib_0_6"} : memref<4096xui8> 
    %ascr_0_6 = aie.buffer(%logical_core_5) {sym_name = "ascr_0_6"} : memref<4096xbf16> 
    %rtp_0_6 = aie.buffer(%logical_core_5) {sym_name = "rtp_0_6"} : memref<2xi32> = dense<0>
    %nib_0_7 = aie.buffer(%logical_core_6) {sym_name = "nib_0_7"} : memref<4096xui8> 
    %ascr_0_7 = aie.buffer(%logical_core_6) {sym_name = "ascr_0_7"} : memref<4096xbf16> 
    %rtp_0_7 = aie.buffer(%logical_core_6) {sym_name = "rtp_0_7"} : memref<2xi32> = dense<0>
    %nib_1_0 = aie.buffer(%logical_core_7) {sym_name = "nib_1_0"} : memref<4096xui8> 
    %ascr_1_0 = aie.buffer(%logical_core_7) {sym_name = "ascr_1_0"} : memref<4096xbf16> 
    %rtp_1_0 = aie.buffer(%logical_core_7) {sym_name = "rtp_1_0"} : memref<2xi32> = dense<0>
    %nib_1_1 = aie.buffer(%logical_core_8) {sym_name = "nib_1_1"} : memref<4096xui8> 
    %ascr_1_1 = aie.buffer(%logical_core_8) {sym_name = "ascr_1_1"} : memref<4096xbf16> 
    %rtp_1_1 = aie.buffer(%logical_core_8) {sym_name = "rtp_1_1"} : memref<2xi32> = dense<0>
    %nib_1_2 = aie.buffer(%logical_core_9) {sym_name = "nib_1_2"} : memref<4096xui8> 
    %ascr_1_2 = aie.buffer(%logical_core_9) {sym_name = "ascr_1_2"} : memref<4096xbf16> 
    %rtp_1_2 = aie.buffer(%logical_core_9) {sym_name = "rtp_1_2"} : memref<2xi32> = dense<0>
    %nib_1_3 = aie.buffer(%logical_core_10) {sym_name = "nib_1_3"} : memref<4096xui8> 
    %ascr_1_3 = aie.buffer(%logical_core_10) {sym_name = "ascr_1_3"} : memref<4096xbf16> 
    %rtp_1_3 = aie.buffer(%logical_core_10) {sym_name = "rtp_1_3"} : memref<2xi32> = dense<0>
    %nib_1_4 = aie.buffer(%logical_core_11) {sym_name = "nib_1_4"} : memref<4096xui8> 
    %ascr_1_4 = aie.buffer(%logical_core_11) {sym_name = "ascr_1_4"} : memref<4096xbf16> 
    %rtp_1_4 = aie.buffer(%logical_core_11) {sym_name = "rtp_1_4"} : memref<2xi32> = dense<0>
    %nib_1_5 = aie.buffer(%logical_core_12) {sym_name = "nib_1_5"} : memref<4096xui8> 
    %ascr_1_5 = aie.buffer(%logical_core_12) {sym_name = "ascr_1_5"} : memref<4096xbf16> 
    %rtp_1_5 = aie.buffer(%logical_core_12) {sym_name = "rtp_1_5"} : memref<2xi32> = dense<0>
    %nib_1_6 = aie.buffer(%logical_core_13) {sym_name = "nib_1_6"} : memref<4096xui8> 
    %ascr_1_6 = aie.buffer(%logical_core_13) {sym_name = "ascr_1_6"} : memref<4096xbf16> 
    %rtp_1_6 = aie.buffer(%logical_core_13) {sym_name = "rtp_1_6"} : memref<2xi32> = dense<0>
    %nib_1_7 = aie.buffer(%logical_core_14) {sym_name = "nib_1_7"} : memref<4096xui8> 
    %ascr_1_7 = aie.buffer(%logical_core_14) {sym_name = "ascr_1_7"} : memref<4096xbf16> 
    %rtp_1_7 = aie.buffer(%logical_core_14) {sym_name = "rtp_1_7"} : memref<2xi32> = dense<0>
    %nib_2_0 = aie.buffer(%logical_core_15) {sym_name = "nib_2_0"} : memref<4096xui8> 
    %ascr_2_0 = aie.buffer(%logical_core_15) {sym_name = "ascr_2_0"} : memref<4096xbf16> 
    %rtp_2_0 = aie.buffer(%logical_core_15) {sym_name = "rtp_2_0"} : memref<2xi32> = dense<0>
    %nib_2_1 = aie.buffer(%logical_core_16) {sym_name = "nib_2_1"} : memref<4096xui8> 
    %ascr_2_1 = aie.buffer(%logical_core_16) {sym_name = "ascr_2_1"} : memref<4096xbf16> 
    %rtp_2_1 = aie.buffer(%logical_core_16) {sym_name = "rtp_2_1"} : memref<2xi32> = dense<0>
    %nib_2_2 = aie.buffer(%logical_core_17) {sym_name = "nib_2_2"} : memref<4096xui8> 
    %ascr_2_2 = aie.buffer(%logical_core_17) {sym_name = "ascr_2_2"} : memref<4096xbf16> 
    %rtp_2_2 = aie.buffer(%logical_core_17) {sym_name = "rtp_2_2"} : memref<2xi32> = dense<0>
    %nib_2_3 = aie.buffer(%logical_core_18) {sym_name = "nib_2_3"} : memref<4096xui8> 
    %ascr_2_3 = aie.buffer(%logical_core_18) {sym_name = "ascr_2_3"} : memref<4096xbf16> 
    %rtp_2_3 = aie.buffer(%logical_core_18) {sym_name = "rtp_2_3"} : memref<2xi32> = dense<0>
    %nib_2_4 = aie.buffer(%logical_core_19) {sym_name = "nib_2_4"} : memref<4096xui8> 
    %ascr_2_4 = aie.buffer(%logical_core_19) {sym_name = "ascr_2_4"} : memref<4096xbf16> 
    %rtp_2_4 = aie.buffer(%logical_core_19) {sym_name = "rtp_2_4"} : memref<2xi32> = dense<0>
    %nib_2_5 = aie.buffer(%logical_core_20) {sym_name = "nib_2_5"} : memref<4096xui8> 
    %ascr_2_5 = aie.buffer(%logical_core_20) {sym_name = "ascr_2_5"} : memref<4096xbf16> 
    %rtp_2_5 = aie.buffer(%logical_core_20) {sym_name = "rtp_2_5"} : memref<2xi32> = dense<0>
    %nib_2_6 = aie.buffer(%logical_core_21) {sym_name = "nib_2_6"} : memref<4096xui8> 
    %ascr_2_6 = aie.buffer(%logical_core_21) {sym_name = "ascr_2_6"} : memref<4096xbf16> 
    %rtp_2_6 = aie.buffer(%logical_core_21) {sym_name = "rtp_2_6"} : memref<2xi32> = dense<0>
    %nib_2_7 = aie.buffer(%logical_core_22) {sym_name = "nib_2_7"} : memref<4096xui8> 
    %ascr_2_7 = aie.buffer(%logical_core_22) {sym_name = "ascr_2_7"} : memref<4096xbf16> 
    %rtp_2_7 = aie.buffer(%logical_core_22) {sym_name = "rtp_2_7"} : memref<2xi32> = dense<0>
    %nib_3_0 = aie.buffer(%logical_core_23) {sym_name = "nib_3_0"} : memref<4096xui8> 
    %ascr_3_0 = aie.buffer(%logical_core_23) {sym_name = "ascr_3_0"} : memref<4096xbf16> 
    %rtp_3_0 = aie.buffer(%logical_core_23) {sym_name = "rtp_3_0"} : memref<2xi32> = dense<0>
    %nib_3_1 = aie.buffer(%logical_core_24) {sym_name = "nib_3_1"} : memref<4096xui8> 
    %ascr_3_1 = aie.buffer(%logical_core_24) {sym_name = "ascr_3_1"} : memref<4096xbf16> 
    %rtp_3_1 = aie.buffer(%logical_core_24) {sym_name = "rtp_3_1"} : memref<2xi32> = dense<0>
    %nib_3_2 = aie.buffer(%logical_core_25) {sym_name = "nib_3_2"} : memref<4096xui8> 
    %ascr_3_2 = aie.buffer(%logical_core_25) {sym_name = "ascr_3_2"} : memref<4096xbf16> 
    %rtp_3_2 = aie.buffer(%logical_core_25) {sym_name = "rtp_3_2"} : memref<2xi32> = dense<0>
    %nib_3_3 = aie.buffer(%logical_core_26) {sym_name = "nib_3_3"} : memref<4096xui8> 
    %ascr_3_3 = aie.buffer(%logical_core_26) {sym_name = "ascr_3_3"} : memref<4096xbf16> 
    %rtp_3_3 = aie.buffer(%logical_core_26) {sym_name = "rtp_3_3"} : memref<2xi32> = dense<0>
    %nib_3_4 = aie.buffer(%logical_core_27) {sym_name = "nib_3_4"} : memref<4096xui8> 
    %ascr_3_4 = aie.buffer(%logical_core_27) {sym_name = "ascr_3_4"} : memref<4096xbf16> 
    %rtp_3_4 = aie.buffer(%logical_core_27) {sym_name = "rtp_3_4"} : memref<2xi32> = dense<0>
    %nib_3_5 = aie.buffer(%logical_core_28) {sym_name = "nib_3_5"} : memref<4096xui8> 
    %ascr_3_5 = aie.buffer(%logical_core_28) {sym_name = "ascr_3_5"} : memref<4096xbf16> 
    %rtp_3_5 = aie.buffer(%logical_core_28) {sym_name = "rtp_3_5"} : memref<2xi32> = dense<0>
    %nib_3_6 = aie.buffer(%logical_core_29) {sym_name = "nib_3_6"} : memref<4096xui8> 
    %ascr_3_6 = aie.buffer(%logical_core_29) {sym_name = "ascr_3_6"} : memref<4096xbf16> 
    %rtp_3_6 = aie.buffer(%logical_core_29) {sym_name = "rtp_3_6"} : memref<2xi32> = dense<0>
    %nib_3_7 = aie.buffer(%logical_core_30) {sym_name = "nib_3_7"} : memref<4096xui8> 
    %ascr_3_7 = aie.buffer(%logical_core_30) {sym_name = "ascr_3_7"} : memref<4096xbf16> 
    %rtp_3_7 = aie.buffer(%logical_core_30) {sym_name = "rtp_3_7"} : memref<2xi32> = dense<0>
    %0 = aie.core(%logical_core) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_0_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_0[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_0, %ascr_0_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_0, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_0_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %1 = aie.core(%logical_core_0) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_1_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_1[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_1, %ascr_0_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_1, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_1_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %2 = aie.core(%logical_core_1) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_2_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_2[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_2, %ascr_0_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_2, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_2_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %3 = aie.core(%logical_core_2) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_3_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_3[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_3, %ascr_0_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_3, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_3_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %4 = aie.core(%logical_core_3) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_4_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_4[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_4, %ascr_0_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_4, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_4_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %5 = aie.core(%logical_core_4) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_5_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_5[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_5, %ascr_0_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_5, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_5_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %6 = aie.core(%logical_core_5) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_6_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_6[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_6, %ascr_0_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_6, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_6_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %7 = aie.core(%logical_core_6) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_7_0(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_0_7[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          aie.objectfifo.release @A_L2L1_0(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_0_7, %ascr_0_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_0_7, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            aie.objectfifo.release @A_L2L1_0(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_7_0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %8 = aie.core(%logical_core_7) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_0_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_0[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_0, %ascr_1_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_0, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_0_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %9 = aie.core(%logical_core_8) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_1_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_1[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_1, %ascr_1_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_1, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_1_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %10 = aie.core(%logical_core_9) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_2_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_2[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_2, %ascr_1_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_2, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_2_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %11 = aie.core(%logical_core_10) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_3_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_3[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_3, %ascr_1_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_3, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_3_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %12 = aie.core(%logical_core_11) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_4_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_4[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_4, %ascr_1_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_4, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_4_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %13 = aie.core(%logical_core_12) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_5_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_5[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_5, %ascr_1_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_5, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_5_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %14 = aie.core(%logical_core_13) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_6_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_6[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_6, %ascr_1_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_6, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_6_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %15 = aie.core(%logical_core_14) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_7_1(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_1_7[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          aie.objectfifo.release @A_L2L1_1(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_1_7, %ascr_1_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_1_7, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            aie.objectfifo.release @A_L2L1_1(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_7_1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %16 = aie.core(%logical_core_15) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_0_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_0[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_0, %ascr_2_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_0, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_0_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %17 = aie.core(%logical_core_16) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_1_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_1[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_1, %ascr_2_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_1, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_1_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %18 = aie.core(%logical_core_17) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_2_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_2[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_2, %ascr_2_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_2, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_2_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %19 = aie.core(%logical_core_18) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_3_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_3[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_3, %ascr_2_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_3, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_3_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %20 = aie.core(%logical_core_19) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_4_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_4[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_4, %ascr_2_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_4, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_4_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %21 = aie.core(%logical_core_20) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_5_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_5[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_5, %ascr_2_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_5, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_5_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %22 = aie.core(%logical_core_21) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_6_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_6[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_6, %ascr_2_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_6, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_6_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %23 = aie.core(%logical_core_22) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_7_2(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_2_7[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          aie.objectfifo.release @A_L2L1_2(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_2_7, %ascr_2_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_2_7, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            aie.objectfifo.release @A_L2L1_2(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_7_2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %24 = aie.core(%logical_core_23) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_0_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_0[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_0(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_0, %ascr_3_0) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_0(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_0, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_0(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_0_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %25 = aie.core(%logical_core_24) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_1_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_1[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_1(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_1, %ascr_3_1) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_1(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_1, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_1(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_1_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %26 = aie.core(%logical_core_25) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_2_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_2[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_2(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_2, %ascr_3_2) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_2(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_2, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_2(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_2_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %27 = aie.core(%logical_core_26) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_3_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_3[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_3(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_3, %ascr_3_3) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_3, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_3(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_3_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %28 = aie.core(%logical_core_27) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_4_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_4[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_4(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_4, %ascr_3_4) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_4(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_4, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_4(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_4_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %29 = aie.core(%logical_core_28) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_5_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_5[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_5(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_5, %ascr_3_5) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_5(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_5, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_5(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_5_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %30 = aie.core(%logical_core_29) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_6_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_6[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_6(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_6, %ascr_3_6) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_6(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_6, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_6(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_6_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    %31 = aie.core(%logical_core_30) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          %32 = aie.objectfifo.acquire @C_L1L2_7_3(Produce, 1) : !aie.objectfifosubview<memref<64x32xf32>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<64x32xf32>> -> memref<64x32xf32>
          %collapse_shape = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @zero_f32(%collapse_shape) : (memref<2048xf32>) -> ()
          %34 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %c1_72 = arith.constant 1 : index
          %36 = memref.load %rtp_3_7[%c1_72] : memref<2xi32>
          func.call @gqd_entry_k0(%35, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %37 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %38 = aie.objectfifo.subview.access %37[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_73 = memref.collapse_shape %38 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_74 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_73, %collapse_shape_74) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k1(%35, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %39 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %40 = aie.objectfifo.subview.access %39[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_75 = memref.collapse_shape %40 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_76 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_75, %collapse_shape_76) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k2(%35, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %41 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %42 = aie.objectfifo.subview.access %41[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_77 = memref.collapse_shape %42 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_78 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_77, %collapse_shape_78) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          func.call @gqd_entry_k3(%35, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
          %43 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
          %44 = aie.objectfifo.subview.access %43[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
          %collapse_shape_79 = memref.collapse_shape %44 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
          %collapse_shape_80 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
          func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_79, %collapse_shape_80) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
          aie.objectfifo.release @B_L2L1_7(Consume, 1)
          aie.objectfifo.release @A_L2L1_3(Consume, 1)
          %c1_i32 = arith.constant 1 : i32
          %45 = arith.subi %36, %c1_i32 : i32
          %c0_81 = arith.constant 0 : index
          %46 = arith.index_cast %45 : i32 to index
          %c1_82 = arith.constant 1 : index
          scf.for %arg2 = %c0_81 to %46 step %c1_82 {
            %47 = aie.objectfifo.acquire @A_L2L1_3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %48 = aie.objectfifo.subview.access %47[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            func.call @gqd_entry_k0(%48, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %49 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %50 = aie.objectfifo.subview.access %49[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_83 = memref.collapse_shape %50 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_84 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_83, %collapse_shape_84) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k1(%48, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %51 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %52 = aie.objectfifo.subview.access %51[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_85 = memref.collapse_shape %52 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_86 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_85, %collapse_shape_86) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k2(%48, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %53 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %54 = aie.objectfifo.subview.access %53[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_87 = memref.collapse_shape %54 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_88 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_87, %collapse_shape_88) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            func.call @gqd_entry_k3(%48, %nib_3_7, %ascr_3_7) : (memref<10240xui8>, memref<4096xui8>, memref<4096xbf16>) -> ()
            %55 = aie.objectfifo.acquire @B_L2L1_7(Consume, 1) : !aie.objectfifosubview<memref<64x32xbf16>>
            %56 = aie.objectfifo.subview.access %55[0] : !aie.objectfifosubview<memref<64x32xbf16>> -> memref<64x32xbf16>
            %collapse_shape_89 = memref.collapse_shape %56 [[0, 1]] : memref<64x32xbf16> into memref<2048xbf16>
            %collapse_shape_90 = memref.collapse_shape %33 [[0, 1]] : memref<64x32xf32> into memref<2048xf32>
            func.call @"14e9516c_matmul_bf16_f32"(%ascr_3_7, %collapse_shape_89, %collapse_shape_90) : (memref<4096xbf16>, memref<2048xbf16>, memref<2048xf32>) -> ()
            aie.objectfifo.release @B_L2L1_7(Consume, 1)
            aie.objectfifo.release @A_L2L1_3(Consume, 1)
          }
          aie.objectfifo.release @C_L1L2_7_3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 4096 : i32}
    aie.runtime_sequence(%arg0: memref<655360xui8>, %arg1: memref<131072xbf16>, %arg2: memref<524288xf32>) {
      %c1_i32 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_0, 0, %c1_i32) : i32
      %c2_i32 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_0, 1, %c2_i32) : i32
      %c1_i32_69 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_1, 0, %c1_i32_69) : i32
      %c2_i32_70 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_1, 1, %c2_i32_70) : i32
      %c1_i32_71 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_2, 0, %c1_i32_71) : i32
      %c2_i32_72 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_2, 1, %c2_i32_72) : i32
      %c1_i32_73 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_3, 0, %c1_i32_73) : i32
      %c2_i32_74 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_3, 1, %c2_i32_74) : i32
      %c1_i32_75 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_4, 0, %c1_i32_75) : i32
      %c2_i32_76 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_4, 1, %c2_i32_76) : i32
      %c1_i32_77 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_5, 0, %c1_i32_77) : i32
      %c2_i32_78 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_5, 1, %c2_i32_78) : i32
      %c1_i32_79 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_6, 0, %c1_i32_79) : i32
      %c2_i32_80 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_6, 1, %c2_i32_80) : i32
      %c1_i32_81 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_0_7, 0, %c1_i32_81) : i32
      %c2_i32_82 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_0_7, 1, %c2_i32_82) : i32
      %c1_i32_83 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_0, 0, %c1_i32_83) : i32
      %c2_i32_84 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_0, 1, %c2_i32_84) : i32
      %c1_i32_85 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_1, 0, %c1_i32_85) : i32
      %c2_i32_86 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_1, 1, %c2_i32_86) : i32
      %c1_i32_87 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_2, 0, %c1_i32_87) : i32
      %c2_i32_88 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_2, 1, %c2_i32_88) : i32
      %c1_i32_89 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_3, 0, %c1_i32_89) : i32
      %c2_i32_90 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_3, 1, %c2_i32_90) : i32
      %c1_i32_91 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_4, 0, %c1_i32_91) : i32
      %c2_i32_92 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_4, 1, %c2_i32_92) : i32
      %c1_i32_93 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_5, 0, %c1_i32_93) : i32
      %c2_i32_94 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_5, 1, %c2_i32_94) : i32
      %c1_i32_95 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_6, 0, %c1_i32_95) : i32
      %c2_i32_96 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_6, 1, %c2_i32_96) : i32
      %c1_i32_97 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_1_7, 0, %c1_i32_97) : i32
      %c2_i32_98 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_1_7, 1, %c2_i32_98) : i32
      %c1_i32_99 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_0, 0, %c1_i32_99) : i32
      %c2_i32_100 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_0, 1, %c2_i32_100) : i32
      %c1_i32_101 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_1, 0, %c1_i32_101) : i32
      %c2_i32_102 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_1, 1, %c2_i32_102) : i32
      %c1_i32_103 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_2, 0, %c1_i32_103) : i32
      %c2_i32_104 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_2, 1, %c2_i32_104) : i32
      %c1_i32_105 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_3, 0, %c1_i32_105) : i32
      %c2_i32_106 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_3, 1, %c2_i32_106) : i32
      %c1_i32_107 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_4, 0, %c1_i32_107) : i32
      %c2_i32_108 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_4, 1, %c2_i32_108) : i32
      %c1_i32_109 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_5, 0, %c1_i32_109) : i32
      %c2_i32_110 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_5, 1, %c2_i32_110) : i32
      %c1_i32_111 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_6, 0, %c1_i32_111) : i32
      %c2_i32_112 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_6, 1, %c2_i32_112) : i32
      %c1_i32_113 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_2_7, 0, %c1_i32_113) : i32
      %c2_i32_114 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_2_7, 1, %c2_i32_114) : i32
      %c1_i32_115 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_0, 0, %c1_i32_115) : i32
      %c2_i32_116 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_0, 1, %c2_i32_116) : i32
      %c1_i32_117 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_1, 0, %c1_i32_117) : i32
      %c2_i32_118 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_1, 1, %c2_i32_118) : i32
      %c1_i32_119 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_2, 0, %c1_i32_119) : i32
      %c2_i32_120 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_2, 1, %c2_i32_120) : i32
      %c1_i32_121 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_3, 0, %c1_i32_121) : i32
      %c2_i32_122 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_3, 1, %c2_i32_122) : i32
      %c1_i32_123 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_4, 0, %c1_i32_123) : i32
      %c2_i32_124 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_4, 1, %c2_i32_124) : i32
      %c1_i32_125 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_5, 0, %c1_i32_125) : i32
      %c2_i32_126 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_5, 1, %c2_i32_126) : i32
      %c1_i32_127 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_6, 0, %c1_i32_127) : i32
      %c2_i32_128 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_6, 1, %c2_i32_128) : i32
      %c1_i32_129 = arith.constant 1 : i32
      aiex.npu.rtp_write(@rtp_3_7, 0, %c1_i32_129) : i32
      %c2_i32_130 = arith.constant 2 : i32
      aiex.npu.rtp_write(@rtp_3_7, 1, %c2_i32_130) : i32
      %32 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 0 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%32)
      %33 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 20480 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%33)
      %34 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 40960 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%34)
      %35 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 61440 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%35)
      %36 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%36)
      %37 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%37)
      %38 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%38)
      %39 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%39)
      %40 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%40)
      %41 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%41)
      %42 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%42)
      %43 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%43)
      %44 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 0 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%44)
      %45 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 32 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%45)
      %46 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 64 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%46)
      %47 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 96 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%47)
      %48 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 128 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%48)
      %49 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 160 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%49)
      %50 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 192 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%50)
      %51 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 224 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%51)
      aiex.dma_await_task(%44)
      aiex.dma_await_task(%45)
      aiex.dma_await_task(%46)
      aiex.dma_await_task(%47)
      aiex.dma_await_task(%48)
      aiex.dma_await_task(%49)
      aiex.dma_await_task(%50)
      aiex.dma_await_task(%51)
      aiex.dma_free_task(%32)
      aiex.dma_free_task(%33)
      aiex.dma_free_task(%34)
      aiex.dma_free_task(%35)
      aiex.dma_free_task(%36)
      aiex.dma_free_task(%37)
      aiex.dma_free_task(%38)
      aiex.dma_free_task(%39)
      aiex.dma_free_task(%40)
      aiex.dma_free_task(%41)
      aiex.dma_free_task(%42)
      aiex.dma_free_task(%43)
      aiex.dma_free_task(%44)
      aiex.dma_free_task(%45)
      aiex.dma_free_task(%46)
      aiex.dma_free_task(%47)
      aiex.dma_free_task(%48)
      aiex.dma_free_task(%49)
      aiex.dma_free_task(%50)
      aiex.dma_free_task(%51)
      %52 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 81920 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%52)
      %53 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 102400 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%53)
      %54 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 122880 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%54)
      %55 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 143360 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%55)
      %56 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%56)
      %57 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%57)
      %58 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%58)
      %59 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%59)
      %60 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%60)
      %61 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%61)
      %62 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%62)
      %63 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%63)
      %64 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65536 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%64)
      %65 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65568 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%65)
      %66 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65600 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%66)
      %67 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65632 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%67)
      %68 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65664 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%68)
      %69 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65696 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%69)
      %70 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65728 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%70)
      %71 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 65760 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%71)
      aiex.dma_await_task(%64)
      aiex.dma_await_task(%65)
      aiex.dma_await_task(%66)
      aiex.dma_await_task(%67)
      aiex.dma_await_task(%68)
      aiex.dma_await_task(%69)
      aiex.dma_await_task(%70)
      aiex.dma_await_task(%71)
      aiex.dma_free_task(%52)
      aiex.dma_free_task(%53)
      aiex.dma_free_task(%54)
      aiex.dma_free_task(%55)
      aiex.dma_free_task(%56)
      aiex.dma_free_task(%57)
      aiex.dma_free_task(%58)
      aiex.dma_free_task(%59)
      aiex.dma_free_task(%60)
      aiex.dma_free_task(%61)
      aiex.dma_free_task(%62)
      aiex.dma_free_task(%63)
      aiex.dma_free_task(%64)
      aiex.dma_free_task(%65)
      aiex.dma_free_task(%66)
      aiex.dma_free_task(%67)
      aiex.dma_free_task(%68)
      aiex.dma_free_task(%69)
      aiex.dma_free_task(%70)
      aiex.dma_free_task(%71)
      %72 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 163840 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%72)
      %73 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 184320 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%73)
      %74 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 204800 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%74)
      %75 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 225280 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%75)
      %76 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%76)
      %77 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%77)
      %78 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%78)
      %79 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%79)
      %80 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%80)
      %81 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%81)
      %82 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%82)
      %83 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%83)
      %84 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131072 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%84)
      %85 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131104 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%85)
      %86 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131136 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%86)
      %87 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131168 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%87)
      %88 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131200 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%88)
      %89 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131232 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%89)
      %90 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131264 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%90)
      %91 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 131296 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%91)
      aiex.dma_await_task(%84)
      aiex.dma_await_task(%85)
      aiex.dma_await_task(%86)
      aiex.dma_await_task(%87)
      aiex.dma_await_task(%88)
      aiex.dma_await_task(%89)
      aiex.dma_await_task(%90)
      aiex.dma_await_task(%91)
      aiex.dma_free_task(%72)
      aiex.dma_free_task(%73)
      aiex.dma_free_task(%74)
      aiex.dma_free_task(%75)
      aiex.dma_free_task(%76)
      aiex.dma_free_task(%77)
      aiex.dma_free_task(%78)
      aiex.dma_free_task(%79)
      aiex.dma_free_task(%80)
      aiex.dma_free_task(%81)
      aiex.dma_free_task(%82)
      aiex.dma_free_task(%83)
      aiex.dma_free_task(%84)
      aiex.dma_free_task(%85)
      aiex.dma_free_task(%86)
      aiex.dma_free_task(%87)
      aiex.dma_free_task(%88)
      aiex.dma_free_task(%89)
      aiex.dma_free_task(%90)
      aiex.dma_free_task(%91)
      %92 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 245760 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%92)
      %93 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 266240 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%93)
      %94 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 286720 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%94)
      %95 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 307200 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%95)
      %96 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%96)
      %97 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%97)
      %98 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%98)
      %99 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%99)
      %100 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%100)
      %101 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%101)
      %102 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%102)
      %103 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%103)
      %104 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196608 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%104)
      %105 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196640 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%105)
      %106 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196672 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%106)
      %107 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196704 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%107)
      %108 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196736 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%108)
      %109 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196768 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%109)
      %110 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196800 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%110)
      %111 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 196832 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%111)
      aiex.dma_await_task(%104)
      aiex.dma_await_task(%105)
      aiex.dma_await_task(%106)
      aiex.dma_await_task(%107)
      aiex.dma_await_task(%108)
      aiex.dma_await_task(%109)
      aiex.dma_await_task(%110)
      aiex.dma_await_task(%111)
      aiex.dma_free_task(%92)
      aiex.dma_free_task(%93)
      aiex.dma_free_task(%94)
      aiex.dma_free_task(%95)
      aiex.dma_free_task(%96)
      aiex.dma_free_task(%97)
      aiex.dma_free_task(%98)
      aiex.dma_free_task(%99)
      aiex.dma_free_task(%100)
      aiex.dma_free_task(%101)
      aiex.dma_free_task(%102)
      aiex.dma_free_task(%103)
      aiex.dma_free_task(%104)
      aiex.dma_free_task(%105)
      aiex.dma_free_task(%106)
      aiex.dma_free_task(%107)
      aiex.dma_free_task(%108)
      aiex.dma_free_task(%109)
      aiex.dma_free_task(%110)
      aiex.dma_free_task(%111)
      %112 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 327680 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%112)
      %113 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 348160 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%113)
      %114 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 368640 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%114)
      %115 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 389120 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%115)
      %116 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%116)
      %117 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%117)
      %118 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%118)
      %119 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%119)
      %120 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%120)
      %121 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%121)
      %122 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%122)
      %123 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%123)
      %124 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262144 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%124)
      %125 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262176 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%125)
      %126 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262208 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%126)
      %127 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262240 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%127)
      %128 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262272 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%128)
      %129 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262304 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%129)
      %130 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262336 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%130)
      %131 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 262368 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%131)
      aiex.dma_await_task(%124)
      aiex.dma_await_task(%125)
      aiex.dma_await_task(%126)
      aiex.dma_await_task(%127)
      aiex.dma_await_task(%128)
      aiex.dma_await_task(%129)
      aiex.dma_await_task(%130)
      aiex.dma_await_task(%131)
      aiex.dma_free_task(%112)
      aiex.dma_free_task(%113)
      aiex.dma_free_task(%114)
      aiex.dma_free_task(%115)
      aiex.dma_free_task(%116)
      aiex.dma_free_task(%117)
      aiex.dma_free_task(%118)
      aiex.dma_free_task(%119)
      aiex.dma_free_task(%120)
      aiex.dma_free_task(%121)
      aiex.dma_free_task(%122)
      aiex.dma_free_task(%123)
      aiex.dma_free_task(%124)
      aiex.dma_free_task(%125)
      aiex.dma_free_task(%126)
      aiex.dma_free_task(%127)
      aiex.dma_free_task(%128)
      aiex.dma_free_task(%129)
      aiex.dma_free_task(%130)
      aiex.dma_free_task(%131)
      %132 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 409600 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%132)
      %133 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 430080 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%133)
      %134 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 450560 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%134)
      %135 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 471040 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%135)
      %136 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%136)
      %137 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%137)
      %138 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%138)
      %139 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%139)
      %140 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%140)
      %141 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%141)
      %142 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%142)
      %143 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%143)
      %144 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327680 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%144)
      %145 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327712 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%145)
      %146 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327744 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%146)
      %147 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327776 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%147)
      %148 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327808 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%148)
      %149 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327840 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%149)
      %150 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327872 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%150)
      %151 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 327904 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%151)
      aiex.dma_await_task(%144)
      aiex.dma_await_task(%145)
      aiex.dma_await_task(%146)
      aiex.dma_await_task(%147)
      aiex.dma_await_task(%148)
      aiex.dma_await_task(%149)
      aiex.dma_await_task(%150)
      aiex.dma_await_task(%151)
      aiex.dma_free_task(%132)
      aiex.dma_free_task(%133)
      aiex.dma_free_task(%134)
      aiex.dma_free_task(%135)
      aiex.dma_free_task(%136)
      aiex.dma_free_task(%137)
      aiex.dma_free_task(%138)
      aiex.dma_free_task(%139)
      aiex.dma_free_task(%140)
      aiex.dma_free_task(%141)
      aiex.dma_free_task(%142)
      aiex.dma_free_task(%143)
      aiex.dma_free_task(%144)
      aiex.dma_free_task(%145)
      aiex.dma_free_task(%146)
      aiex.dma_free_task(%147)
      aiex.dma_free_task(%148)
      aiex.dma_free_task(%149)
      aiex.dma_free_task(%150)
      aiex.dma_free_task(%151)
      %152 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 491520 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%152)
      %153 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 512000 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%153)
      %154 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 532480 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%154)
      %155 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 552960 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%155)
      %156 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%156)
      %157 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%157)
      %158 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%158)
      %159 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%159)
      %160 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%160)
      %161 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%161)
      %162 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%162)
      %163 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%163)
      %164 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393216 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%164)
      %165 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393248 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%165)
      %166 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393280 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%166)
      %167 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393312 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%167)
      %168 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393344 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%168)
      %169 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393376 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%169)
      %170 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393408 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%170)
      %171 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 393440 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%171)
      aiex.dma_await_task(%164)
      aiex.dma_await_task(%165)
      aiex.dma_await_task(%166)
      aiex.dma_await_task(%167)
      aiex.dma_await_task(%168)
      aiex.dma_await_task(%169)
      aiex.dma_await_task(%170)
      aiex.dma_await_task(%171)
      aiex.dma_free_task(%152)
      aiex.dma_free_task(%153)
      aiex.dma_free_task(%154)
      aiex.dma_free_task(%155)
      aiex.dma_free_task(%156)
      aiex.dma_free_task(%157)
      aiex.dma_free_task(%158)
      aiex.dma_free_task(%159)
      aiex.dma_free_task(%160)
      aiex.dma_free_task(%161)
      aiex.dma_free_task(%162)
      aiex.dma_free_task(%163)
      aiex.dma_free_task(%164)
      aiex.dma_free_task(%165)
      aiex.dma_free_task(%166)
      aiex.dma_free_task(%167)
      aiex.dma_free_task(%168)
      aiex.dma_free_task(%169)
      aiex.dma_free_task(%170)
      aiex.dma_free_task(%171)
      %172 = aiex.dma_configure_task_for @A_L3L2_0 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 573440 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%172)
      %173 = aiex.dma_configure_task_for @A_L3L2_1 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 593920 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%173)
      %174 = aiex.dma_configure_task_for @A_L3L2_2 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 614400 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%174)
      %175 = aiex.dma_configure_task_for @A_L3L2_3 {
        aie.dma_bd(%arg0 : memref<655360xui8> offset = 634880 len = 20480 sizes = [1, 1, 1, 20480] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%175)
      %176 = aiex.dma_configure_task_for @B_L3L2_0 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%176)
      %177 = aiex.dma_configure_task_for @B_L3L2_1 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%177)
      %178 = aiex.dma_configure_task_for @B_L3L2_2 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%178)
      %179 = aiex.dma_configure_task_for @B_L3L2_3 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%179)
      %180 = aiex.dma_configure_task_for @B_L3L2_4 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 8192 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%180)
      %181 = aiex.dma_configure_task_for @B_L3L2_5 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 10240 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%181)
      %182 = aiex.dma_configure_task_for @B_L3L2_6 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 12288 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%182)
      %183 = aiex.dma_configure_task_for @B_L3L2_7 {
        aie.dma_bd(%arg1 : memref<131072xbf16> offset = 14336 len = 16384 sizes = [1, 8, 64, 32] strides = [0, 16384, 32, 1])
        aie.end
      }
      aiex.dma_start_task(%183)
      %184 = aiex.dma_configure_task_for @C_L2L3_0 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458752 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%184)
      %185 = aiex.dma_configure_task_for @C_L2L3_1 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458784 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%185)
      %186 = aiex.dma_configure_task_for @C_L2L3_2 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458816 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%186)
      %187 = aiex.dma_configure_task_for @C_L2L3_3 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458848 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%187)
      %188 = aiex.dma_configure_task_for @C_L2L3_4 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458880 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%188)
      %189 = aiex.dma_configure_task_for @C_L2L3_5 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458912 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%189)
      %190 = aiex.dma_configure_task_for @C_L2L3_6 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458944 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%190)
      %191 = aiex.dma_configure_task_for @C_L2L3_7 {
        aie.dma_bd(%arg2 : memref<524288xf32> offset = 458976 len = 8192 sizes = [1, 1, 256, 32] strides = [0, 0, 256, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%191)
      aiex.dma_await_task(%184)
      aiex.dma_await_task(%185)
      aiex.dma_await_task(%186)
      aiex.dma_await_task(%187)
      aiex.dma_await_task(%188)
      aiex.dma_await_task(%189)
      aiex.dma_await_task(%190)
      aiex.dma_await_task(%191)
      aiex.dma_free_task(%172)
      aiex.dma_free_task(%173)
      aiex.dma_free_task(%174)
      aiex.dma_free_task(%175)
      aiex.dma_free_task(%176)
      aiex.dma_free_task(%177)
      aiex.dma_free_task(%178)
      aiex.dma_free_task(%179)
      aiex.dma_free_task(%180)
      aiex.dma_free_task(%181)
      aiex.dma_free_task(%182)
      aiex.dma_free_task(%183)
      aiex.dma_free_task(%184)
      aiex.dma_free_task(%185)
      aiex.dma_free_task(%186)
      aiex.dma_free_task(%187)
      aiex.dma_free_task(%188)
      aiex.dma_free_task(%189)
      aiex.dma_free_task(%190)
      aiex.dma_free_task(%191)
    }
  }
}
