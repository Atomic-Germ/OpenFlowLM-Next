module {
  aie.device(npu2) {
    %logical_core = aie.logical_tile<CoreTile>(0, 3)
    %logical_core_0 = aie.logical_tile<CoreTile>(0, 2)
    %logical_core_1 = aie.logical_tile<CoreTile>(1, 2)
    %logical_core_2 = aie.logical_tile<CoreTile>(2, 2)
    %logical_core_3 = aie.logical_tile<CoreTile>(3, 2)
    %logical_core_4 = aie.logical_tile<CoreTile>(4, 2)
    %logical_core_5 = aie.logical_tile<CoreTile>(5, 2)
    %logical_core_6 = aie.logical_tile<CoreTile>(6, 2)
    %logical_core_7 = aie.logical_tile<CoreTile>(7, 2)
    %logical_core_8 = aie.logical_tile<CoreTile>(1, 3)
    %logical_core_9 = aie.logical_tile<CoreTile>(2, 3)
    %logical_shim_noc = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_shim_noc_10 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_11 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_12 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_13 = aie.logical_tile<ShimNOCTile>(4, 0)
    %logical_shim_noc_14 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_15 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_16 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_17 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_18 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_19 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_shim_noc_20 = aie.logical_tile<ShimNOCTile>(4, 0)
    %logical_shim_noc_21 = aie.logical_tile<ShimNOCTile>(5, 0)
    %logical_shim_noc_22 = aie.logical_tile<ShimNOCTile>(6, 0)
    %logical_shim_noc_23 = aie.logical_tile<ShimNOCTile>(7, 0)
    %logical_shim_noc_24 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_25 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_26 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_27 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_28 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_shim_noc_29 = aie.logical_tile<ShimNOCTile>(4, 0)
    %logical_shim_noc_30 = aie.logical_tile<ShimNOCTile>(5, 0)
    %logical_shim_noc_31 = aie.logical_tile<ShimNOCTile>(6, 0)
    %logical_shim_noc_32 = aie.logical_tile<ShimNOCTile>(7, 0)
    aie.objectfifo @gact(%logical_shim_noc, {%logical_core_9}, 5 : i32) : !aie.objectfifo<memref<2048xui8>>  
    aie.objectfifo @gout(%logical_core_9, {%logical_shim_noc_10}, 3 : i32) : !aie.objectfifo<memref<2048xui8>>  
    aie.objectfifo @lni(%logical_shim_noc_11, {%logical_core}, 5 : i32) : !aie.objectfifo<memref<4096xui8>>  
    aie.objectfifo @lno(%logical_core, {%logical_shim_noc_12}, 3 : i32) : !aie.objectfifo<memref<4096xui8>>  
    aie.objectfifo @pin(%logical_shim_noc_13, {%logical_core_8}, 2 : i32) : !aie.objectfifo<memref<4096xui8>>  
    aie.objectfifo @pout(%logical_core_8, {%logical_shim_noc_14}, 2 : i32) : !aie.objectfifo<memref<2048xui8>>  
    aie.objectfifo @side(%logical_shim_noc_15, {%logical_core_9}, 2 : i32) : !aie.objectfifo<memref<4096xui8>>  
    aie.objectfifo @w0(%logical_shim_noc_16, {%logical_core_0}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w1(%logical_shim_noc_17, {%logical_core_1}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w2(%logical_shim_noc_18, {%logical_core_2}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w3(%logical_shim_noc_19, {%logical_core_3}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w4(%logical_shim_noc_20, {%logical_core_4}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w5(%logical_shim_noc_21, {%logical_core_5}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w6(%logical_shim_noc_22, {%logical_core_6}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @w7(%logical_shim_noc_23, {%logical_core_7}, 2 : i32) : !aie.objectfifo<memref<10240xui8>>  
    aie.objectfifo @x(%logical_shim_noc_24, {%logical_core_0, %logical_core_1, %logical_core_2, %logical_core_3, %logical_core_4, %logical_core_5, %logical_core_6, %logical_core_7}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @y0(%logical_core_0, {%logical_shim_noc_25}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y1(%logical_core_1, {%logical_shim_noc_26}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y2(%logical_core_2, {%logical_shim_noc_27}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y3(%logical_core_3, {%logical_shim_noc_28}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y4(%logical_core_4, {%logical_shim_noc_29}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y5(%logical_core_5, {%logical_shim_noc_30}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y6(%logical_core_6, {%logical_shim_noc_31}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    aie.objectfifo @y7(%logical_core_7, {%logical_shim_noc_32}, 2 : i32) : !aie.objectfifo<memref<64xf32>>  
    %rxs = aie.buffer(%logical_core) {sym_name = "rxs"} : memref<2048xbf16> 
    %racc = aie.buffer(%logical_core) {sym_name = "racc"} : memref<256xf32> 
    func.func private @ln_nr(memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) attributes {link_with = "ln_nr.o"}
    func.func private @ln_fn(memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) attributes {link_with = "ln_fn.o"}
    func.func private @router_copy_x(memref<4096xui8>, memref<2048xbf16>) attributes {link_with = "router_copy_x.o"}
    func.func private @router_acc(memref<4096xui8>, memref<2048xbf16>, memref<256xf32>, i32) attributes {link_with = "router_acc.o"}
    func.func private @router_fin(memref<256xf32>, memref<4096xui8>) attributes {link_with = "router_fin.o"}
    %tab0 = aie.buffer(%logical_core_0) {sym_name = "tab0"} : memref<9216xui8> 
    %ms0 = aie.buffer(%logical_core_0) {sym_name = "ms0"} : memref<928xf32> 
    %ds0 = aie.buffer(%logical_core_0) {sym_name = "ds0"} : memref<1280xf32> 
    func.func private @gemv_q4_gup(memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) attributes {link_with = "gemv_q4_gup.o"}
    func.func private @gemv_q4_gdown(memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) attributes {link_with = "gemv_q4_gdown.o"}
    func.func private @gemv_q4_prep_k2048(memref<2048xbf16>, memref<9216xui8>) attributes {link_with = "gemv_q4_prep_k2048.o"}
    func.func private @gemv_q4_prep_k4096_b0n64(memref<2048xbf16>, memref<9216xui8>) attributes {link_with = "gemv_q4_prep_k4096_b0n64.o"}
    func.func private @gemv_q4_prep_k4096_b64n64(memref<2048xbf16>, memref<9216xui8>) attributes {link_with = "gemv_q4_prep_k4096_b64n64.o"}
    func.func private @gemv_q4_prep_h(memref<2048xbf16>, memref<9216xui8>) attributes {link_with = "gemv_q4_prep_h.o"}
    func.func private @moe_hdr2(memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) attributes {link_with = "moe_hdr2.o"}
    func.func private @moe_silu32(memref<928xf32>, memref<64xf32>) attributes {link_with = "moe_silu32.o"}
    func.func private @moe_accfin(memref<928xf32>, i32) attributes {link_with = "moe_accfin.o"}
    func.func private @moe_out(memref<928xf32>, memref<64xf32>, i32) attributes {link_with = "moe_out.o"}
    func.func private @dnx_vcopy(memref<10240xui8>, memref<1280xf32>) attributes {link_with = "dnx_vcopy.o"}
    func.func private @dnx_pass1(memref<10240xui8>, memref<1280xf32>, i32) attributes {link_with = "dnx_pass1.o"}
    func.func private @dnx_delta(memref<1280xf32>) attributes {link_with = "dnx_delta.o"}
    func.func private @dnx_row(memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) attributes {link_with = "dnx_row.o"}
    func.func private @dnx_ofin(memref<1280xf32>, memref<64xf32>, i32) attributes {link_with = "dnx_ofin.o"}
    func.func private @gemv_q8_gy(memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) attributes {link_with = "gemv_q8_gy.o"}
    %tab1 = aie.buffer(%logical_core_1) {sym_name = "tab1"} : memref<9216xui8> 
    %ms1 = aie.buffer(%logical_core_1) {sym_name = "ms1"} : memref<928xf32> 
    %ds1 = aie.buffer(%logical_core_1) {sym_name = "ds1"} : memref<1280xf32> 
    %tab2 = aie.buffer(%logical_core_2) {sym_name = "tab2"} : memref<9216xui8> 
    %ms2 = aie.buffer(%logical_core_2) {sym_name = "ms2"} : memref<928xf32> 
    %ds2 = aie.buffer(%logical_core_2) {sym_name = "ds2"} : memref<1280xf32> 
    %tab3 = aie.buffer(%logical_core_3) {sym_name = "tab3"} : memref<9216xui8> 
    %ms3 = aie.buffer(%logical_core_3) {sym_name = "ms3"} : memref<928xf32> 
    %ds3 = aie.buffer(%logical_core_3) {sym_name = "ds3"} : memref<1280xf32> 
    %tab4 = aie.buffer(%logical_core_4) {sym_name = "tab4"} : memref<9216xui8> 
    %ms4 = aie.buffer(%logical_core_4) {sym_name = "ms4"} : memref<928xf32> 
    %ds4 = aie.buffer(%logical_core_4) {sym_name = "ds4"} : memref<1280xf32> 
    %tab5 = aie.buffer(%logical_core_5) {sym_name = "tab5"} : memref<9216xui8> 
    %ms5 = aie.buffer(%logical_core_5) {sym_name = "ms5"} : memref<928xf32> 
    %ds5 = aie.buffer(%logical_core_5) {sym_name = "ds5"} : memref<1280xf32> 
    %tab6 = aie.buffer(%logical_core_6) {sym_name = "tab6"} : memref<9216xui8> 
    %ms6 = aie.buffer(%logical_core_6) {sym_name = "ms6"} : memref<928xf32> 
    %ds6 = aie.buffer(%logical_core_6) {sym_name = "ds6"} : memref<1280xf32> 
    %tab7 = aie.buffer(%logical_core_7) {sym_name = "tab7"} : memref<9216xui8> 
    %ms7 = aie.buffer(%logical_core_7) {sym_name = "ms7"} : memref<928xf32> 
    %ds7 = aie.buffer(%logical_core_7) {sym_name = "ds7"} : memref<1280xf32> 
    %nwb = aie.buffer(%logical_core_8) {sym_name = "nwb"} : memref<128xbf16> 
    func.func private @post_fn(memref<4096xui8>, memref<4096xui8>, memref<128xbf16>, memref<2048xui8>) attributes {link_with = "post_fn.o"}
    func.func private @post_copy_nw(memref<4096xui8>, memref<128xbf16>) attributes {link_with = "post_copy_nw.o"}
    %acc_a = aie.buffer(%logical_core_9) {sym_name = "acc_a"} : memref<32xf32> 
    %acc_b = aie.buffer(%logical_core_9) {sym_name = "acc_b"} : memref<32xf32> 
    %decay = aie.buffer(%logical_core_9) {sym_name = "decay"} : memref<32xf32> 
    %beta = aie.buffer(%logical_core_9) {sym_name = "beta"} : memref<32xf32> 
    %qk = aie.buffer(%logical_core_9) {sym_name = "qk"} : memref<4096xf32> 
    %vt = aie.buffer(%logical_core_9) {sym_name = "vt"} : memref<1024xf32> 
    %xnb = aie.buffer(%logical_core_9) {sym_name = "xnb"} : memref<2048xbf16> 
    func.func private @glue_ab(memref<4096xui8>, memref<2048xbf16>, memref<32xf32>, i32) attributes {link_with = "glue_ab.o"}
    func.func private @glue_small_fn(memref<4096xui8>, memref<32xf32>, memref<32xf32>, memref<32xf32>, memref<32xf32>) attributes {link_with = "glue_small_fn.o"}
    func.func private @glue_conv(memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<4096xui8>, memref<4096xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<4096xf32>, memref<1024xf32>, i32, i32) attributes {link_with = "glue_conv.o"}
    func.func private @glue_emit_fn(memref<4096xf32>, memref<1024xf32>, memref<32xf32>, memref<32xf32>, memref<2048xui8>, i32, i32) attributes {link_with = "glue_emit_fn.o"}
    func.func private @glue_copy_xn(memref<4096xui8>, memref<2048xbf16>) attributes {link_with = "glue_copy_xn.o"}
    %core_0_3 = aie.core(%logical_core) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @lni(Consume, 3) : !aie.objectfifosubview<memref<4096xui8>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %2 = aie.objectfifo.subview.access %0[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %3 = aie.objectfifo.subview.access %0[2] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %4 = aie.objectfifo.acquire @lno(Produce, 1) : !aie.objectfifosubview<memref<4096xui8>>
        %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @ln_nr(%1, %2, %3, %5) : (memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) -> ()
        aie.objectfifo.release @lno(Produce, 1)
        aie.objectfifo.release @lni(Consume, 3)
        %6 = aie.objectfifo.acquire @lni(Consume, 5) : !aie.objectfifosubview<memref<4096xui8>>
        %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %8 = aie.objectfifo.subview.access %6[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %9 = aie.objectfifo.subview.access %6[2] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %10 = aie.objectfifo.subview.access %6[3] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %11 = aie.objectfifo.subview.access %6[4] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %12 = aie.objectfifo.acquire @lno(Produce, 3) : !aie.objectfifosubview<memref<4096xui8>>
        %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %14 = aie.objectfifo.subview.access %12[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %15 = aie.objectfifo.subview.access %12[2] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @ln_fn(%7, %8, %10, %11, %9, %13, %14, %15) : (memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) -> ()
        func.call @router_copy_x(%15, %rxs) : (memref<4096xui8>, memref<2048xbf16>) -> ()
        aie.objectfifo.release @lno(Produce, 3)
        aie.objectfifo.release @lni(Consume, 5)
        %c0_33 = arith.constant 0 : index
        %c256 = arith.constant 256 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c256 step %c1_34 {
          %18 = aie.objectfifo.acquire @lni(Consume, 1) : !aie.objectfifosubview<memref<4096xui8>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %20 = arith.index_cast %arg1 : index to i32
          func.call @router_acc(%19, %rxs, %racc, %20) : (memref<4096xui8>, memref<2048xbf16>, memref<256xf32>, i32) -> ()
          aie.objectfifo.release @lni(Consume, 1)
        }
        %16 = aie.objectfifo.acquire @lno(Produce, 1) : !aie.objectfifosubview<memref<4096xui8>>
        %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @router_fin(%racc, %17) : (memref<256xf32>, memref<4096xui8>) -> ()
        aie.objectfifo.release @lno(Produce, 1)
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_0_2 = aie.core(%logical_core_0) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab0) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab0, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w0(Consume, 1)
          }
          aie.objectfifo.release @y0(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds0) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w0(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds0, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w0(Consume, 1)
          }
          func.call @dnx_delta(%ds0) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds0, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y0(Produce, 1)
            }
            aie.objectfifo.release @w0(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds0, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y0(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab0) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab0) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab0, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w0(Consume, 1)
          }
          aie.objectfifo.release @y0(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab0) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms0, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w0(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab0, %ms0, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w0(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms0, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y0(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab0) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w0(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab0, %ms0, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w0(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms0, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y0(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms0, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y0(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_1_2 = aie.core(%logical_core_1) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab1) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab1, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w1(Consume, 1)
          }
          aie.objectfifo.release @y1(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds1) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w1(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds1, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w1(Consume, 1)
          }
          func.call @dnx_delta(%ds1) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds1, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y1(Produce, 1)
            }
            aie.objectfifo.release @w1(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds1, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y1(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab1) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab1) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab1, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w1(Consume, 1)
          }
          aie.objectfifo.release @y1(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab1) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms1, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w1(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab1, %ms1, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w1(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms1, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y1(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab1) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w1(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab1, %ms1, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w1(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms1, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y1(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms1, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y1(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_2_2 = aie.core(%logical_core_2) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab2) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab2, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w2(Consume, 1)
          }
          aie.objectfifo.release @y2(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds2) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w2(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds2, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w2(Consume, 1)
          }
          func.call @dnx_delta(%ds2) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds2, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y2(Produce, 1)
            }
            aie.objectfifo.release @w2(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds2, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y2(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab2) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab2) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab2, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w2(Consume, 1)
          }
          aie.objectfifo.release @y2(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab2) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms2, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w2(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab2, %ms2, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w2(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms2, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y2(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab2) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w2(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab2, %ms2, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w2(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms2, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y2(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms2, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y2(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_3_2 = aie.core(%logical_core_3) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab3) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab3, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w3(Consume, 1)
          }
          aie.objectfifo.release @y3(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds3) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w3(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds3, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w3(Consume, 1)
          }
          func.call @dnx_delta(%ds3) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds3, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y3(Produce, 1)
            }
            aie.objectfifo.release @w3(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds3, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y3(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab3) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab3) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab3, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w3(Consume, 1)
          }
          aie.objectfifo.release @y3(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab3) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms3, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w3(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab3, %ms3, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w3(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms3, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y3(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab3) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w3(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab3, %ms3, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w3(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms3, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y3(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms3, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y3(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_4_2 = aie.core(%logical_core_4) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab4) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab4, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w4(Consume, 1)
          }
          aie.objectfifo.release @y4(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds4) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w4(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds4, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w4(Consume, 1)
          }
          func.call @dnx_delta(%ds4) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds4, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y4(Produce, 1)
            }
            aie.objectfifo.release @w4(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds4, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y4(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab4) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab4) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab4, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w4(Consume, 1)
          }
          aie.objectfifo.release @y4(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab4) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms4, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w4(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab4, %ms4, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w4(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms4, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y4(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab4) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w4(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab4, %ms4, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w4(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms4, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y4(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms4, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y4(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_5_2 = aie.core(%logical_core_5) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab5) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab5, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w5(Consume, 1)
          }
          aie.objectfifo.release @y5(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds5) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w5(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds5, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w5(Consume, 1)
          }
          func.call @dnx_delta(%ds5) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds5, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y5(Produce, 1)
            }
            aie.objectfifo.release @w5(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds5, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y5(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab5) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab5) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab5, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w5(Consume, 1)
          }
          aie.objectfifo.release @y5(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab5) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms5, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w5(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab5, %ms5, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w5(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms5, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y5(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab5) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w5(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab5, %ms5, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w5(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms5, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y5(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms5, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y5(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_6_2 = aie.core(%logical_core_6) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab6) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab6, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w6(Consume, 1)
          }
          aie.objectfifo.release @y6(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds6) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w6(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds6, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w6(Consume, 1)
          }
          func.call @dnx_delta(%ds6) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds6, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y6(Produce, 1)
            }
            aie.objectfifo.release @w6(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds6, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y6(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab6) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab6) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab6, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w6(Consume, 1)
          }
          aie.objectfifo.release @y6(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab6) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms6, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w6(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab6, %ms6, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w6(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms6, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y6(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab6) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w6(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab6, %ms6, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w6(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms6, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y6(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms6, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y6(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_7_2 = aie.core(%logical_core_7) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%1, %tab7) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_33 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c24 step %c1_34 {
          %7 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c16 = arith.constant 16 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c16 step %c1_48 {
            %9 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c32_i32 = arith.constant 32 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab7, %8, %11, %c32_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w7(Consume, 1)
          }
          aie.objectfifo.release @y7(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_35 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_36 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c4 step %c1_36 {
          %7 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          func.call @dnx_vcopy(%8, %ds7) : (memref<10240xui8>, memref<1280xf32>) -> ()
          aie.objectfifo.release @w7(Consume, 1)
          %c0_47 = arith.constant 0 : index
          %c7 = arith.constant 7 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c7 step %c1_48 {
            %9 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_pass1(%10, %ds7, %11) : (memref<10240xui8>, memref<1280xf32>, i32) -> ()
            aie.objectfifo.release @w7(Consume, 1)
          }
          func.call @dnx_delta(%ds7) : (memref<1280xf32>) -> ()
          %c0_49 = arith.constant 0 : index
          %c7_50 = arith.constant 7 : index
          %c1_51 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c7_50 step %c1_51 {
            %9 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %c0_54 = arith.constant 0 : index
            %c40 = arith.constant 40 : index
            %c1_55 = arith.constant 1 : index
            scf.for %arg3 = %c0_54 to %c40 step %c1_55 {
              %11 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
              %12 = aie.objectfifo.subview.access %11[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
              %13 = arith.index_cast %arg2 : index to i32
              %14 = arith.index_cast %arg3 : index to i32
              func.call @dnx_row(%10, %ds7, %12, %13, %14) : (memref<10240xui8>, memref<1280xf32>, memref<64xf32>, i32, i32) -> ()
              aie.objectfifo.release @y7(Produce, 1)
            }
            aie.objectfifo.release @w7(Consume, 1)
          }
          %c0_52 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_53 = arith.constant 1 : index
          scf.for %arg2 = %c0_52 to %c2 step %c1_53 {
            %9 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
            %11 = arith.index_cast %arg2 : index to i32
            func.call @dnx_ofin(%ds7, %10, %11) : (memref<1280xf32>, memref<64xf32>, i32) -> ()
            aie.objectfifo.release @y7(Produce, 1)
          }
        }
        %2 = aie.objectfifo.acquire @x(Consume, 2) : !aie.objectfifosubview<memref<2048xbf16>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k4096_b0n64(%3, %tab7) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        func.call @gemv_q4_prep_k4096_b64n64(%4, %tab7) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_37 = arith.constant 0 : index
        %c4_38 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_37 to %c4_38 step %c1_39 {
          %7 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %c0_47 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c32 step %c1_48 {
            %9 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %11 = arith.index_cast %arg2 : index to i32
            %c64_i32 = arith.constant 64 : i32
            %c4_i32 = arith.constant 4 : i32
            func.call @gemv_q8_gy(%10, %tab7, %8, %11, %c64_i32, %c4_i32) : (memref<10240xui8>, memref<9216xui8>, memref<64xf32>, i32, i32, i32) -> ()
            aie.objectfifo.release @w7(Consume, 1)
          }
          aie.objectfifo.release @y7(Produce, 1)
        }
        aie.objectfifo.release @x(Consume, 2)
        %5 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
        %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
        func.call @gemv_q4_prep_k2048(%6, %tab7) : (memref<2048xbf16>, memref<9216xui8>) -> ()
        %c0_40 = arith.constant 0 : index
        %c3 = arith.constant 3 : index
        %c1_41 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c3 step %c1_41 {
          %7 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_hdr2(%8, %6, %ms7, %9) : (memref<10240xui8>, memref<2048xbf16>, memref<928xf32>, i32) -> ()
          aie.objectfifo.release @w7(Consume, 1)
        }
        aie.objectfifo.release @x(Consume, 1)
        %c0_42 = arith.constant 0 : index
        %c9 = arith.constant 9 : index
        %c1_43 = arith.constant 1 : index
        scf.for %arg1 = %c0_42 to %c9 step %c1_43 {
          %c0_47 = arith.constant 0 : index
          %c2 = arith.constant 2 : index
          %c1_48 = arith.constant 1 : index
          scf.for %arg2 = %c0_47 to %c2 step %c1_48 {
            %c0_51 = arith.constant 0 : index
            %c8_52 = arith.constant 8 : index
            %c1_53 = arith.constant 1 : index
            scf.for %arg3 = %c0_51 to %c8_52 step %c1_53 {
              %12 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
              %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
              %14 = arith.index_cast %arg3 : index to i32
              %15 = arith.index_cast %arg2 : index to i32
              func.call @gemv_q4_gup(%13, %tab7, %ms7, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
              aie.objectfifo.release @w7(Consume, 1)
            }
          }
          %7 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          func.call @moe_silu32(%ms7, %8) : (memref<928xf32>, memref<64xf32>) -> ()
          aie.objectfifo.release @y7(Produce, 1)
          %9 = aie.objectfifo.acquire @x(Consume, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %10 = aie.objectfifo.subview.access %9[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @gemv_q4_prep_h(%10, %tab7) : (memref<2048xbf16>, memref<9216xui8>) -> ()
          aie.objectfifo.release @x(Consume, 1)
          %c0_49 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_50 = arith.constant 1 : index
          scf.for %arg2 = %c0_49 to %c8 step %c1_50 {
            %12 = aie.objectfifo.acquire @w7(Consume, 1) : !aie.objectfifosubview<memref<10240xui8>>
            %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<10240xui8>> -> memref<10240xui8>
            %14 = arith.index_cast %arg2 : index to i32
            %15 = arith.index_cast %arg1 : index to i32
            func.call @gemv_q4_gdown(%13, %tab7, %ms7, %14, %15) : (memref<10240xui8>, memref<9216xui8>, memref<928xf32>, i32, i32) -> ()
            aie.objectfifo.release @w7(Consume, 1)
          }
          %11 = arith.index_cast %arg1 : index to i32
          func.call @moe_accfin(%ms7, %11) : (memref<928xf32>, i32) -> ()
        }
        %c0_44 = arith.constant 0 : index
        %c4_45 = arith.constant 4 : index
        %c1_46 = arith.constant 1 : index
        scf.for %arg1 = %c0_44 to %c4_45 step %c1_46 {
          %7 = aie.objectfifo.acquire @y7(Produce, 1) : !aie.objectfifosubview<memref<64xf32>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<64xf32>> -> memref<64xf32>
          %9 = arith.index_cast %arg1 : index to i32
          func.call @moe_out(%ms7, %8, %9) : (memref<928xf32>, memref<64xf32>, i32) -> ()
          aie.objectfifo.release @y7(Produce, 1)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_1_3 = aie.core(%logical_core_8) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @pin(Consume, 1) : !aie.objectfifosubview<memref<4096xui8>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @post_copy_nw(%1, %nwb) : (memref<4096xui8>, memref<128xbf16>) -> ()
        aie.objectfifo.release @pin(Consume, 1)
        %c0_33 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c4 step %c1_34 {
          %2 = aie.objectfifo.acquire @pin(Consume, 2) : !aie.objectfifosubview<memref<4096xui8>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %4 = aie.objectfifo.subview.access %2[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %5 = aie.objectfifo.acquire @pout(Produce, 1) : !aie.objectfifosubview<memref<2048xui8>>
          %6 = aie.objectfifo.subview.access %5[0] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          func.call @post_fn(%3, %4, %nwb, %6) : (memref<4096xui8>, memref<4096xui8>, memref<128xbf16>, memref<2048xui8>) -> ()
          aie.objectfifo.release @pout(Produce, 1)
          aie.objectfifo.release @pin(Consume, 2)
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    %core_2_3 = aie.core(%logical_core_9) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @side(Consume, 1) : !aie.objectfifosubview<memref<4096xui8>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @glue_copy_xn(%1, %xnb) : (memref<4096xui8>, memref<2048xbf16>) -> ()
        aie.objectfifo.release @side(Consume, 1)
        %c0_33 = arith.constant 0 : index
        %c32 = arith.constant 32 : index
        %c1_34 = arith.constant 1 : index
        scf.for %arg1 = %c0_33 to %c32 step %c1_34 {
          %4 = aie.objectfifo.acquire @side(Consume, 1) : !aie.objectfifosubview<memref<4096xui8>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %6 = arith.index_cast %arg1 : index to i32
          func.call @glue_ab(%5, %xnb, %acc_a, %6) : (memref<4096xui8>, memref<2048xbf16>, memref<32xf32>, i32) -> ()
          aie.objectfifo.release @side(Consume, 1)
        }
        %c0_35 = arith.constant 0 : index
        %c32_36 = arith.constant 32 : index
        %c1_37 = arith.constant 1 : index
        scf.for %arg1 = %c0_35 to %c32_36 step %c1_37 {
          %4 = aie.objectfifo.acquire @side(Consume, 1) : !aie.objectfifosubview<memref<4096xui8>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %6 = arith.index_cast %arg1 : index to i32
          func.call @glue_ab(%5, %xnb, %acc_b, %6) : (memref<4096xui8>, memref<2048xbf16>, memref<32xf32>, i32) -> ()
          aie.objectfifo.release @side(Consume, 1)
        }
        %2 = aie.objectfifo.acquire @side(Consume, 1) : !aie.objectfifosubview<memref<4096xui8>>
        %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @glue_small_fn(%3, %acc_a, %acc_b, %decay, %beta) : (memref<4096xui8>, memref<32xf32>, memref<32xf32>, memref<32xf32>, memref<32xf32>) -> ()
        aie.objectfifo.release @side(Consume, 1)
        %c0_38 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_39 = arith.constant 1 : index
        scf.for %arg1 = %c0_38 to %c4 step %c1_39 {
          %4 = aie.objectfifo.acquire @side(Consume, 2) : !aie.objectfifosubview<memref<4096xui8>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %6 = aie.objectfifo.subview.access %4[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %7 = aie.objectfifo.acquire @gact(Consume, 5) : !aie.objectfifosubview<memref<2048xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %9 = aie.objectfifo.subview.access %7[1] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %10 = aie.objectfifo.subview.access %7[2] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %11 = aie.objectfifo.subview.access %7[3] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %12 = aie.objectfifo.subview.access %7[4] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %13 = aie.objectfifo.acquire @gout(Produce, 3) : !aie.objectfifosubview<memref<2048xui8>>
          %14 = aie.objectfifo.subview.access %13[0] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %15 = aie.objectfifo.subview.access %13[1] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %16 = aie.objectfifo.subview.access %13[2] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %17 = arith.index_cast %arg1 : index to i32
          %c0_i32 = arith.constant 0 : i32
          func.call @glue_conv(%8, %9, %10, %11, %12, %5, %6, %14, %15, %16, %qk, %vt, %17, %c0_i32) : (memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<4096xui8>, memref<4096xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<4096xf32>, memref<1024xf32>, i32, i32) -> ()
          aie.objectfifo.release @gout(Produce, 3)
          aie.objectfifo.release @gact(Consume, 5)
          aie.objectfifo.release @side(Consume, 2)
        }
        %c0_40 = arith.constant 0 : index
        %c4_41 = arith.constant 4 : index
        %c1_42 = arith.constant 1 : index
        scf.for %arg1 = %c0_40 to %c4_41 step %c1_42 {
          %4 = aie.objectfifo.acquire @side(Consume, 2) : !aie.objectfifosubview<memref<4096xui8>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %6 = aie.objectfifo.subview.access %4[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
          %7 = aie.objectfifo.acquire @gact(Consume, 5) : !aie.objectfifosubview<memref<2048xui8>>
          %8 = aie.objectfifo.subview.access %7[0] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %9 = aie.objectfifo.subview.access %7[1] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %10 = aie.objectfifo.subview.access %7[2] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %11 = aie.objectfifo.subview.access %7[3] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %12 = aie.objectfifo.subview.access %7[4] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %13 = aie.objectfifo.acquire @gout(Produce, 3) : !aie.objectfifosubview<memref<2048xui8>>
          %14 = aie.objectfifo.subview.access %13[0] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %15 = aie.objectfifo.subview.access %13[1] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %16 = aie.objectfifo.subview.access %13[2] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
          %17 = arith.index_cast %arg1 : index to i32
          %c4_i32 = arith.constant 4 : i32
          func.call @glue_conv(%8, %9, %10, %11, %12, %5, %6, %14, %15, %16, %qk, %vt, %17, %c4_i32) : (memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<4096xui8>, memref<4096xui8>, memref<2048xui8>, memref<2048xui8>, memref<2048xui8>, memref<4096xf32>, memref<1024xf32>, i32, i32) -> ()
          aie.objectfifo.release @gout(Produce, 3)
          aie.objectfifo.release @gact(Consume, 5)
          aie.objectfifo.release @side(Consume, 2)
          %c0_43 = arith.constant 0 : index
          %c8 = arith.constant 8 : index
          %c1_44 = arith.constant 1 : index
          scf.for %arg2 = %c0_43 to %c8 step %c1_44 {
            %18 = aie.objectfifo.acquire @gout(Produce, 1) : !aie.objectfifosubview<memref<2048xui8>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<2048xui8>> -> memref<2048xui8>
            %20 = arith.index_cast %arg1 : index to i32
            %21 = arith.index_cast %arg2 : index to i32
            func.call @glue_emit_fn(%qk, %vt, %decay, %beta, %19, %20, %21) : (memref<4096xf32>, memref<1024xf32>, memref<32xf32>, memref<32xf32>, memref<2048xui8>, i32, i32) -> ()
            aie.objectfifo.release @gout(Produce, 1)
          }
        }
      }
      aie.end
    } {stack_size = 6144 : i32}
    aie.runtime_sequence(%arg0: memref<540016640xui8>, %arg1: memref<2048xf32>, %arg2: memref<11882496xui8>, %arg3: memref<2342912xui8>, %arg4: memref<190464xui8>) {
      %0 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 172032 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%0)
      %1 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%1)
      %2 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%2)
      %3 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 151552 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%3)
      %4 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%4)
      %5 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%5)
      %6 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 152576 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%6)
      %7 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%7)
      %8 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%8)
      %9 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 153600 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%9)
      %10 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%10)
      %11 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%11)
      %12 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 154624 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%12)
      %13 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%13)
      %14 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%14)
      %15 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 155648 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%15)
      %16 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%16)
      %17 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%17)
      %18 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 156672 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%18)
      %19 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%19)
      %20 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%20)
      %21 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 157696 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%21)
      %22 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 176128 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%22)
      %23 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg2 : memref<11882496xui8> offset = 1392640 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%23)
      %24 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 158720 len = 10240 sizes = [1, 1, 1, 10240] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%24)
      aiex.dma_await_task(%1)
      aiex.dma_free_task(%1)
      %25 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 0 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%25)
      aiex.dma_await_task(%2)
      aiex.dma_free_task(%2)
      %26 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 163840 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%26)
      %27 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%27)
      aiex.dma_await_task(%4)
      aiex.dma_free_task(%4)
      %28 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 10240 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%28)
      aiex.dma_await_task(%5)
      aiex.dma_free_task(%5)
      %29 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 174080 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%29)
      %30 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%30)
      aiex.dma_await_task(%7)
      aiex.dma_free_task(%7)
      %31 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 327680 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%31)
      aiex.dma_await_task(%8)
      aiex.dma_free_task(%8)
      %32 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 491520 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%32)
      %33 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%33)
      aiex.dma_await_task(%10)
      aiex.dma_free_task(%10)
      %34 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337920 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%34)
      aiex.dma_await_task(%11)
      aiex.dma_free_task(%11)
      %35 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 501760 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%35)
      %36 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%36)
      aiex.dma_await_task(%13)
      aiex.dma_free_task(%13)
      %37 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 655360 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%37)
      aiex.dma_await_task(%14)
      aiex.dma_free_task(%14)
      %38 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 819200 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%38)
      %39 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%39)
      aiex.dma_await_task(%16)
      aiex.dma_free_task(%16)
      %40 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 665600 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%40)
      aiex.dma_await_task(%17)
      aiex.dma_free_task(%17)
      %41 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 829440 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%41)
      %42 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%42)
      aiex.dma_await_task(%19)
      aiex.dma_free_task(%19)
      %43 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 983040 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%43)
      aiex.dma_await_task(%20)
      aiex.dma_free_task(%20)
      %44 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1146880 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%44)
      %45 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%45)
      aiex.dma_await_task(%22)
      aiex.dma_free_task(%22)
      %46 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 993280 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%46)
      aiex.dma_await_task(%23)
      aiex.dma_free_task(%23)
      %47 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1157120 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%47)
      %48 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%48)
      aiex.dma_await_task(%27)
      aiex.dma_free_task(%27)
      aiex.dma_await_task(%30)
      aiex.dma_free_task(%30)
      aiex.dma_await_task(%33)
      aiex.dma_free_task(%33)
      aiex.dma_await_task(%36)
      aiex.dma_free_task(%36)
      aiex.dma_await_task(%39)
      aiex.dma_free_task(%39)
      aiex.dma_await_task(%42)
      aiex.dma_free_task(%42)
      aiex.dma_await_task(%45)
      aiex.dma_free_task(%45)
      aiex.dma_await_task(%48)
      aiex.dma_free_task(%48)
      %49 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%49)
      aiex.dma_await_task(%3)
      aiex.dma_free_task(%3)
      %50 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 335544320 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%50)
      aiex.dma_await_task(%6)
      aiex.dma_free_task(%6)
      %51 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 335626240 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%51)
      aiex.dma_await_task(%9)
      aiex.dma_free_task(%9)
      %52 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 335708160 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%52)
      aiex.dma_await_task(%12)
      aiex.dma_free_task(%12)
      %53 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 335790080 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%53)
      aiex.dma_await_task(%15)
      aiex.dma_free_task(%15)
      %54 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 335872000 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%54)
      aiex.dma_await_task(%18)
      aiex.dma_free_task(%18)
      %55 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 335953920 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%55)
      aiex.dma_await_task(%21)
      aiex.dma_free_task(%21)
      %56 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336035840 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%56)
      aiex.dma_await_task(%24)
      aiex.dma_free_task(%24)
      %57 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336117760 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%57)
      aiex.dma_await_task(%25)
      aiex.dma_free_task(%25)
      %58 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1310720 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%58)
      aiex.dma_await_task(%26)
      aiex.dma_free_task(%26)
      %59 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1474560 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%59)
      %60 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%60)
      aiex.dma_await_task(%28)
      aiex.dma_free_task(%28)
      %61 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1320960 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%61)
      aiex.dma_await_task(%29)
      aiex.dma_free_task(%29)
      %62 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1484800 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%62)
      %63 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%63)
      aiex.dma_await_task(%31)
      aiex.dma_free_task(%31)
      %64 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1638400 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%64)
      aiex.dma_await_task(%32)
      aiex.dma_free_task(%32)
      %65 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1802240 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%65)
      %66 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%66)
      aiex.dma_await_task(%34)
      aiex.dma_free_task(%34)
      %67 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1648640 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%67)
      aiex.dma_await_task(%35)
      aiex.dma_free_task(%35)
      %68 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1812480 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%68)
      %69 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%69)
      aiex.dma_await_task(%37)
      aiex.dma_free_task(%37)
      %70 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1966080 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%70)
      aiex.dma_await_task(%38)
      aiex.dma_free_task(%38)
      %71 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2129920 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%71)
      %72 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%72)
      aiex.dma_await_task(%40)
      aiex.dma_free_task(%40)
      %73 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 1976320 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%73)
      aiex.dma_await_task(%41)
      aiex.dma_free_task(%41)
      %74 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2140160 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%74)
      %75 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%75)
      aiex.dma_await_task(%43)
      aiex.dma_free_task(%43)
      %76 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2293760 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%76)
      aiex.dma_await_task(%44)
      aiex.dma_free_task(%44)
      %77 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2457600 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%77)
      %78 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%78)
      aiex.dma_await_task(%46)
      aiex.dma_free_task(%46)
      %79 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2304000 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%79)
      aiex.dma_await_task(%47)
      aiex.dma_free_task(%47)
      %80 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2467840 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%80)
      %81 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%81)
      aiex.dma_await_task(%60)
      aiex.dma_free_task(%60)
      aiex.dma_await_task(%63)
      aiex.dma_free_task(%63)
      aiex.dma_await_task(%66)
      aiex.dma_free_task(%66)
      aiex.dma_await_task(%69)
      aiex.dma_free_task(%69)
      aiex.dma_await_task(%72)
      aiex.dma_free_task(%72)
      aiex.dma_await_task(%75)
      aiex.dma_free_task(%75)
      aiex.dma_await_task(%78)
      aiex.dma_free_task(%78)
      aiex.dma_await_task(%81)
      aiex.dma_free_task(%81)
      %82 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%82)
      aiex.dma_await_task(%50)
      aiex.dma_free_task(%50)
      %83 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336199680 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%83)
      aiex.dma_await_task(%51)
      aiex.dma_free_task(%51)
      %84 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336281600 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%84)
      aiex.dma_await_task(%52)
      aiex.dma_free_task(%52)
      %85 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336363520 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%85)
      aiex.dma_await_task(%53)
      aiex.dma_free_task(%53)
      %86 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336445440 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%86)
      aiex.dma_await_task(%54)
      aiex.dma_free_task(%54)
      %87 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336527360 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%87)
      aiex.dma_await_task(%55)
      aiex.dma_free_task(%55)
      %88 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336609280 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%88)
      aiex.dma_await_task(%56)
      aiex.dma_free_task(%56)
      %89 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336691200 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%89)
      aiex.dma_await_task(%57)
      aiex.dma_free_task(%57)
      %90 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336773120 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%90)
      aiex.dma_await_task(%58)
      aiex.dma_free_task(%58)
      %91 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2621440 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%91)
      aiex.dma_await_task(%59)
      aiex.dma_free_task(%59)
      %92 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2785280 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%92)
      %93 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%93)
      aiex.dma_await_task(%61)
      aiex.dma_free_task(%61)
      %94 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2631680 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%94)
      aiex.dma_await_task(%62)
      aiex.dma_free_task(%62)
      %95 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2795520 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%95)
      %96 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%96)
      aiex.dma_await_task(%64)
      aiex.dma_free_task(%64)
      %97 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2949120 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%97)
      aiex.dma_await_task(%65)
      aiex.dma_free_task(%65)
      %98 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3112960 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%98)
      %99 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%99)
      aiex.dma_await_task(%67)
      aiex.dma_free_task(%67)
      %100 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 2959360 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%100)
      aiex.dma_await_task(%68)
      aiex.dma_free_task(%68)
      %101 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3123200 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%101)
      %102 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%102)
      aiex.dma_await_task(%70)
      aiex.dma_free_task(%70)
      %103 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3276800 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%103)
      aiex.dma_await_task(%71)
      aiex.dma_free_task(%71)
      %104 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3440640 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%104)
      %105 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%105)
      aiex.dma_await_task(%73)
      aiex.dma_free_task(%73)
      %106 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3287040 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%106)
      aiex.dma_await_task(%74)
      aiex.dma_free_task(%74)
      %107 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3450880 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%107)
      %108 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%108)
      aiex.dma_await_task(%76)
      aiex.dma_free_task(%76)
      %109 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3604480 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%109)
      aiex.dma_await_task(%77)
      aiex.dma_free_task(%77)
      %110 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3768320 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%110)
      %111 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%111)
      aiex.dma_await_task(%79)
      aiex.dma_free_task(%79)
      %112 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3614720 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%112)
      aiex.dma_await_task(%80)
      aiex.dma_free_task(%80)
      %113 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3778560 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%113)
      %114 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%114)
      aiex.dma_await_task(%93)
      aiex.dma_free_task(%93)
      aiex.dma_await_task(%96)
      aiex.dma_free_task(%96)
      aiex.dma_await_task(%99)
      aiex.dma_free_task(%99)
      aiex.dma_await_task(%102)
      aiex.dma_free_task(%102)
      aiex.dma_await_task(%105)
      aiex.dma_free_task(%105)
      aiex.dma_await_task(%108)
      aiex.dma_free_task(%108)
      aiex.dma_await_task(%111)
      aiex.dma_free_task(%111)
      aiex.dma_await_task(%114)
      aiex.dma_free_task(%114)
      aiex.dma_await_task(%0)
      aiex.dma_free_task(%0)
      %115 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%115)
      aiex.dma_await_task(%83)
      aiex.dma_free_task(%83)
      %116 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336855040 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%116)
      aiex.dma_await_task(%84)
      aiex.dma_free_task(%84)
      %117 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 336936960 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%117)
      aiex.dma_await_task(%85)
      aiex.dma_free_task(%85)
      %118 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337018880 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%118)
      aiex.dma_await_task(%86)
      aiex.dma_free_task(%86)
      %119 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337100800 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%119)
      aiex.dma_await_task(%87)
      aiex.dma_free_task(%87)
      %120 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337182720 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%120)
      aiex.dma_await_task(%88)
      aiex.dma_free_task(%88)
      %121 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337264640 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%121)
      aiex.dma_await_task(%89)
      aiex.dma_free_task(%89)
      %122 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337346560 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%122)
      aiex.dma_await_task(%90)
      aiex.dma_free_task(%90)
      %123 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337428480 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%123)
      aiex.dma_await_task(%91)
      aiex.dma_free_task(%91)
      %124 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3932160 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%124)
      aiex.dma_await_task(%92)
      aiex.dma_free_task(%92)
      %125 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4096000 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%125)
      %126 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%126)
      aiex.dma_await_task(%94)
      aiex.dma_free_task(%94)
      %127 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 3942400 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%127)
      aiex.dma_await_task(%95)
      aiex.dma_free_task(%95)
      %128 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4106240 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%128)
      %129 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%129)
      aiex.dma_await_task(%97)
      aiex.dma_free_task(%97)
      %130 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4259840 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%130)
      aiex.dma_await_task(%98)
      aiex.dma_free_task(%98)
      %131 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4423680 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%131)
      %132 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%132)
      aiex.dma_await_task(%100)
      aiex.dma_free_task(%100)
      %133 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4270080 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%133)
      aiex.dma_await_task(%101)
      aiex.dma_free_task(%101)
      %134 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4433920 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%134)
      %135 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%135)
      aiex.dma_await_task(%103)
      aiex.dma_free_task(%103)
      %136 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4587520 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%136)
      aiex.dma_await_task(%104)
      aiex.dma_free_task(%104)
      %137 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4751360 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%137)
      %138 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%138)
      aiex.dma_await_task(%106)
      aiex.dma_free_task(%106)
      %139 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4597760 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%139)
      aiex.dma_await_task(%107)
      aiex.dma_free_task(%107)
      %140 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4761600 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%140)
      %141 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%141)
      aiex.dma_await_task(%109)
      aiex.dma_free_task(%109)
      %142 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4915200 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%142)
      aiex.dma_await_task(%110)
      aiex.dma_free_task(%110)
      %143 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5079040 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%143)
      %144 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%144)
      aiex.dma_await_task(%112)
      aiex.dma_free_task(%112)
      %145 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 4925440 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%145)
      aiex.dma_await_task(%113)
      aiex.dma_free_task(%113)
      %146 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5089280 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%146)
      %147 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%147)
      aiex.dma_await_task(%126)
      aiex.dma_free_task(%126)
      aiex.dma_await_task(%129)
      aiex.dma_free_task(%129)
      aiex.dma_await_task(%132)
      aiex.dma_free_task(%132)
      aiex.dma_await_task(%135)
      aiex.dma_free_task(%135)
      aiex.dma_await_task(%138)
      aiex.dma_free_task(%138)
      aiex.dma_await_task(%141)
      aiex.dma_free_task(%141)
      aiex.dma_await_task(%144)
      aiex.dma_free_task(%144)
      aiex.dma_await_task(%147)
      aiex.dma_free_task(%147)
      aiex.dma_await_task(%49)
      aiex.dma_free_task(%49)
      %148 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%148)
      aiex.dma_await_task(%116)
      aiex.dma_free_task(%116)
      %149 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337510400 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%149)
      aiex.dma_await_task(%117)
      aiex.dma_free_task(%117)
      %150 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337592320 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%150)
      aiex.dma_await_task(%118)
      aiex.dma_free_task(%118)
      %151 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337674240 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%151)
      aiex.dma_await_task(%119)
      aiex.dma_free_task(%119)
      %152 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337756160 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%152)
      aiex.dma_await_task(%120)
      aiex.dma_free_task(%120)
      %153 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337838080 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%153)
      aiex.dma_await_task(%121)
      aiex.dma_free_task(%121)
      %154 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 337920000 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%154)
      aiex.dma_await_task(%122)
      aiex.dma_free_task(%122)
      %155 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338001920 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%155)
      aiex.dma_await_task(%123)
      aiex.dma_free_task(%123)
      %156 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338083840 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%156)
      aiex.dma_await_task(%124)
      aiex.dma_free_task(%124)
      %157 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5242880 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%157)
      aiex.dma_await_task(%125)
      aiex.dma_free_task(%125)
      %158 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5406720 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%158)
      %159 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%159)
      aiex.dma_await_task(%127)
      aiex.dma_free_task(%127)
      %160 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5253120 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%160)
      aiex.dma_await_task(%128)
      aiex.dma_free_task(%128)
      %161 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5416960 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%161)
      %162 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%162)
      aiex.dma_await_task(%130)
      aiex.dma_free_task(%130)
      %163 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5570560 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%163)
      aiex.dma_await_task(%131)
      aiex.dma_free_task(%131)
      %164 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5734400 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%164)
      %165 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%165)
      aiex.dma_await_task(%133)
      aiex.dma_free_task(%133)
      %166 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5580800 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%166)
      aiex.dma_await_task(%134)
      aiex.dma_free_task(%134)
      %167 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5744640 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%167)
      %168 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%168)
      aiex.dma_await_task(%136)
      aiex.dma_free_task(%136)
      %169 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5898240 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%169)
      aiex.dma_await_task(%137)
      aiex.dma_free_task(%137)
      %170 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6062080 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%170)
      %171 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%171)
      aiex.dma_await_task(%139)
      aiex.dma_free_task(%139)
      %172 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 5908480 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%172)
      aiex.dma_await_task(%140)
      aiex.dma_free_task(%140)
      %173 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6072320 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%173)
      %174 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%174)
      aiex.dma_await_task(%142)
      aiex.dma_free_task(%142)
      %175 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6225920 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%175)
      aiex.dma_await_task(%143)
      aiex.dma_free_task(%143)
      %176 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6389760 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%176)
      %177 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%177)
      aiex.dma_await_task(%145)
      aiex.dma_free_task(%145)
      %178 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6236160 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%178)
      aiex.dma_await_task(%146)
      aiex.dma_free_task(%146)
      %179 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6400000 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%179)
      %180 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%180)
      aiex.dma_await_task(%159)
      aiex.dma_free_task(%159)
      aiex.dma_await_task(%162)
      aiex.dma_free_task(%162)
      aiex.dma_await_task(%165)
      aiex.dma_free_task(%165)
      aiex.dma_await_task(%168)
      aiex.dma_free_task(%168)
      aiex.dma_await_task(%171)
      aiex.dma_free_task(%171)
      aiex.dma_await_task(%174)
      aiex.dma_free_task(%174)
      aiex.dma_await_task(%177)
      aiex.dma_free_task(%177)
      aiex.dma_await_task(%180)
      aiex.dma_free_task(%180)
      aiex.dma_await_task(%82)
      aiex.dma_free_task(%82)
      %181 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%181)
      aiex.dma_await_task(%149)
      aiex.dma_free_task(%149)
      %182 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338165760 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%182)
      aiex.dma_await_task(%150)
      aiex.dma_free_task(%150)
      %183 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338247680 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%183)
      aiex.dma_await_task(%151)
      aiex.dma_free_task(%151)
      %184 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338329600 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%184)
      aiex.dma_await_task(%152)
      aiex.dma_free_task(%152)
      %185 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338411520 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%185)
      aiex.dma_await_task(%153)
      aiex.dma_free_task(%153)
      %186 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338493440 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%186)
      aiex.dma_await_task(%154)
      aiex.dma_free_task(%154)
      %187 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338575360 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%187)
      aiex.dma_await_task(%155)
      aiex.dma_free_task(%155)
      %188 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338657280 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%188)
      aiex.dma_await_task(%156)
      aiex.dma_free_task(%156)
      %189 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338739200 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%189)
      aiex.dma_await_task(%157)
      aiex.dma_free_task(%157)
      %190 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6553600 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%190)
      aiex.dma_await_task(%158)
      aiex.dma_free_task(%158)
      %191 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6717440 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%191)
      %192 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%192)
      aiex.dma_await_task(%160)
      aiex.dma_free_task(%160)
      %193 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6563840 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%193)
      aiex.dma_await_task(%161)
      aiex.dma_free_task(%161)
      %194 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6727680 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%194)
      %195 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%195)
      aiex.dma_await_task(%163)
      aiex.dma_free_task(%163)
      %196 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6881280 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%196)
      aiex.dma_await_task(%164)
      aiex.dma_free_task(%164)
      %197 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7045120 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%197)
      %198 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%198)
      aiex.dma_await_task(%166)
      aiex.dma_free_task(%166)
      %199 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 6891520 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%199)
      aiex.dma_await_task(%167)
      aiex.dma_free_task(%167)
      %200 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7055360 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%200)
      %201 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%201)
      aiex.dma_await_task(%169)
      aiex.dma_free_task(%169)
      %202 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7208960 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%202)
      aiex.dma_await_task(%170)
      aiex.dma_free_task(%170)
      %203 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7372800 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%203)
      %204 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%204)
      aiex.dma_await_task(%172)
      aiex.dma_free_task(%172)
      %205 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7219200 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%205)
      aiex.dma_await_task(%173)
      aiex.dma_free_task(%173)
      %206 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7383040 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%206)
      %207 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%207)
      aiex.dma_await_task(%175)
      aiex.dma_free_task(%175)
      %208 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7536640 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%208)
      aiex.dma_await_task(%176)
      aiex.dma_free_task(%176)
      %209 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7700480 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%209)
      %210 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%210)
      aiex.dma_await_task(%178)
      aiex.dma_free_task(%178)
      %211 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7546880 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%211)
      aiex.dma_await_task(%179)
      aiex.dma_free_task(%179)
      %212 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7710720 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%212)
      %213 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%213)
      aiex.dma_await_task(%192)
      aiex.dma_free_task(%192)
      aiex.dma_await_task(%195)
      aiex.dma_free_task(%195)
      aiex.dma_await_task(%198)
      aiex.dma_free_task(%198)
      aiex.dma_await_task(%201)
      aiex.dma_free_task(%201)
      aiex.dma_await_task(%204)
      aiex.dma_free_task(%204)
      aiex.dma_await_task(%207)
      aiex.dma_free_task(%207)
      aiex.dma_await_task(%210)
      aiex.dma_free_task(%210)
      aiex.dma_await_task(%213)
      aiex.dma_free_task(%213)
      aiex.dma_await_task(%115)
      aiex.dma_free_task(%115)
      %214 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%214)
      aiex.dma_await_task(%182)
      aiex.dma_free_task(%182)
      %215 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338821120 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%215)
      aiex.dma_await_task(%183)
      aiex.dma_free_task(%183)
      %216 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338903040 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%216)
      aiex.dma_await_task(%184)
      aiex.dma_free_task(%184)
      %217 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 338984960 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%217)
      aiex.dma_await_task(%185)
      aiex.dma_free_task(%185)
      %218 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339066880 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%218)
      aiex.dma_await_task(%186)
      aiex.dma_free_task(%186)
      %219 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339148800 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%219)
      aiex.dma_await_task(%187)
      aiex.dma_free_task(%187)
      %220 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339230720 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%220)
      aiex.dma_await_task(%188)
      aiex.dma_free_task(%188)
      %221 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339312640 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%221)
      aiex.dma_await_task(%189)
      aiex.dma_free_task(%189)
      %222 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339394560 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%222)
      aiex.dma_await_task(%190)
      aiex.dma_free_task(%190)
      %223 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7864320 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%223)
      aiex.dma_await_task(%191)
      aiex.dma_free_task(%191)
      %224 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8028160 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%224)
      %225 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%225)
      aiex.dma_await_task(%193)
      aiex.dma_free_task(%193)
      %226 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 7874560 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%226)
      aiex.dma_await_task(%194)
      aiex.dma_free_task(%194)
      %227 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8038400 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%227)
      %228 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%228)
      aiex.dma_await_task(%196)
      aiex.dma_free_task(%196)
      %229 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8192000 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%229)
      aiex.dma_await_task(%197)
      aiex.dma_free_task(%197)
      %230 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8355840 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%230)
      %231 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%231)
      aiex.dma_await_task(%199)
      aiex.dma_free_task(%199)
      %232 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8202240 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%232)
      aiex.dma_await_task(%200)
      aiex.dma_free_task(%200)
      %233 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8366080 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%233)
      %234 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%234)
      aiex.dma_await_task(%202)
      aiex.dma_free_task(%202)
      %235 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8519680 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%235)
      aiex.dma_await_task(%203)
      aiex.dma_free_task(%203)
      %236 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8683520 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%236)
      %237 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%237)
      aiex.dma_await_task(%205)
      aiex.dma_free_task(%205)
      %238 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8529920 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%238)
      aiex.dma_await_task(%206)
      aiex.dma_free_task(%206)
      %239 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8693760 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%239)
      %240 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%240)
      aiex.dma_await_task(%208)
      aiex.dma_free_task(%208)
      %241 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8847360 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%241)
      aiex.dma_await_task(%209)
      aiex.dma_free_task(%209)
      %242 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9011200 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%242)
      %243 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%243)
      aiex.dma_await_task(%211)
      aiex.dma_free_task(%211)
      %244 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 8857600 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%244)
      aiex.dma_await_task(%212)
      aiex.dma_free_task(%212)
      %245 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9021440 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%245)
      %246 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%246)
      aiex.dma_await_task(%225)
      aiex.dma_free_task(%225)
      aiex.dma_await_task(%228)
      aiex.dma_free_task(%228)
      aiex.dma_await_task(%231)
      aiex.dma_free_task(%231)
      aiex.dma_await_task(%234)
      aiex.dma_free_task(%234)
      aiex.dma_await_task(%237)
      aiex.dma_free_task(%237)
      aiex.dma_await_task(%240)
      aiex.dma_free_task(%240)
      aiex.dma_await_task(%243)
      aiex.dma_free_task(%243)
      aiex.dma_await_task(%246)
      aiex.dma_free_task(%246)
      aiex.dma_await_task(%148)
      aiex.dma_free_task(%148)
      %247 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%247)
      aiex.dma_await_task(%215)
      aiex.dma_free_task(%215)
      %248 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339476480 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%248)
      aiex.dma_await_task(%216)
      aiex.dma_free_task(%216)
      %249 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339558400 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%249)
      aiex.dma_await_task(%217)
      aiex.dma_free_task(%217)
      %250 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339640320 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%250)
      aiex.dma_await_task(%218)
      aiex.dma_free_task(%218)
      %251 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339722240 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%251)
      aiex.dma_await_task(%219)
      aiex.dma_free_task(%219)
      %252 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339804160 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%252)
      aiex.dma_await_task(%220)
      aiex.dma_free_task(%220)
      %253 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339886080 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%253)
      aiex.dma_await_task(%221)
      aiex.dma_free_task(%221)
      %254 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 339968000 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%254)
      aiex.dma_await_task(%222)
      aiex.dma_free_task(%222)
      %255 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340049920 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%255)
      aiex.dma_await_task(%223)
      aiex.dma_free_task(%223)
      %256 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9175040 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%256)
      aiex.dma_await_task(%224)
      aiex.dma_free_task(%224)
      %257 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9338880 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%257)
      %258 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%258)
      aiex.dma_await_task(%226)
      aiex.dma_free_task(%226)
      %259 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9185280 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%259)
      aiex.dma_await_task(%227)
      aiex.dma_free_task(%227)
      %260 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9349120 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%260)
      %261 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%261)
      aiex.dma_await_task(%229)
      aiex.dma_free_task(%229)
      %262 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9502720 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%262)
      aiex.dma_await_task(%230)
      aiex.dma_free_task(%230)
      %263 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9666560 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%263)
      %264 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%264)
      aiex.dma_await_task(%232)
      aiex.dma_free_task(%232)
      %265 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9512960 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%265)
      aiex.dma_await_task(%233)
      aiex.dma_free_task(%233)
      %266 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9676800 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%266)
      %267 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%267)
      aiex.dma_await_task(%235)
      aiex.dma_free_task(%235)
      %268 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9830400 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%268)
      aiex.dma_await_task(%236)
      aiex.dma_free_task(%236)
      %269 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9994240 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%269)
      %270 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%270)
      aiex.dma_await_task(%238)
      aiex.dma_free_task(%238)
      %271 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 9840640 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%271)
      aiex.dma_await_task(%239)
      aiex.dma_free_task(%239)
      %272 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 10004480 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%272)
      %273 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%273)
      aiex.dma_await_task(%241)
      aiex.dma_free_task(%241)
      %274 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 10158080 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%274)
      aiex.dma_await_task(%242)
      aiex.dma_free_task(%242)
      %275 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 10321920 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%275)
      %276 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%276)
      aiex.dma_await_task(%244)
      aiex.dma_free_task(%244)
      %277 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 10168320 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%277)
      aiex.dma_await_task(%245)
      aiex.dma_free_task(%245)
      %278 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 10332160 len = 81920 sizes = [1, 8, 4, 2560] strides = [0, 20480, 2560, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%278)
      %279 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%279)
      aiex.dma_await_task(%258)
      aiex.dma_free_task(%258)
      aiex.dma_await_task(%261)
      aiex.dma_free_task(%261)
      aiex.dma_await_task(%264)
      aiex.dma_free_task(%264)
      aiex.dma_await_task(%267)
      aiex.dma_free_task(%267)
      aiex.dma_await_task(%270)
      aiex.dma_free_task(%270)
      aiex.dma_await_task(%273)
      aiex.dma_free_task(%273)
      aiex.dma_await_task(%276)
      aiex.dma_free_task(%276)
      aiex.dma_await_task(%279)
      aiex.dma_free_task(%279)
      aiex.dma_await_task(%181)
      aiex.dma_free_task(%181)
      %280 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%280)
      aiex.dma_await_task(%248)
      aiex.dma_free_task(%248)
      %281 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340131840 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%281)
      aiex.dma_await_task(%249)
      aiex.dma_free_task(%249)
      %282 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340213760 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%282)
      aiex.dma_await_task(%250)
      aiex.dma_free_task(%250)
      %283 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340295680 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%283)
      aiex.dma_await_task(%251)
      aiex.dma_free_task(%251)
      %284 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340377600 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%284)
      aiex.dma_await_task(%252)
      aiex.dma_free_task(%252)
      %285 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340459520 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%285)
      aiex.dma_await_task(%253)
      aiex.dma_free_task(%253)
      %286 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340541440 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%286)
      aiex.dma_await_task(%254)
      aiex.dma_free_task(%254)
      %287 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340623360 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%287)
      aiex.dma_await_task(%255)
      aiex.dma_free_task(%255)
      %288 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 340705280 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%288)
      aiex.dma_await_task(%256)
      aiex.dma_free_task(%256)
      %289 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503316480 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%289)
      aiex.dma_await_task(%257)
      aiex.dma_free_task(%257)
      %290 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503971840 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%290)
      %291 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%291)
      aiex.dma_await_task(%259)
      aiex.dma_free_task(%259)
      %292 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503398400 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%292)
      aiex.dma_await_task(%260)
      aiex.dma_free_task(%260)
      %293 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504053760 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%293)
      %294 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186624 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%294)
      aiex.dma_await_task(%262)
      aiex.dma_free_task(%262)
      %295 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503480320 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%295)
      aiex.dma_await_task(%263)
      aiex.dma_free_task(%263)
      %296 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504135680 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%296)
      %297 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186880 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%297)
      aiex.dma_await_task(%265)
      aiex.dma_free_task(%265)
      %298 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503562240 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%298)
      aiex.dma_await_task(%266)
      aiex.dma_free_task(%266)
      %299 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504217600 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%299)
      %300 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187136 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%300)
      aiex.dma_await_task(%268)
      aiex.dma_free_task(%268)
      %301 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503644160 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%301)
      aiex.dma_await_task(%269)
      aiex.dma_free_task(%269)
      %302 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504299520 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%302)
      %303 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187392 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%303)
      aiex.dma_await_task(%271)
      aiex.dma_free_task(%271)
      %304 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503726080 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%304)
      aiex.dma_await_task(%272)
      aiex.dma_free_task(%272)
      %305 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504381440 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%305)
      %306 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187648 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%306)
      aiex.dma_await_task(%274)
      aiex.dma_free_task(%274)
      %307 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503808000 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%307)
      aiex.dma_await_task(%275)
      aiex.dma_free_task(%275)
      %308 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504463360 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%308)
      %309 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 187904 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%309)
      aiex.dma_await_task(%277)
      aiex.dma_free_task(%277)
      %310 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 503889920 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%310)
      aiex.dma_await_task(%278)
      aiex.dma_free_task(%278)
      %311 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504545280 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%311)
      %312 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 188160 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%312)
      aiex.dma_await_task(%291)
      aiex.dma_free_task(%291)
      aiex.dma_await_task(%294)
      aiex.dma_free_task(%294)
      aiex.dma_await_task(%297)
      aiex.dma_free_task(%297)
      aiex.dma_await_task(%300)
      aiex.dma_free_task(%300)
      aiex.dma_await_task(%303)
      aiex.dma_free_task(%303)
      aiex.dma_await_task(%306)
      aiex.dma_free_task(%306)
      aiex.dma_await_task(%309)
      aiex.dma_free_task(%309)
      aiex.dma_await_task(%312)
      aiex.dma_free_task(%312)
      aiex.dma_await_task(%214)
      aiex.dma_free_task(%214)
      %313 = aiex.dma_configure_task_for @x {
        aie.dma_bd(%arg4 : memref<190464xui8> offset = 186368 len = 4096 sizes = [1, 1, 1, 4096] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%313)
      aiex.dma_await_task(%281)
      aiex.dma_free_task(%281)
      %314 = aiex.dma_configure_task_for @w0 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504627200 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%314)
      aiex.dma_await_task(%282)
      aiex.dma_free_task(%282)
      %315 = aiex.dma_configure_task_for @w1 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504709120 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%315)
      aiex.dma_await_task(%283)
      aiex.dma_free_task(%283)
      %316 = aiex.dma_configure_task_for @w2 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504791040 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%316)
      aiex.dma_await_task(%284)
      aiex.dma_free_task(%284)
      %317 = aiex.dma_configure_task_for @w3 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504872960 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%317)
      aiex.dma_await_task(%285)
      aiex.dma_free_task(%285)
      %318 = aiex.dma_configure_task_for @w4 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 504954880 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%318)
      aiex.dma_await_task(%286)
      aiex.dma_free_task(%286)
      %319 = aiex.dma_configure_task_for @w5 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 505036800 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%319)
      aiex.dma_await_task(%287)
      aiex.dma_free_task(%287)
      %320 = aiex.dma_configure_task_for @w6 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 505118720 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%320)
      aiex.dma_await_task(%288)
      aiex.dma_free_task(%288)
      %321 = aiex.dma_configure_task_for @w7 {
        aie.dma_bd(%arg0 : memref<540016640xui8> offset = 505200640 len = 81920 sizes = [1, 1, 1, 81920] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%321)
      %322 = aiex.dma_configure_task_for @y0 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 0 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%322)
      %323 = aiex.dma_configure_task_for @y1 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 256 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%323)
      %324 = aiex.dma_configure_task_for @y2 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 512 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%324)
      %325 = aiex.dma_configure_task_for @y3 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 768 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%325)
      %326 = aiex.dma_configure_task_for @y4 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 1024 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%326)
      %327 = aiex.dma_configure_task_for @y5 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 1280 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%327)
      %328 = aiex.dma_configure_task_for @y6 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 1536 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%328)
      %329 = aiex.dma_configure_task_for @y7 {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 1792 len = 256 sizes = [1, 1, 1, 256] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%329)
      aiex.dma_await_task(%289)
      aiex.dma_free_task(%289)
      aiex.dma_await_task(%290)
      aiex.dma_free_task(%290)
      aiex.dma_await_task(%314)
      aiex.dma_free_task(%314)
      aiex.dma_await_task(%292)
      aiex.dma_free_task(%292)
      aiex.dma_await_task(%293)
      aiex.dma_free_task(%293)
      aiex.dma_await_task(%315)
      aiex.dma_free_task(%315)
      aiex.dma_await_task(%295)
      aiex.dma_free_task(%295)
      aiex.dma_await_task(%296)
      aiex.dma_free_task(%296)
      aiex.dma_await_task(%316)
      aiex.dma_free_task(%316)
      aiex.dma_await_task(%298)
      aiex.dma_free_task(%298)
      aiex.dma_await_task(%299)
      aiex.dma_free_task(%299)
      aiex.dma_await_task(%317)
      aiex.dma_free_task(%317)
      aiex.dma_await_task(%301)
      aiex.dma_free_task(%301)
      aiex.dma_await_task(%302)
      aiex.dma_free_task(%302)
      aiex.dma_await_task(%318)
      aiex.dma_free_task(%318)
      aiex.dma_await_task(%304)
      aiex.dma_free_task(%304)
      aiex.dma_await_task(%305)
      aiex.dma_free_task(%305)
      aiex.dma_await_task(%319)
      aiex.dma_free_task(%319)
      aiex.dma_await_task(%307)
      aiex.dma_free_task(%307)
      aiex.dma_await_task(%308)
      aiex.dma_free_task(%308)
      aiex.dma_await_task(%320)
      aiex.dma_free_task(%320)
      aiex.dma_await_task(%310)
      aiex.dma_free_task(%310)
      aiex.dma_await_task(%311)
      aiex.dma_free_task(%311)
      aiex.dma_await_task(%321)
      aiex.dma_free_task(%321)
      aiex.dma_await_task(%247)
      aiex.dma_free_task(%247)
      aiex.dma_await_task(%280)
      aiex.dma_free_task(%280)
      aiex.dma_await_task(%313)
      aiex.dma_free_task(%313)
      aiex.dma_await_task(%322)
      aiex.dma_free_task(%322)
      aiex.dma_await_task(%323)
      aiex.dma_free_task(%323)
      aiex.dma_await_task(%324)
      aiex.dma_free_task(%324)
      aiex.dma_await_task(%325)
      aiex.dma_free_task(%325)
      aiex.dma_await_task(%326)
      aiex.dma_free_task(%326)
      aiex.dma_await_task(%327)
      aiex.dma_free_task(%327)
      aiex.dma_await_task(%328)
      aiex.dma_free_task(%328)
      aiex.dma_await_task(%329)
      aiex.dma_free_task(%329)
    }
  }
}
