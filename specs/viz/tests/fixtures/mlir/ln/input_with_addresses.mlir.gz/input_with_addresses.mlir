#loc5 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":9:17)
#loc8 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":13:15)
#loc10 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":15:14)
#loc11 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":16:14)
#loc12 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":17:14)
#loc13 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":18:14)
#loc14 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":19:14)
#loc16 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":21:14)
#loc17 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":22:14)
#loc18 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":23:14)
#loc24 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:26)
#loc25 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:51)
#loc26 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:76)
#loc27 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:102)
#loc28 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:127)
module {
  aie.device(npu2) {
    %shim_noc_tile_0_0 = aie.tile(0, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %tile_0_2 = aie.tile(0, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %out_cons_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 0) {init = 0 : i32, sym_name = "out_cons_prod_lock_0"} loc(#loc2)
    %out_cons_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 1) {init = 0 : i32, sym_name = "out_cons_cons_lock_0"} loc(#loc2)
    %out_buff_0 = aie.buffer(%tile_0_2) {address = 6144 : i32, sym_name = "out_buff_0"} : memref<4096xui8>  loc(#loc2)
    %out_buff_1 = aie.buffer(%tile_0_2) {address = 10240 : i32, sym_name = "out_buff_1"} : memref<4096xui8>  loc(#loc2)
    %out_buff_2 = aie.buffer(%tile_0_2) {address = 14336 : i32, sym_name = "out_buff_2"} : memref<4096xui8>  loc(#loc2)
    %out_buff_3 = aie.buffer(%tile_0_2) {address = 18432 : i32, sym_name = "out_buff_3"} : memref<4096xui8>  loc(#loc2)
    %out_prod_lock_0 = aie.lock(%tile_0_2, 0) {init = 4 : i32, sym_name = "out_prod_lock_0"} loc(#loc2)
    %out_cons_lock_0 = aie.lock(%tile_0_2, 1) {init = 0 : i32, sym_name = "out_cons_lock_0"} loc(#loc2)
    %in_cons_buff_0 = aie.buffer(%tile_0_2) {address = 22528 : i32, sym_name = "in_cons_buff_0"} : memref<4096xui8>  loc(#loc3)
    %in_cons_buff_1 = aie.buffer(%tile_0_2) {address = 26624 : i32, sym_name = "in_cons_buff_1"} : memref<4096xui8>  loc(#loc3)
    %in_cons_buff_2 = aie.buffer(%tile_0_2) {address = 30720 : i32, sym_name = "in_cons_buff_2"} : memref<4096xui8>  loc(#loc3)
    %in_cons_buff_3 = aie.buffer(%tile_0_2) {address = 34816 : i32, sym_name = "in_cons_buff_3"} : memref<4096xui8>  loc(#loc3)
    %in_cons_buff_4 = aie.buffer(%tile_0_2) {address = 38912 : i32, sym_name = "in_cons_buff_4"} : memref<4096xui8>  loc(#loc3)
    %in_cons_buff_5 = aie.buffer(%tile_0_2) {address = 43008 : i32, sym_name = "in_cons_buff_5"} : memref<4096xui8>  loc(#loc3)
    %in_cons_prod_lock_0 = aie.lock(%tile_0_2, 2) {init = 6 : i32, sym_name = "in_cons_prod_lock_0"} loc(#loc3)
    %in_cons_cons_lock_0 = aie.lock(%tile_0_2, 3) {init = 0 : i32, sym_name = "in_cons_cons_lock_0"} loc(#loc3)
    %in_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 2) {init = 0 : i32, sym_name = "in_prod_lock_0"} loc(#loc3)
    %in_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 3) {init = 0 : i32, sym_name = "in_cons_lock_0"} loc(#loc3)
    aie.flow(%shim_noc_tile_0_0, DMA : 0, %tile_0_2, DMA : 0) loc(#loc3)
    aie.flow(%tile_0_2, DMA : 0, %shim_noc_tile_0_0, DMA : 0) loc(#loc2)
    func.func private @ln_fn(memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) attributes {link_with = "ln_fn.o"} loc(#loc4)
    %core_0_2 = aie.core(%tile_0_2) {
      %c1 = arith.constant 1 : index loc(#loc6)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc6)
      %c0 = arith.constant 0 : index loc(#loc6)
      %c0_i32 = arith.constant 0 : i32 loc(#loc6)
      %c5_i32 = arith.constant 5 : i32 loc(#loc6)
      %c3_i32 = arith.constant 3 : i32 loc(#loc6)
      %c4_i32 = arith.constant 4 : i32 loc(#loc6)
      %c6_i32 = arith.constant 6 : i32 loc(#loc6)
      %c-1_i32 = arith.constant -1 : i32 loc(#loc6)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc7)
    ^bb1(%0: index loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":13:15), %1: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":9:17), %2: i32 loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":9:17)):  // 2 preds: ^bb0, ^bb60
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc7)
      cf.cond_br %3, ^bb2, ^bb61 loc(#loc7)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%in_cons_cons_lock_0, AcquireGreaterEqual, %c5_i32) loc(#loc9)
      %4 = arith.index_cast %1 : i32 to index loc(#loc10)
      %5 = arith.index_cast %4 : index to i64 loc(#loc10)
      cf.switch %5 : i64, [
        default: ^bb9,
        0: ^bb3,
        1: ^bb4,
        2: ^bb5,
        3: ^bb6,
        4: ^bb7,
        5: ^bb8
      ] loc(#loc10)
    ^bb3:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_0 : memref<4096xui8>) loc(#loc10)
    ^bb4:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_1 : memref<4096xui8>) loc(#loc10)
    ^bb5:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_2 : memref<4096xui8>) loc(#loc10)
    ^bb6:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_3 : memref<4096xui8>) loc(#loc10)
    ^bb7:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_4 : memref<4096xui8>) loc(#loc10)
    ^bb8:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_5 : memref<4096xui8>) loc(#loc10)
    ^bb9:  // pred: ^bb2
      cf.br ^bb10(%in_cons_buff_0 : memref<4096xui8>) loc(#loc10)
    ^bb10(%6: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":15:14)):  // 7 preds: ^bb3, ^bb4, ^bb5, ^bb6, ^bb7, ^bb8, ^bb9
      %7 = arith.index_cast %1 : i32 to index loc(#loc11)
      %8 = arith.index_cast %7 : index to i64 loc(#loc11)
      cf.switch %8 : i64, [
        default: ^bb17,
        0: ^bb11,
        1: ^bb12,
        2: ^bb13,
        3: ^bb14,
        4: ^bb15,
        5: ^bb16
      ] loc(#loc11)
    ^bb11:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_1 : memref<4096xui8>) loc(#loc11)
    ^bb12:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_2 : memref<4096xui8>) loc(#loc11)
    ^bb13:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_3 : memref<4096xui8>) loc(#loc11)
    ^bb14:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_4 : memref<4096xui8>) loc(#loc11)
    ^bb15:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_5 : memref<4096xui8>) loc(#loc11)
    ^bb16:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_0 : memref<4096xui8>) loc(#loc11)
    ^bb17:  // pred: ^bb10
      cf.br ^bb18(%in_cons_buff_1 : memref<4096xui8>) loc(#loc11)
    ^bb18(%9: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":16:14)):  // 7 preds: ^bb11, ^bb12, ^bb13, ^bb14, ^bb15, ^bb16, ^bb17
      %10 = arith.index_cast %1 : i32 to index loc(#loc12)
      %11 = arith.index_cast %10 : index to i64 loc(#loc12)
      cf.switch %11 : i64, [
        default: ^bb25,
        0: ^bb19,
        1: ^bb20,
        2: ^bb21,
        3: ^bb22,
        4: ^bb23,
        5: ^bb24
      ] loc(#loc12)
    ^bb19:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_2 : memref<4096xui8>) loc(#loc12)
    ^bb20:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_3 : memref<4096xui8>) loc(#loc12)
    ^bb21:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_4 : memref<4096xui8>) loc(#loc12)
    ^bb22:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_5 : memref<4096xui8>) loc(#loc12)
    ^bb23:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_0 : memref<4096xui8>) loc(#loc12)
    ^bb24:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_1 : memref<4096xui8>) loc(#loc12)
    ^bb25:  // pred: ^bb18
      cf.br ^bb26(%in_cons_buff_2 : memref<4096xui8>) loc(#loc12)
    ^bb26(%12: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":17:14)):  // 7 preds: ^bb19, ^bb20, ^bb21, ^bb22, ^bb23, ^bb24, ^bb25
      %13 = arith.index_cast %1 : i32 to index loc(#loc13)
      %14 = arith.index_cast %13 : index to i64 loc(#loc13)
      cf.switch %14 : i64, [
        default: ^bb33,
        0: ^bb27,
        1: ^bb28,
        2: ^bb29,
        3: ^bb30,
        4: ^bb31,
        5: ^bb32
      ] loc(#loc13)
    ^bb27:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_3 : memref<4096xui8>) loc(#loc13)
    ^bb28:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_4 : memref<4096xui8>) loc(#loc13)
    ^bb29:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_5 : memref<4096xui8>) loc(#loc13)
    ^bb30:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_0 : memref<4096xui8>) loc(#loc13)
    ^bb31:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_1 : memref<4096xui8>) loc(#loc13)
    ^bb32:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_2 : memref<4096xui8>) loc(#loc13)
    ^bb33:  // pred: ^bb26
      cf.br ^bb34(%in_cons_buff_3 : memref<4096xui8>) loc(#loc13)
    ^bb34(%15: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":18:14)):  // 7 preds: ^bb27, ^bb28, ^bb29, ^bb30, ^bb31, ^bb32, ^bb33
      %16 = arith.index_cast %1 : i32 to index loc(#loc14)
      %17 = arith.index_cast %16 : index to i64 loc(#loc14)
      cf.switch %17 : i64, [
        default: ^bb41,
        0: ^bb35,
        1: ^bb36,
        2: ^bb37,
        3: ^bb38,
        4: ^bb39,
        5: ^bb40
      ] loc(#loc14)
    ^bb35:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_4 : memref<4096xui8>) loc(#loc14)
    ^bb36:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_5 : memref<4096xui8>) loc(#loc14)
    ^bb37:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_0 : memref<4096xui8>) loc(#loc14)
    ^bb38:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_1 : memref<4096xui8>) loc(#loc14)
    ^bb39:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_2 : memref<4096xui8>) loc(#loc14)
    ^bb40:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_3 : memref<4096xui8>) loc(#loc14)
    ^bb41:  // pred: ^bb34
      cf.br ^bb42(%in_cons_buff_4 : memref<4096xui8>) loc(#loc14)
    ^bb42(%18: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":19:14)):  // 7 preds: ^bb35, ^bb36, ^bb37, ^bb38, ^bb39, ^bb40, ^bb41
      aie.use_lock(%out_prod_lock_0, AcquireGreaterEqual, %c3_i32) loc(#loc15)
      %19 = arith.index_cast %2 : i32 to index loc(#loc16)
      %20 = arith.index_cast %19 : index to i64 loc(#loc16)
      cf.switch %20 : i64, [
        default: ^bb47,
        0: ^bb43,
        1: ^bb44,
        2: ^bb45,
        3: ^bb46
      ] loc(#loc16)
    ^bb43:  // pred: ^bb42
      cf.br ^bb48(%out_buff_0 : memref<4096xui8>) loc(#loc16)
    ^bb44:  // pred: ^bb42
      cf.br ^bb48(%out_buff_1 : memref<4096xui8>) loc(#loc16)
    ^bb45:  // pred: ^bb42
      cf.br ^bb48(%out_buff_2 : memref<4096xui8>) loc(#loc16)
    ^bb46:  // pred: ^bb42
      cf.br ^bb48(%out_buff_3 : memref<4096xui8>) loc(#loc16)
    ^bb47:  // pred: ^bb42
      cf.br ^bb48(%out_buff_0 : memref<4096xui8>) loc(#loc16)
    ^bb48(%21: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":21:14)):  // 5 preds: ^bb43, ^bb44, ^bb45, ^bb46, ^bb47
      %22 = arith.index_cast %2 : i32 to index loc(#loc17)
      %23 = arith.index_cast %22 : index to i64 loc(#loc17)
      cf.switch %23 : i64, [
        default: ^bb53,
        0: ^bb49,
        1: ^bb50,
        2: ^bb51,
        3: ^bb52
      ] loc(#loc17)
    ^bb49:  // pred: ^bb48
      cf.br ^bb54(%out_buff_1 : memref<4096xui8>) loc(#loc17)
    ^bb50:  // pred: ^bb48
      cf.br ^bb54(%out_buff_2 : memref<4096xui8>) loc(#loc17)
    ^bb51:  // pred: ^bb48
      cf.br ^bb54(%out_buff_3 : memref<4096xui8>) loc(#loc17)
    ^bb52:  // pred: ^bb48
      cf.br ^bb54(%out_buff_0 : memref<4096xui8>) loc(#loc17)
    ^bb53:  // pred: ^bb48
      cf.br ^bb54(%out_buff_1 : memref<4096xui8>) loc(#loc17)
    ^bb54(%24: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":22:14)):  // 5 preds: ^bb49, ^bb50, ^bb51, ^bb52, ^bb53
      %25 = arith.index_cast %2 : i32 to index loc(#loc18)
      %26 = arith.index_cast %25 : index to i64 loc(#loc18)
      cf.switch %26 : i64, [
        default: ^bb59,
        0: ^bb55,
        1: ^bb56,
        2: ^bb57,
        3: ^bb58
      ] loc(#loc18)
    ^bb55:  // pred: ^bb54
      cf.br ^bb60(%out_buff_2 : memref<4096xui8>) loc(#loc18)
    ^bb56:  // pred: ^bb54
      cf.br ^bb60(%out_buff_3 : memref<4096xui8>) loc(#loc18)
    ^bb57:  // pred: ^bb54
      cf.br ^bb60(%out_buff_0 : memref<4096xui8>) loc(#loc18)
    ^bb58:  // pred: ^bb54
      cf.br ^bb60(%out_buff_1 : memref<4096xui8>) loc(#loc18)
    ^bb59:  // pred: ^bb54
      cf.br ^bb60(%out_buff_2 : memref<4096xui8>) loc(#loc18)
    ^bb60(%27: memref<4096xui8> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":23:14)):  // 5 preds: ^bb55, ^bb56, ^bb57, ^bb58, ^bb59
      func.call @ln_fn(%6, %9, %12, %15, %18, %21, %24, %27) : (memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) -> () loc(#loc19)
      aie.use_lock(%out_cons_lock_0, Release, %c3_i32) loc(#loc20)
      %28 = arith.addi %2, %c3_i32 : i32 loc(#loc20)
      %29 = arith.cmpi sge, %28, %c4_i32 : i32 loc(#loc20)
      %30 = arith.addi %2, %c-1_i32 : i32 loc(#loc20)
      %31 = arith.select %29, %30, %28 : i32 loc(#loc20)
      aie.use_lock(%in_cons_prod_lock_0, Release, %c5_i32) loc(#loc21)
      %32 = arith.addi %1, %c5_i32 : i32 loc(#loc21)
      %33 = arith.cmpi sge, %32, %c6_i32 : i32 loc(#loc21)
      %34 = arith.addi %1, %c-1_i32 : i32 loc(#loc21)
      %35 = arith.select %33, %34, %32 : i32 loc(#loc21)
      %36 = arith.addi %0, %c1 : index loc(#loc7)
      cf.br ^bb1(%36, %35, %31 : index, i32, i32) loc(#loc7)
    ^bb61:  // pred: ^bb1
      aie.end loc(#loc22)
    } {link_files = ["ln_fn.o"], stack_size = 6144 : i32} loc(#loc5)
    aie.runtime_sequence(%arg0: memref<2048xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:26), %arg1: memref<2048xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:51), %arg2: memref<2048xbf16> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:76), %arg3: memref<2048xf32> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:102), %arg4: memref<2048xbf16> loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:127)) {
      %0 = aiex.dma_configure_task_for @out_shim_alloc {
        aie.dma_bd(%arg3 : memref<2048xf32> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1]) loc(#loc30)
        aie.end loc(#loc31)
      } {issue_token = true} loc(#loc29)
      aiex.dma_start_task(%0) loc(#loc32)
      %1 = aiex.dma_configure_task_for @out_shim_alloc {
        aie.dma_bd(%arg4 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1]) loc(#loc34)
        aie.end loc(#loc35)
      } {issue_token = true} loc(#loc33)
      aiex.dma_start_task(%1) loc(#loc36)
      %2 = aiex.dma_configure_task_for @in_shim_alloc {
        aie.dma_bd(%arg0 : memref<2048xf32> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1]) loc(#loc38)
        aie.end loc(#loc39)
      } {issue_token = true} loc(#loc37)
      aiex.dma_start_task(%2) loc(#loc40)
      %3 = aiex.dma_configure_task_for @in_shim_alloc {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1]) loc(#loc42)
        aie.end loc(#loc43)
      } {issue_token = true} loc(#loc41)
      aiex.dma_start_task(%3) loc(#loc44)
      %4 = aiex.dma_configure_task_for @in_shim_alloc {
        aie.dma_bd(%arg2 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1]) loc(#loc46)
        aie.end loc(#loc47)
      } {issue_token = true} loc(#loc45)
      aiex.dma_start_task(%4) loc(#loc48)
      aiex.dma_await_task(%0) loc(#loc49)
      aiex.dma_free_task(%0) loc(#loc50)
      aiex.dma_await_task(%1) loc(#loc51)
      aiex.dma_free_task(%1) loc(#loc52)
      aiex.dma_await_task(%2) loc(#loc53)
      aiex.dma_free_task(%2) loc(#loc54)
      aiex.dma_await_task(%3) loc(#loc55)
      aiex.dma_free_task(%3) loc(#loc56)
      aiex.dma_await_task(%4) loc(#loc57)
      aiex.dma_free_task(%4) loc(#loc58)
    } loc(#loc23)
    aie.shim_dma_allocation @in_shim_alloc(%shim_noc_tile_0_0, MM2S, 0) loc(#loc3)
    %mem_0_2 = aie.mem(%tile_0_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc6)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb7) loc(#loc3)
    ^bb1:  // 2 preds: ^bb0, ^bb6
      aie.use_lock(%in_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%in_cons_buff_0 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc3)
      aie.use_lock(%in_cons_cons_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb2 loc(#loc3)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%in_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%in_cons_buff_1 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc3)
      aie.use_lock(%in_cons_cons_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb3 loc(#loc3)
    ^bb3:  // pred: ^bb2
      aie.use_lock(%in_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%in_cons_buff_2 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc3)
      aie.use_lock(%in_cons_cons_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb4 loc(#loc3)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%in_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%in_cons_buff_3 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc3)
      aie.use_lock(%in_cons_cons_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb5 loc(#loc3)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%in_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%in_cons_buff_4 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc3)
      aie.use_lock(%in_cons_cons_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb6 loc(#loc3)
    ^bb6:  // pred: ^bb5
      aie.use_lock(%in_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%in_cons_buff_5 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 5 : i32, next_bd_id = 0 : i32} loc(#loc3)
      aie.use_lock(%in_cons_cons_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb1 loc(#loc3)
    ^bb7:  // pred: ^bb0
      %1 = aie.dma_start(MM2S, 0, ^bb8, ^bb12) loc(#loc2)
    ^bb8:  // 2 preds: ^bb7, ^bb11
      aie.use_lock(%out_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%out_buff_0 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc2)
      aie.use_lock(%out_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb9 loc(#loc2)
    ^bb9:  // pred: ^bb8
      aie.use_lock(%out_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%out_buff_1 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc2)
      aie.use_lock(%out_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb10 loc(#loc2)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%out_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%out_buff_2 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc2)
      aie.use_lock(%out_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb11 loc(#loc2)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%out_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%out_buff_3 : memref<4096xui8> offset = 0 len = 4096) {bd_id = 9 : i32, next_bd_id = 6 : i32} loc(#loc2)
      aie.use_lock(%out_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb8 loc(#loc2)
    ^bb12:  // pred: ^bb7
      aie.end loc(#loc3)
    } loc(#loc3)
    aie.shim_dma_allocation @out_shim_alloc(%shim_noc_tile_0_0, S2MM, 0) loc(#loc2)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_0_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_0_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
  } loc(#loc1)
} loc(#loc)
#loc = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":1:1)
#loc1 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":2:3)
#loc2 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":7:5)
#loc3 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":6:5)
#loc4 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":8:5)
#loc6 = loc(unknown)
#loc7 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":13:7)
#loc9 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":14:14)
#loc15 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":20:14)
#loc19 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":24:9)
#loc20 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":25:9)
#loc21 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":26:9)
#loc22 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":28:7)
#loc23 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":30:5)
#loc29 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":31:12)
#loc30 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":32:9)
#loc31 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":33:9)
#loc32 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":35:7)
#loc33 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":36:12)
#loc34 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":37:9)
#loc35 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":38:9)
#loc36 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":40:7)
#loc37 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":41:12)
#loc38 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":42:9)
#loc39 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":43:9)
#loc40 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":45:7)
#loc41 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":46:12)
#loc42 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":47:9)
#loc43 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":48:9)
#loc44 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":50:7)
#loc45 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":51:12)
#loc46 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":52:9)
#loc47 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":53:9)
#loc48 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":55:7)
#loc49 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":56:7)
#loc50 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":57:7)
#loc51 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":58:7)
#loc52 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":59:7)
#loc53 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":60:7)
#loc54 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":61:7)
#loc55 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":62:7)
#loc56 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":63:7)
#loc57 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":64:7)
#loc58 = loc("/mnt/c/code/OpenFlowLM-Next2/open_kernels/designs/ln/build/final.prj/aie.mlir":65:7)
