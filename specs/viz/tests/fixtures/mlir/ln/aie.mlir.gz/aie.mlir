module {
  aie.device(npu2) {
    %logical_core = aie.logical_tile<CoreTile>(0, 2)
    %logical_shim_noc = aie.logical_tile<ShimNOCTile>(?, ?)
    %logical_shim_noc_0 = aie.logical_tile<ShimNOCTile>(?, ?)
    aie.objectfifo @in(%logical_shim_noc, {%logical_core}, 5 : i32) : !aie.objectfifo<memref<4096xui8>>  
    aie.objectfifo @out(%logical_core, {%logical_shim_noc_0}, 3 : i32) : !aie.objectfifo<memref<4096xui8>>  
    func.func private @ln_fn(memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) attributes {link_with = "ln_fn.o"}
    %core_0_2 = aie.core(%logical_core) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %0 = aie.objectfifo.acquire @in(Consume, 5) : !aie.objectfifosubview<memref<4096xui8>>
        %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %2 = aie.objectfifo.subview.access %0[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %3 = aie.objectfifo.subview.access %0[2] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %4 = aie.objectfifo.subview.access %0[3] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %5 = aie.objectfifo.subview.access %0[4] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %6 = aie.objectfifo.acquire @out(Produce, 3) : !aie.objectfifosubview<memref<4096xui8>>
        %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %8 = aie.objectfifo.subview.access %6[1] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        %9 = aie.objectfifo.subview.access %6[2] : !aie.objectfifosubview<memref<4096xui8>> -> memref<4096xui8>
        func.call @ln_fn(%1, %2, %3, %4, %5, %7, %8, %9) : (memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>, memref<4096xui8>) -> ()
        aie.objectfifo.release @out(Produce, 3)
        aie.objectfifo.release @in(Consume, 5)
      }
      aie.end
    } {stack_size = 6144 : i32}
    aie.runtime_sequence(%arg0: memref<2048xf32>, %arg1: memref<2048xf32>, %arg2: memref<2048xbf16>, %arg3: memref<2048xf32>, %arg4: memref<2048xbf16>) {
      %0 = aiex.dma_configure_task_for @out {
        aie.dma_bd(%arg3 : memref<2048xf32> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%0)
      %1 = aiex.dma_configure_task_for @out {
        aie.dma_bd(%arg4 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%1)
      %2 = aiex.dma_configure_task_for @in {
        aie.dma_bd(%arg0 : memref<2048xf32> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%2)
      %3 = aiex.dma_configure_task_for @in {
        aie.dma_bd(%arg1 : memref<2048xf32> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%3)
      %4 = aiex.dma_configure_task_for @in {
        aie.dma_bd(%arg2 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 1, 1, 2048] strides = [0, 0, 0, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%4)
      aiex.dma_await_task(%0)
      aiex.dma_free_task(%0)
      aiex.dma_await_task(%1)
      aiex.dma_free_task(%1)
      aiex.dma_await_task(%2)
      aiex.dma_free_task(%2)
      aiex.dma_await_task(%3)
      aiex.dma_free_task(%3)
      aiex.dma_await_task(%4)
      aiex.dma_free_task(%4)
    }
  }
}
